import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ComingSoon from "./pages/ComingSoon";
import SpaceInvaders from "./pages/games/SpaceInvaders";
import NeonPong from "./pages/games/NeonPong";
import MemoryMatrix from "./pages/games/MemoryMatrix";
import InfiniteRunner from "./pages/games/InfiniteRunner";
import BlackHolePuzzle from "./pages/games/BlackHolePuzzle";
import CyberSlash from "./pages/games/CyberSlash";
import GravityDodge from "./pages/games/GravityDodge";
import CryptoMiner from "./pages/games/CryptoMiner";
import AIDungeon from "./pages/games/AIDungeon";
import QuantumTetris from "./pages/games/QuantumTetris";
import PlasmaSnake from "./pages/games/PlasmaSnake";
import SingularityClicker from "./pages/games/SingularityClicker";
import LaserDeflector from "./pages/games/LaserDeflector";
import GlitchPainter from "./pages/games/GlitchPainter";
import PixelZombies from "./pages/games/PixelZombies";
import BeatSyncRhythm from "./pages/games/BeatSyncRhythm";
import NanoRacing from "./pages/games/NanoRacing";
import DataBreachHacker from "./pages/games/DataBreachHacker";
import VoidJumper from "./pages/games/VoidJumper";
import OrbitalChess from "./pages/games/OrbitalChess";
import CyberBlackjack from "./pages/games/CyberBlackjack";
import AstroArcher from "./pages/games/AstroArcher";
import CodeBreaker from "./pages/games/CodeBreaker";
import VirtualPetSimulator from "./pages/games/VirtualPetSimulator";
import StealthHacker from "./pages/games/StealthHacker";
import DroneDelivery from "./pages/games/DroneDelivery";
import NeuralNetworkPuzzle from "./pages/games/NeuralNetworkPuzzle";
import RetroRacer from "./pages/games/RetroRacer";
import HoloMazeEscape from "./pages/games/HoloMazeEscape";
import TimeWarpShooter from "./pages/games/TimeWarpShooter";
import CircuitBreaker from "./pages/games/CircuitBreaker";
import QuantumLeapPlatformer from "./pages/games/QuantumLeapPlatformer";
import PixelArtCreator from "./pages/games/PixelArtCreator";
import SpaceColonyBuilder from "./pages/games/SpaceColonyBuilder";
import AICombatArena from "./pages/games/AICombatArena";
import CyberneticFarm from "./pages/games/CyberneticFarm";
import GravityFlipAdventure from "./pages/games/GravityFlipAdventure";
import NeonBattleRoyale from "./pages/games/NeonBattleRoyale";
import DataStreamRunner from "./pages/games/DataStreamRunner";
import AugmentedRealityQuest from "./pages/games/AugmentedRealityQuest";
import BiohazardSurvival from "./pages/games/BiohazardSurvival";
import CodeQuestRPG from "./pages/games/CodeQuestRPG";
import GalacticTrader from "./pages/games/GalacticTrader";
import RhythmRacer from "./pages/games/RhythmRacer";
import MemoryMazeChallenge from "./pages/games/MemoryMazeChallenge";
import CyberpunkDetective from "./pages/games/CyberpunkDetective";
import LightSpeedPuzzle from "./pages/games/LightSpeedPuzzle";
import VirtualRealityExplorer from "./pages/games/VirtualRealityExplorer";
import DigitalDungeonCrawler from "./pages/games/DigitalDungeonCrawler";
import SynthwaveShooter from "./pages/games/SynthwaveShooter";
import GalagaSpecialEdition from "./pages/games/GalagaSpecialEdition";
import GeometryWarsRetro from "./pages/games/GeometryWarsRetro";
import AsteroidsReloaded from "./pages/games/AsteroidsReloaded";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/coming-soon" element={<ComingSoon />} />
          <Route path="/game/space-invaders" element={<SpaceInvaders />} />
          <Route path="/game/neon-pong" element={<NeonPong />} />
          <Route path="/game/memory-matrix" element={<MemoryMatrix />} />
          <Route path="/game/infinite-runner" element={<InfiniteRunner />} />
          <Route path="/game/black-hole-puzzle" element={<BlackHolePuzzle />} />
          <Route path="/game/cyber-slash" element={<CyberSlash />} />
          <Route path="/game/gravity-dodge" element={<GravityDodge />} />
          <Route path="/game/crypto-miner" element={<CryptoMiner />} />
          <Route path="/game/ai-dungeon" element={<AIDungeon />} />
          <Route path="/game/quantum-tetris" element={<QuantumTetris />} />
          <Route path="/game/plasma-snake" element={<PlasmaSnake />} />
          <Route path="/game/singularity-clicker" element={<SingularityClicker />} />
          <Route path="/game/laser-deflector" element={<LaserDeflector />} />
          <Route path="/game/glitch-painter" element={<GlitchPainter />} />
          <Route path="/game/pixel-zombies" element={<PixelZombies />} />
          <Route path="/game/beat-sync-rhythm" element={<BeatSyncRhythm />} />
          <Route path="/game/nano-racing" element={<NanoRacing />} />
          <Route path="/game/data-breach-hacker" element={<DataBreachHacker />} />
          <Route path="/game/void-jumper" element={<VoidJumper />} />
          {/* Placeholder routes for remaining games */}
          <Route path="/game/orbital-chess" element={<OrbitalChess />} />
          <Route path="/game/cyber-blackjack" element={<CyberBlackjack />} />
          <Route path="/game/astro-archer" element={<AstroArcher />} />
          <Route path="/game/code-breaker" element={<CodeBreaker />} />
          <Route path="/game/drone-delivery" element={<DroneDelivery />} />
          <Route path="/game/neural-network-puzzle" element={<NeuralNetworkPuzzle />} />
          <Route path="/game/retro-racer" element={<RetroRacer />} />
          <Route path="/game/holo-maze-escape" element={<HoloMazeEscape />} />
          <Route path="/game/time-warp-shooter" element={<TimeWarpShooter />} />
          <Route path="/game/circuit-breaker" element={<CircuitBreaker />} />
          <Route path="/game/virtual-pet-simulator" element={<VirtualPetSimulator />} />
          <Route path="/game/quantum-leap-platformer" element={<QuantumLeapPlatformer />} />
          <Route path="/game/pixel-art-creator" element={<PixelArtCreator />} />
          <Route path="/game/space-colony-builder" element={<SpaceColonyBuilder />} />
          <Route path="/game/ai-combat-arena" element={<AICombatArena />} />
          <Route path="/game/cybernetic-farm" element={<CyberneticFarm />} />
          <Route path="/game/stealth-hacker" element={<StealthHacker />} />
          <Route path="/game/gravity-flip-adventure" element={<GravityFlipAdventure />} />
          <Route path="/game/neon-battle-royale" element={<NeonBattleRoyale />} />
          <Route path="/game/data-stream-runner" element={<DataStreamRunner />} />
          <Route path="/game/augmented-reality-quest" element={<AugmentedRealityQuest />} />
          <Route path="/game/biohazard-survival" element={<BiohazardSurvival />} />
          <Route path="/game/code-quest-rpg" element={<CodeQuestRPG />} />
          <Route path="/game/galactic-trader" element={<GalacticTrader />} />
          <Route path="/game/rhythm-racer" element={<RhythmRacer />} />
          <Route path="/game/memory-maze-challenge" element={<MemoryMazeChallenge />} />
          <Route path="/game/cyberpunk-detective" element={<CyberpunkDetective />} />
          <Route path="/game/light-speed-puzzle" element={<LightSpeedPuzzle />} />
          <Route path="/game/virtual-reality-explorer" element={<VirtualRealityExplorer />} />
          <Route path="/game/digital-dungeon-crawler" element={<DigitalDungeonCrawler />} />
          <Route path="/game/synthwave-shooter" element={<SynthwaveShooter />} />
          <Route path="/game/galaga-special-edition" element={<GalagaSpecialEdition />} />
          <Route path="/game/geometry-wars-retro" element={<GeometryWarsRetro />} />
          <Route path="/game/asteroids-reloaded" element={<AsteroidsReloaded />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
