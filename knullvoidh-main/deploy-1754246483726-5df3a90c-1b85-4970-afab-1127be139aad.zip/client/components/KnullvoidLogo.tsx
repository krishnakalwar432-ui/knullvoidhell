import React, { useState } from 'react';
import { motion } from 'framer-motion';

const KnullvoidLogo: React.FC<{ className?: string }> = ({ className = "" }) => {
  const [isHovered, setIsHovered] = useState(false);

  const letterVariants = {
    initial: { 
      opacity: 1,
      y: 0,
      scale: 1,
    },
    animate: {
      opacity: [1, 0.3, 1],
      y: [0, -5, 0],
      scale: [1, 1.1, 1],
      transition: {
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut"
      }
    },
    hover: {
      opacity: [1, 0, 1],
      scale: [1, 0.8, 1.2, 1],
      transition: {
        duration: 0.6,
        ease: "easeInOut"
      }
    }
  };

  const glowVariants = {
    initial: { 
      boxShadow: "0 0 20px #0aff9d50" 
    },
    animate: {
      boxShadow: [
        "0 0 20px #0aff9d50",
        "0 0 40px #0aff9d80",
        "0 0 60px #7000ff50",
        "0 0 40px #0aff9d80",
        "0 0 20px #0aff9d50"
      ],
      transition: {
        duration: 3,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  const letters = "KNULLVOID".split("");

  return (
    <motion.div
      className={`relative inline-block cursor-pointer ${className}`}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      variants={glowVariants}
      initial="initial"
      animate="animate"
    >
      <div className="flex">
        {letters.map((letter, index) => (
          <motion.span
            key={index}
            className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-neon-green via-neon-purple to-neon-pink bg-clip-text text-transparent"
            variants={letterVariants}
            initial="initial"
            animate={isHovered ? "hover" : "animate"}
            custom={index}
            style={{
              animationDelay: `${index * 0.1}s`,
              textShadow: "0 0 20px currentColor"
            }}
          >
            {letter}
          </motion.span>
        ))}
      </div>
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-neon-green/20 via-neon-purple/20 to-neon-pink/20 blur-xl -z-10"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
    </motion.div>
  );
};

export default KnullvoidLogo;
