import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Home, RotateCcw, Pause, Play } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface GameLayoutProps {
  gameTitle: string;
  gameCategory: string;
  score?: number;
  isPlaying?: boolean;
  onPause?: () => void;
  onReset?: () => void;
  children: React.ReactNode;
}

const GameLayout: React.FC<GameLayoutProps> = ({
  gameTitle,
  gameCategory,
  score,
  isPlaying = false,
  onPause,
  onReset,
  children
}) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/90 to-background">
      {/* Game Header */}
      <header className="bg-card/30 backdrop-blur-md border-b border-border/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/">
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-primary">
                  <ArrowLeft className="w-4 h-4 mr-1" />
                  Back
                </Button>
              </Link>
              
              <div className="flex items-center gap-3">
                <h1 className="text-lg font-bold text-foreground">{gameTitle}</h1>
                <Badge variant="secondary" className="text-xs">
                  {gameCategory}
                </Badge>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              {score !== undefined && (
                <div className="text-sm">
                  <span className="text-muted-foreground">Score: </span>
                  <span className="font-bold text-neon-green">{score.toLocaleString()}</span>
                </div>
              )}
              
              <div className="flex gap-2">
                {onPause && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={onPause}
                    className="border-neon-purple/50 text-neon-purple hover:bg-neon-purple/10"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                )}
                
                {onReset && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={onReset}
                    className="border-neon-green/50 text-neon-green hover:bg-neon-green/10"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                )}
                
                <Link to="/">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="border-border/50 hover:border-primary/50"
                  >
                    <Home className="w-4 h-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Game Content */}
      <main className="relative">
        {children}
      </main>
    </div>
  );
};

export default GameLayout;
