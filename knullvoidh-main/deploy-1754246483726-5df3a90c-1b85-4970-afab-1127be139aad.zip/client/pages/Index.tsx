import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import ParticleBackground from '@/components/ParticleBackground';
import KnullvoidLogo from '@/components/KnullvoidLogo';
import GameCard from '@/components/GameCard';
import { games, gameCategories } from '@shared/games';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, Filter, Zap, Smartphone, Globe } from 'lucide-react';
import { Input } from '@/components/ui/input';

const Index: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredGames, setFilteredGames] = useState(games);

  useEffect(() => {
    let filtered = games;
    
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(game => game.category === selectedCategory);
    }
    
    if (searchTerm) {
      filtered = filtered.filter(game => 
        game.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        game.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setFilteredGames(filtered);
  }, [selectedCategory, searchTerm]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  const implementedGames = games.filter(game => game.isImplemented);
  const totalGames = games.length;

  return (
    <div className="min-h-screen relative overflow-hidden">
      <ParticleBackground />
      
      <div className="relative z-10">
        {/* Hero Section */}
        <section className="min-h-screen flex flex-col items-center justify-center px-4 py-20">
          <motion.div
            className="text-center max-w-4xl mx-auto"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            <motion.div variants={itemVariants} className="mb-8">
              <KnullvoidLogo className="mb-6" />
              <motion.h2 
                className="text-xl md:text-2xl text-muted-foreground mb-8"
                variants={itemVariants}
              >
                Experience the future of gaming with cutting-edge 3D interactive entertainment
              </motion.h2>
            </motion.div>

            <motion.div 
              className="flex flex-wrap justify-center gap-4 mb-12"
              variants={itemVariants}
            >
              <Badge className="bg-neon-green/20 text-neon-green border-neon-green/30 px-4 py-2">
                <Zap className="w-4 h-4 mr-2" />
                50 Premium Games
              </Badge>
              <Badge className="bg-neon-purple/20 text-neon-purple border-neon-purple/30 px-4 py-2">
                <Smartphone className="w-4 h-4 mr-2" />
                Mobile Optimized
              </Badge>
              <Badge className="bg-neon-pink/20 text-neon-pink border-neon-pink/30 px-4 py-2">
                <Globe className="w-4 h-4 mr-2" />
                PWA Ready
              </Badge>
            </motion.div>

            <motion.div variants={itemVariants}>
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-neon-green to-neon-purple hover:from-neon-purple hover:to-neon-green text-black font-bold px-8 py-4 text-lg neon-glow"
                onClick={() => document.getElementById('games')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Start Gaming
              </Button>
            </motion.div>
          </motion.div>
        </section>

        {/* Games Section */}
        <section id="games" className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <motion.div
              className="text-center mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-neon-green via-neon-purple to-neon-pink bg-clip-text text-transparent">
                Game Collection
              </h2>
              <p className="text-muted-foreground text-lg mb-8">
                {implementedGames.length} of {totalGames} games available • More coming soon
              </p>
              
              {/* Search and Filter */}
              <div className="flex flex-col md:flex-row gap-4 items-center justify-center mb-8">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search games..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64 bg-card/50 border-border/50 focus:border-primary/50"
                  />
                </div>
                
                <div className="flex gap-2 flex-wrap justify-center">
                  {gameCategories.map((category) => (
                    <Button
                      key={category}
                      variant={selectedCategory === category ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedCategory(category)}
                      className={selectedCategory === category 
                        ? "bg-primary text-primary-foreground" 
                        : "border-border/50 hover:border-primary/50"
                      }
                    >
                      {category}
                    </Button>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Game Grid */}
            <motion.div
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
            >
              {filteredGames.map((game, index) => (
                <GameCard key={game.id} game={game} index={index} />
              ))}
            </motion.div>

            {filteredGames.length === 0 && (
              <motion.div
                className="text-center py-20"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
              >
                <p className="text-muted-foreground text-lg">No games found matching your criteria.</p>
              </motion.div>
            )}
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-20 px-4 border-t border-border/20">
          <div className="max-w-4xl mx-auto text-center">
            <motion.div
              className="grid grid-cols-1 md:grid-cols-3 gap-8"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              <div className="p-6">
                <h3 className="text-3xl font-bold text-neon-green mb-2">{implementedGames.length}</h3>
                <p className="text-muted-foreground">Games Available</p>
              </div>
              <div className="p-6">
                <h3 className="text-3xl font-bold text-neon-purple mb-2">100%</h3>
                <p className="text-muted-foreground">Mobile Compatible</p>
              </div>
              <div className="p-6">
                <h3 className="text-3xl font-bold text-neon-pink mb-2">3D</h3>
                <p className="text-muted-foreground">Interactive Experience</p>
              </div>
            </motion.div>
          </div>
        </section>
      </div>
    </div>
  );
};

export default Index;
