import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import GameLayout from '@/components/GameLayout';
import { Button } from '@/components/ui/button';

interface Card {
  id: number;
  symbol: string;
  isFlipped: boolean;
  isMatched: boolean;
  color: string;
}

const MemoryMatrix: React.FC = () => {
  const [gameState, setGameState] = useState<'playing' | 'paused' | 'gameOver' | 'won'>('playing');
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [score, setScore] = useState(0);
  const [moves, setMoves] = useState(0);
  const [level, setLevel] = useState(1);
  const [timeLeft, setTimeLeft] = useState(60);

  // Cyber-themed symbols and colors
  const symbols = ['🔥', '⚡', '💎', '🌟', '🔮', '⭐', '💫', '✨'];
  const colors = ['#0aff9d', '#7000ff', '#ff0099', '#00ffff', '#ffa500', '#ff6b6b', '#4ecdc4', '#45b7d1'];

  // Initialize game
  const initializeGame = useCallback(() => {
    const cardPairs = level + 3; // Start with 4 pairs, increase with level
    const gameSymbols = symbols.slice(0, cardPairs);
    const gameColors = colors.slice(0, cardPairs);
    
    const newCards: Card[] = [];
    gameSymbols.forEach((symbol, index) => {
      // Add two cards for each symbol
      newCards.push(
        {
          id: index * 2,
          symbol,
          isFlipped: false,
          isMatched: false,
          color: gameColors[index]
        },
        {
          id: index * 2 + 1,
          symbol,
          isFlipped: false,
          isMatched: false,
          color: gameColors[index]
        }
      );
    });

    // Shuffle cards
    for (let i = newCards.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newCards[i], newCards[j]] = [newCards[j], newCards[i]];
    }

    // Reassign IDs to match array indices
    newCards.forEach((card, index) => {
      card.id = index;
    });

    setCards(newCards);
    setFlippedCards([]);
    setMoves(0);
    setTimeLeft(60 - (level - 1) * 5); // Decrease time with level
  }, [level]);

  // Handle card click
  const handleCardClick = (cardId: number) => {
    if (gameState !== 'playing') return;
    if (flippedCards.length >= 2) return;
    if (cards[cardId].isFlipped || cards[cardId].isMatched) return;

    const newFlippedCards = [...flippedCards, cardId];
    setFlippedCards(newFlippedCards);

    // Flip the card
    setCards(prev => prev.map(card => 
      card.id === cardId ? { ...card, isFlipped: true } : card
    ));

    // Check for match when two cards are flipped
    if (newFlippedCards.length === 2) {
      setMoves(prev => prev + 1);
      
      const [firstId, secondId] = newFlippedCards;
      const firstCard = cards[firstId];
      const secondCard = cards[secondId];

      if (firstCard.symbol === secondCard.symbol) {
        // Match found
        setTimeout(() => {
          setCards(prev => prev.map(card => 
            card.id === firstId || card.id === secondId 
              ? { ...card, isMatched: true }
              : card
          ));
          setFlippedCards([]);
          setScore(prev => prev + 100 * level);
        }, 1000);
      } else {
        // No match, flip back after delay
        setTimeout(() => {
          setCards(prev => prev.map(card => 
            card.id === firstId || card.id === secondId 
              ? { ...card, isFlipped: false }
              : card
          ));
          setFlippedCards([]);
        }, 1500);
      }
    }
  };

  // Check for win condition
  useEffect(() => {
    if (cards.length > 0 && cards.every(card => card.isMatched)) {
      setGameState('won');
      const timeBonus = timeLeft * 10;
      setScore(prev => prev + timeBonus);
      
      setTimeout(() => {
        setLevel(prev => prev + 1);
        setGameState('playing');
        initializeGame();
      }, 2000);
    }
  }, [cards, timeLeft, initializeGame]);

  // Timer
  useEffect(() => {
    if (gameState !== 'playing') return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setGameState('gameOver');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState]);

  // Initialize game on mount
  useEffect(() => {
    initializeGame();
  }, [initializeGame]);

  const handlePause = () => {
    setGameState(prev => prev === 'playing' ? 'paused' : 'playing');
  };

  const handleReset = () => {
    setLevel(1);
    setScore(0);
    setGameState('playing');
    initializeGame();
  };

  const cardVariants = {
    hidden: { 
      rotateY: 180, 
      scale: 0.8,
      opacity: 0 
    },
    visible: { 
      rotateY: 0, 
      scale: 1,
      opacity: 1,
      transition: { 
        duration: 0.6,
        ease: "easeOut"
      }
    },
    flipped: { 
      rotateY: 180,
      transition: { 
        duration: 0.3 
      }
    },
    matched: { 
      scale: 1.1,
      transition: { 
        duration: 0.3,
        type: "spring",
        stiffness: 300
      }
    }
  };

  const gridCols = Math.ceil(Math.sqrt(cards.length));

  return (
    <GameLayout
      gameTitle="Memory Card Matrix"
      gameCategory="Puzzle"
      score={score}
      isPlaying={gameState === 'playing'}
      onPause={handlePause}
      onReset={handleReset}
    >
      <div className="min-h-[calc(100vh-64px)] p-4 flex flex-col items-center justify-center">
        {/* Game Stats */}
        <div className="mb-6 flex gap-6 text-center">
          <div className="bg-card/30 backdrop-blur-sm rounded-lg p-4 border border-border/50">
            <div className="text-2xl font-bold text-neon-green">{level}</div>
            <div className="text-sm text-muted-foreground">Level</div>
          </div>
          <div className="bg-card/30 backdrop-blur-sm rounded-lg p-4 border border-border/50">
            <div className="text-2xl font-bold text-neon-purple">{moves}</div>
            <div className="text-sm text-muted-foreground">Moves</div>
          </div>
          <div className="bg-card/30 backdrop-blur-sm rounded-lg p-4 border border-border/50">
            <div className={`text-2xl font-bold ${timeLeft <= 10 ? 'text-red-500' : 'text-neon-pink'}`}>
              {timeLeft}
            </div>
            <div className="text-sm text-muted-foreground">Time</div>
          </div>
        </div>

        {/* Game Grid */}
        <div 
          className="grid gap-3 max-w-2xl mx-auto"
          style={{ 
            gridTemplateColumns: `repeat(${gridCols}, 1fr)`,
            aspectRatio: '1'
          }}
        >
          <AnimatePresence>
            {cards.map((card) => (
              <motion.div
                key={card.id}
                variants={cardVariants}
                initial="hidden"
                animate={card.isMatched ? "matched" : card.isFlipped ? "flipped" : "visible"}
                className="relative cursor-pointer"
                onClick={() => handleCardClick(card.id)}
                style={{ aspectRatio: '1' }}
              >
                <div className="w-full h-full rounded-lg border border-border/50 overflow-hidden relative">
                  {/* Card Back */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-br from-card via-card/80 to-card/60 flex items-center justify-center"
                    animate={{ 
                      opacity: card.isFlipped || card.isMatched ? 0 : 1,
                      rotateY: card.isFlipped || card.isMatched ? 180 : 0
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="text-4xl opacity-50">🔒</div>
                  </motion.div>
                  
                  {/* Card Front */}
                  <motion.div
                    className="absolute inset-0 flex items-center justify-center"
                    style={{ 
                      background: card.isMatched 
                        ? `linear-gradient(135deg, ${card.color}30, ${card.color}10)`
                        : `linear-gradient(135deg, ${card.color}20, transparent)`,
                      boxShadow: card.isMatched 
                        ? `0 0 20px ${card.color}50, inset 0 0 20px ${card.color}30`
                        : 'none'
                    }}
                    animate={{ 
                      opacity: card.isFlipped || card.isMatched ? 1 : 0,
                      rotateY: card.isFlipped || card.isMatched ? 0 : 180
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    <div 
                      className="text-6xl filter drop-shadow-lg"
                      style={{ 
                        textShadow: `0 0 10px ${card.color}` 
                      }}
                    >
                      {card.symbol}
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Game Over / Won Overlay */}
        <AnimatePresence>
          {(gameState === 'gameOver' || gameState === 'won') && (
            <motion.div
              className="fixed inset-0 bg-black/70 flex items-center justify-center z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <motion.div
                className="bg-card border border-border rounded-xl p-8 text-center max-w-md mx-4"
                initial={{ scale: 0.5, y: 50 }}
                animate={{ scale: 1, y: 0 }}
                transition={{ type: "spring", stiffness: 200 }}
              >
                <h2 className={`text-3xl font-bold mb-4 ${
                  gameState === 'won' ? 'text-neon-green' : 'text-red-500'
                }`}>
                  {gameState === 'won' ? 'Level Complete!' : 'Game Over'}
                </h2>
                <p className="text-muted-foreground mb-6">
                  {gameState === 'won' 
                    ? `Amazing! Moving to level ${level + 1}` 
                    : 'Time ran out! Try again?'
                  }
                </p>
                <div className="text-2xl font-bold text-neon-purple mb-6">
                  Final Score: {score.toLocaleString()}
                </div>
                {gameState === 'gameOver' && (
                  <Button 
                    onClick={handleReset}
                    className="bg-gradient-to-r from-neon-green to-neon-purple text-black font-bold"
                  >
                    Play Again
                  </Button>
                )}
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Pause Overlay */}
        <AnimatePresence>
          {gameState === 'paused' && (
            <motion.div
              className="fixed inset-0 bg-black/50 flex items-center justify-center z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <div className="text-6xl font-bold text-white">PAUSED</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </GameLayout>
  );
};

export default MemoryMatrix;
