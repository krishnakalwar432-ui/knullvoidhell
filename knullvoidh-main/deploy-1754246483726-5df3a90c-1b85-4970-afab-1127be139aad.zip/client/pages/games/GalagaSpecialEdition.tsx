import React, { useState, useEffect, useRef, useCallback } from 'react';
import GameLayout from '@/components/GameLayout';

interface Enemy {
  x: number;
  y: number;
  type: 'bee' | 'butterfly' | 'boss';
  health: number;
  speed: number;
  shootTimer: number;
  points: number;
  formation: boolean;
  formationX: number;
  formationY: number;
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  friendly: boolean;
}

interface PowerUp {
  x: number;
  y: number;
  type: 'double' | 'rapid' | 'shield';
  timer: number;
}

const GalagaSpecialEdition: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'playing' | 'paused' | 'gameOver'>('playing');
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [level, setLevel] = useState(1);
  const [playerX, setPlayerX] = useState(400);
  const [enemies, setEnemies] = useState<Enemy[]>([]);
  const [bullets, setBullets] = useState<Bullet[]>([]);
  const [powerUps, setPowerUps] = useState<PowerUp[]>([]);
  const [keys, setKeys] = useState<Set<string>>(new Set());
  const [playerPower, setPlayerPower] = useState({ double: false, rapid: false, shield: false });

  const gameLoopRef = useRef<number>();
  const CANVAS_WIDTH = 800;
  const CANVAS_HEIGHT = 600;

  // Generate enemy formation
  const spawnEnemies = useCallback(() => {
    const newEnemies: Enemy[] = [];
    const baseY = 50;
    
    // Boss row
    for (let i = 0; i < 4; i++) {
      newEnemies.push({
        x: 300 + i * 50,
        y: baseY,
        type: 'boss',
        health: 3,
        speed: 1 + level * 0.2,
        shootTimer: 0,
        points: 400,
        formation: true,
        formationX: 300 + i * 50,
        formationY: baseY
      });
    }
    
    // Butterfly rows
    for (let row = 0; row < 2; row++) {
      for (let i = 0; i < 8; i++) {
        newEnemies.push({
          x: 250 + i * 40,
          y: baseY + (row + 1) * 40,
          type: 'butterfly',
          health: 2,
          speed: 1.5 + level * 0.3,
          shootTimer: 0,
          points: 160,
          formation: true,
          formationX: 250 + i * 40,
          formationY: baseY + (row + 1) * 40
        });
      }
    }
    
    // Bee rows
    for (let row = 0; row < 2; row++) {
      for (let i = 0; i < 10; i++) {
        newEnemies.push({
          x: 200 + i * 40,
          y: baseY + (row + 3) * 40,
          type: 'bee',
          health: 1,
          speed: 2 + level * 0.4,
          shootTimer: 0,
          points: 100,
          formation: true,
          formationX: 200 + i * 40,
          formationY: baseY + (row + 3) * 40
        });
      }
    }
    
    setEnemies(newEnemies);
  }, [level]);

  // Handle input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => new Set([...prev, e.key.toLowerCase()]));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => {
        const newKeys = new Set(prev);
        newKeys.delete(e.key.toLowerCase());
        return newKeys;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    const gameLoop = () => {
      // Move player
      setPlayerX(prev => {
        let newX = prev;
        if (keys.has('a') || keys.has('arrowleft')) newX = Math.max(30, prev - 5);
        if (keys.has('d') || keys.has('arrowright')) newX = Math.min(CANVAS_WIDTH - 30, prev + 5);
        return newX;
      });

      // Player shooting
      if (keys.has(' ')) {
        setBullets(prev => {
          const playerBullets = prev.filter(b => b.friendly);
          const maxBullets = playerPower.rapid ? 5 : playerPower.double ? 2 : 1;
          
          if (playerBullets.length < maxBullets) {
            const newBullets = [{ x: playerX, y: CANVAS_HEIGHT - 50, vx: 0, vy: -8, friendly: true }];
            if (playerPower.double) {
              newBullets.push({ x: playerX - 20, y: CANVAS_HEIGHT - 50, vx: 0, vy: -8, friendly: true });
              newBullets.push({ x: playerX + 20, y: CANVAS_HEIGHT - 50, vx: 0, vy: -8, friendly: true });
            }
            return [...prev, ...newBullets];
          }
          return prev;
        });
      }

      // Update bullets
      setBullets(prev => prev
        .map(bullet => ({
          ...bullet,
          x: bullet.x + bullet.vx,
          y: bullet.y + bullet.vy
        }))
        .filter(bullet => bullet.y > -10 && bullet.y < CANVAS_HEIGHT + 10)
      );

      // Update enemies
      setEnemies(prev => prev.map(enemy => {
        let newEnemy = { ...enemy };
        
        if (enemy.formation) {
          // Formation movement
          const formationOffset = Math.sin(Date.now() * 0.001 + enemy.formationX * 0.01) * 20;
          newEnemy.x = enemy.formationX + formationOffset;
          
          // Occasionally break formation
          if (Math.random() < 0.001) {
            newEnemy.formation = false;
          }
        } else {
          // Attack pattern
          newEnemy.y += enemy.speed;
          newEnemy.x += Math.sin(newEnemy.y * 0.02) * 2;
          
          if (newEnemy.y > CANVAS_HEIGHT) {
            newEnemy.formation = true;
            newEnemy.x = enemy.formationX;
            newEnemy.y = enemy.formationY;
          }
        }
        
        // Enemy shooting
        newEnemy.shootTimer--;
        if (newEnemy.shootTimer <= 0 && Math.random() < 0.002) {
          setBullets(bullets => [...bullets, {
            x: newEnemy.x,
            y: newEnemy.y + 20,
            vx: 0,
            vy: 3,
            friendly: false
          }]);
          newEnemy.shootTimer = 60;
        }
        
        return newEnemy;
      }));

      // Collision detection
      setBullets(prevBullets => {
        let newBullets = [...prevBullets];
        
        setEnemies(prevEnemies => {
          let newEnemies = [...prevEnemies];
          
          newBullets = newBullets.filter(bullet => {
            if (bullet.friendly) {
              const hitEnemyIndex = newEnemies.findIndex(enemy => {
                const dx = enemy.x - bullet.x;
                const dy = enemy.y - bullet.y;
                return Math.sqrt(dx * dx + dy * dy) < 25;
              });
              
              if (hitEnemyIndex !== -1) {
                const enemy = newEnemies[hitEnemyIndex];
                enemy.health--;
                
                if (enemy.health <= 0) {
                  setScore(s => s + enemy.points);
                  
                  // Drop power-up
                  if (Math.random() < 0.1) {
                    setPowerUps(powers => [...powers, {
                      x: enemy.x,
                      y: enemy.y,
                      type: ['double', 'rapid', 'shield'][Math.floor(Math.random() * 3)] as 'double' | 'rapid' | 'shield',
                      timer: 300
                    }]);
                  }
                  
                  newEnemies.splice(hitEnemyIndex, 1);
                }
                
                return false;
              }
            } else {
              // Enemy bullet hit player
              if (!playerPower.shield) {
                const dx = playerX - bullet.x;
                const dy = (CANVAS_HEIGHT - 40) - bullet.y;
                if (Math.sqrt(dx * dx + dy * dy) < 25) {
                  setLives(l => l - 1);
                  return false;
                }
              }
            }
            return true;
          });
          
          return newEnemies;
        });
        
        return newBullets;
      });

      // Update power-ups
      setPowerUps(prev => prev.map(power => ({ ...power, timer: power.timer - 1 })).filter(power => power.timer > 0));

      // Check level completion
      if (enemies.length === 0) {
        setLevel(prev => prev + 1);
        spawnEnemies();
      }

      // Check game over
      if (lives <= 0) {
        setGameState('gameOver');
      }

      gameLoopRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoopRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [gameState, playerX, enemies, bullets, keys, lives, playerPower, spawnEnemies]);

  // Render
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Space background
    ctx.fillStyle = '#000011';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Stars
    for (let i = 0; i < 100; i++) {
      const x = (i * 31) % CANVAS_WIDTH;
      const y = (i * 47) % CANVAS_HEIGHT;
      const brightness = Math.sin(Date.now() * 0.001 + i) * 0.5 + 0.5;
      ctx.fillStyle = `rgba(255, 255, 255, ${brightness * 0.5})`;
      ctx.fillRect(x, y, 1, 1);
    }

    // Draw enemies
    enemies.forEach(enemy => {
      ctx.save();
      ctx.translate(enemy.x, enemy.y);
      
      if (enemy.type === 'boss') {
        ctx.fillStyle = '#ff0099';
        ctx.shadowColor = '#ff0099';
        ctx.shadowBlur = 10;
        ctx.fillRect(-15, -15, 30, 30);
      } else if (enemy.type === 'butterfly') {
        ctx.fillStyle = '#7000ff';
        ctx.shadowColor = '#7000ff';
        ctx.shadowBlur = 8;
        ctx.fillRect(-12, -12, 24, 24);
      } else {
        ctx.fillStyle = '#0aff9d';
        ctx.shadowColor = '#0aff9d';
        ctx.shadowBlur = 6;
        ctx.fillRect(-10, -10, 20, 20);
      }
      
      ctx.shadowBlur = 0;
      ctx.restore();
    });

    // Draw bullets
    bullets.forEach(bullet => {
      ctx.fillStyle = bullet.friendly ? '#ffff00' : '#ff4444';
      ctx.shadowColor = bullet.friendly ? '#ffff00' : '#ff4444';
      ctx.shadowBlur = 5;
      ctx.fillRect(bullet.x - 2, bullet.y - 8, 4, 16);
      ctx.shadowBlur = 0;
    });

    // Draw power-ups
    powerUps.forEach(power => {
      ctx.fillStyle = power.type === 'double' ? '#00ffff' : power.type === 'rapid' ? '#ffff00' : '#ff8800';
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = 8;
      ctx.fillRect(power.x - 8, power.y - 8, 16, 16);
      ctx.shadowBlur = 0;
    });

    // Draw player
    ctx.fillStyle = playerPower.shield ? '#ffffff' : '#0aff9d';
    ctx.shadowColor = '#0aff9d';
    ctx.shadowBlur = 15;
    ctx.fillRect(playerX - 15, CANVAS_HEIGHT - 50, 30, 40);
    ctx.shadowBlur = 0;

    // UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '18px monospace';
    ctx.fillText(`Score: ${score}`, 20, 30);
    ctx.fillText(`Lives: ${lives}`, 20, 55);
    ctx.fillText(`Level: ${level}`, 20, 80);

    if (gameState === 'gameOver') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.fillStyle = '#ff0000';
      ctx.font = '48px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('GAME OVER', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
      ctx.textAlign = 'left';
    }
  });

  useEffect(() => {
    spawnEnemies();
  }, [spawnEnemies]);

  const handlePause = () => {
    setGameState(prev => prev === 'playing' ? 'paused' : 'playing');
  };

  const handleReset = () => {
    setScore(0);
    setLives(3);
    setLevel(1);
    setPlayerX(400);
    setEnemies([]);
    setBullets([]);
    setPowerUps([]);
    setPlayerPower({ double: false, rapid: false, shield: false });
    spawnEnemies();
    setGameState('playing');
  };

  return (
    <GameLayout
      gameTitle="Galaga: Special Edition"
      gameCategory="Arcade"
      score={score}
      isPlaying={gameState === 'playing'}
      onPause={handlePause}
      onReset={handleReset}
    >
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] p-4">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="border border-neon-green/50 rounded-lg bg-black/20 backdrop-blur-sm shadow-2xl max-w-full h-auto"
            style={{ touchAction: 'none' }}
          />
          
          <div className="mt-4 text-center text-sm text-muted-foreground">
            <p>A/D or Arrow keys to move • Space to shoot • Destroy the alien formation!</p>
          </div>
        </div>
      </div>
    </GameLayout>
  );
};

export default GalagaSpecialEdition;
