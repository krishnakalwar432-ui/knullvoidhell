import React, { useState, useEffect, useRef, useCallback } from 'react';
import GameLayout from '@/components/GameLayout';

interface Position {
  x: number;
  y: number;
}

interface Mirror extends Position {
  id: number;
  angle: number;
  type: 'normal' | 'splitter';
}

interface Laser {
  start: Position;
  end: Position;
  color: string;
  active: boolean;
}

interface Target extends Position {
  id: number;
  active: boolean;
  color: string;
}

const LaserDeflector: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'playing' | 'paused' | 'levelComplete'>('playing');
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [mirrors, setMirrors] = useState<Mirror[]>([]);
  const [targets, setTargets] = useState<Target[]>([]);
  const [lasers, setLasers] = useState<Laser[]>([]);
  const [selectedMirror, setSelectedMirror] = useState<number | null>(null);
  const [laserSource] = useState<Position>({ x: 50, y: 300 });

  const CANVAS_WIDTH = 800;
  const CANVAS_HEIGHT = 600;
  const GRID_SIZE = 40;

  // Initialize level
  const initializeLevel = useCallback(() => {
    const newMirrors: Mirror[] = [];
    const newTargets: Target[] = [];
    
    // Add mirrors based on level
    for (let i = 0; i < 3 + level; i++) {
      newMirrors.push({
        id: i,
        x: 200 + (i % 3) * 150,
        y: 150 + Math.floor(i / 3) * 120,
        angle: 45,
        type: Math.random() > 0.8 ? 'splitter' : 'normal'
      });
    }

    // Add targets
    for (let i = 0; i < 2 + Math.floor(level / 2); i++) {
      newTargets.push({
        id: i,
        x: 650 + (i % 2) * 80,
        y: 200 + i * 100,
        active: false,
        color: ['#0aff9d', '#7000ff', '#ff0099'][i % 3]
      });
    }

    setMirrors(newMirrors);
    setTargets(newTargets);
  }, [level]);

  // Calculate laser paths
  const calculateLasers = useCallback(() => {
    const newLasers: Laser[] = [];
    const maxReflections = 20;
    
    // Start laser from source
    let currentPos = { ...laserSource };
    let direction = { x: 1, y: 0 }; // Start going right
    let color = '#ff0000';
    
    for (let reflection = 0; reflection < maxReflections; reflection++) {
      // Find next intersection
      let closestDistance = Infinity;
      let closestMirror: Mirror | null = null;
      let intersection: Position | null = null;

      // Check collision with mirrors
      mirrors.forEach(mirror => {
        const mirrorCenter = { x: mirror.x, y: mirror.y };
        const dx = mirrorCenter.x - currentPos.x;
        const dy = mirrorCenter.y - currentPos.y;
        
        // Simple intersection check (within mirror bounds)
        if (Math.abs(dx) < 20 && Math.abs(dy) < 20) {
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < closestDistance && distance > 5) {
            closestDistance = distance;
            closestMirror = mirror;
            intersection = mirrorCenter;
          }
        }
      });

      // If no mirror hit, go to edge
      if (!intersection) {
        const edgeX = direction.x > 0 ? CANVAS_WIDTH : 0;
        const edgeY = direction.y > 0 ? CANVAS_HEIGHT : 0;
        
        if (Math.abs(direction.x) > Math.abs(direction.y)) {
          intersection = { x: edgeX, y: currentPos.y + direction.y * (edgeX - currentPos.x) / direction.x };
        } else {
          intersection = { x: currentPos.x + direction.x * (edgeY - currentPos.y) / direction.y, y: edgeY };
        }
      }

      // Add laser segment
      newLasers.push({
        start: { ...currentPos },
        end: intersection,
        color,
        active: true
      });

      // Check if laser hits target
      targets.forEach(target => {
        const distToTarget = Math.sqrt(
          Math.pow(intersection!.x - target.x, 2) + Math.pow(intersection!.y - target.y, 2)
        );
        if (distToTarget < 25) {
          setTargets(prev => prev.map(t => 
            t.id === target.id ? { ...t, active: true } : t
          ));
        }
      });

      if (!closestMirror) break;

      // Reflect direction based on mirror angle
      const mirrorAngleRad = (closestMirror.angle * Math.PI) / 180;
      const normalX = Math.cos(mirrorAngleRad + Math.PI / 2);
      const normalY = Math.sin(mirrorAngleRad + Math.PI / 2);
      
      // Reflect direction vector
      const dot = direction.x * normalX + direction.y * normalY;
      direction.x = direction.x - 2 * dot * normalX;
      direction.y = direction.y - 2 * dot * normalY;
      
      currentPos = intersection;
    }

    setLasers(newLasers);
  }, [mirrors, targets, laserSource]);

  // Handle canvas click
  const handleCanvasClick = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * CANVAS_WIDTH;
    const y = ((e.clientY - rect.top) / rect.height) * CANVAS_HEIGHT;

    // Find clicked mirror
    const clickedMirror = mirrors.find(mirror => {
      const dx = mirror.x - x;
      const dy = mirror.y - y;
      return Math.sqrt(dx * dx + dy * dy) < 25;
    });

    if (clickedMirror) {
      setSelectedMirror(clickedMirror.id);
    } else {
      setSelectedMirror(null);
    }
  };

  // Rotate selected mirror
  const rotateMirror = useCallback((direction: number) => {
    if (selectedMirror === null) return;
    
    setMirrors(prev => prev.map(mirror => 
      mirror.id === selectedMirror 
        ? { ...mirror, angle: (mirror.angle + direction * 15) % 360 }
        : mirror
    ));
  }, [selectedMirror]);

  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
        case 'a':
          rotateMirror(-1);
          break;
        case 'ArrowRight':
        case 'd':
          rotateMirror(1);
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [rotateMirror]);

  // Check win condition
  useEffect(() => {
    const allTargetsActive = targets.length > 0 && targets.every(target => target.active);
    if (allTargetsActive && gameState === 'playing') {
      setScore(prev => prev + level * 100);
      setGameState('levelComplete');
      setTimeout(() => {
        setLevel(prev => prev + 1);
        setGameState('playing');
        initializeLevel();
      }, 2000);
    }
  }, [targets, gameState, level, initializeLevel]);

  // Update lasers when mirrors change
  useEffect(() => {
    calculateLasers();
  }, [mirrors, calculateLasers]);

  // Render game
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw grid
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1;
    for (let x = 0; x < CANVAS_WIDTH; x += GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, CANVAS_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y < CANVAS_HEIGHT; y += GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(CANVAS_WIDTH, y);
      ctx.stroke();
    }

    // Draw laser source
    ctx.fillStyle = '#ff0000';
    ctx.shadowColor = '#ff0000';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(laserSource.x, laserSource.y, 15, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Draw lasers
    lasers.forEach(laser => {
      ctx.strokeStyle = laser.color;
      ctx.lineWidth = 3;
      ctx.shadowColor = laser.color;
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.moveTo(laser.start.x, laser.start.y);
      ctx.lineTo(laser.end.x, laser.end.y);
      ctx.stroke();
      ctx.shadowBlur = 0;
    });

    // Draw mirrors
    mirrors.forEach(mirror => {
      ctx.save();
      ctx.translate(mirror.x, mirror.y);
      ctx.rotate((mirror.angle * Math.PI) / 180);
      
      const isSelected = selectedMirror === mirror.id;
      ctx.strokeStyle = isSelected ? '#0aff9d' : '#7000ff';
      ctx.lineWidth = isSelected ? 4 : 3;
      ctx.shadowColor = ctx.strokeStyle;
      ctx.shadowBlur = isSelected ? 15 : 10;
      
      if (mirror.type === 'splitter') {
        // Draw beam splitter
        ctx.beginPath();
        ctx.moveTo(-20, 0);
        ctx.lineTo(20, 0);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, -20);
        ctx.lineTo(0, 20);
        ctx.stroke();
      } else {
        // Draw regular mirror
        ctx.beginPath();
        ctx.moveTo(-20, 0);
        ctx.lineTo(20, 0);
        ctx.stroke();
      }
      
      ctx.restore();
      ctx.shadowBlur = 0;
    });

    // Draw targets
    targets.forEach(target => {
      ctx.fillStyle = target.active ? target.color : '#333';
      ctx.strokeStyle = target.color;
      ctx.lineWidth = 2;
      ctx.shadowColor = target.active ? target.color : 'transparent';
      ctx.shadowBlur = target.active ? 15 : 0;
      
      ctx.beginPath();
      ctx.arc(target.x, target.y, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.shadowBlur = 0;
    });

    // Draw UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px monospace';
    ctx.fillText(`Level: ${level}`, 20, 30);
    ctx.fillText(`Score: ${score}`, 20, 50);
    
    if (selectedMirror !== null) {
      ctx.fillText('A/D or ←/→ to rotate mirror', 20, CANVAS_HEIGHT - 20);
    } else {
      ctx.fillText('Click mirror to select', 20, CANVAS_HEIGHT - 20);
    }

    if (gameState === 'levelComplete') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.fillStyle = '#0aff9d';
      ctx.font = '48px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('LEVEL COMPLETE!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
      ctx.textAlign = 'left';
    }

    if (gameState === 'paused') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.fillStyle = '#ffffff';
      ctx.font = '48px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('PAUSED', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
      ctx.textAlign = 'left';
    }
  });

  useEffect(() => {
    initializeLevel();
  }, [initializeLevel]);

  const handlePause = () => {
    setGameState(prev => prev === 'playing' ? 'paused' : 'playing');
  };

  const handleReset = () => {
    setScore(0);
    setLevel(1);
    setSelectedMirror(null);
    setGameState('playing');
    initializeLevel();
  };

  return (
    <GameLayout
      gameTitle="Laser Deflector"
      gameCategory="Puzzle"
      score={score}
      isPlaying={gameState === 'playing'}
      onPause={handlePause}
      onReset={handleReset}
    >
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] p-4">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="border border-neon-purple/50 rounded-lg bg-black/20 backdrop-blur-sm shadow-2xl max-w-full h-auto"
            onClick={handleCanvasClick}
            style={{ touchAction: 'none' }}
          />
          
          <div className="mt-4 text-center text-sm text-muted-foreground">
            <p>Click mirrors to select • A/D keys to rotate • Hit all targets</p>
          </div>
        </div>
      </div>
    </GameLayout>
  );
};

export default LaserDeflector;
