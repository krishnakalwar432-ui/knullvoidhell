import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface Player {
  id: string;
  x: number;
  y: number;
  health: number;
  maxHealth: number;
  weapon: 'pistol' | 'rifle' | 'shotgun';
  ammo: number;
  kills: number;
  color: string;
  isAlive: boolean;
  shield: number;
}

interface Enemy {
  id: string;
  x: number;
  y: number;
  health: number;
  weapon: string;
  color: string;
  ai: 'aggressive' | 'defensive' | 'hunter';
  target: string | null;
}

interface Bullet {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  owner: string;
  color: string;
}

interface Loot {
  id: string;
  x: number;
  y: number;
  type: 'weapon' | 'ammo' | 'health' | 'shield';
  value: any;
  color: string;
}

const ARENA_SIZE = 800;
const SHRINK_RATE = 0.5;

export default function NeonBattleRoyale() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [player] = useState<Player>({
    id: 'player',
    x: ARENA_SIZE / 2,
    y: ARENA_SIZE / 2,
    health: 100,
    maxHealth: 100,
    weapon: 'pistol',
    ammo: 30,
    kills: 0,
    color: '#0aff9d',
    isAlive: true,
    shield: 0
  });
  const [enemies, setEnemies] = useState<Enemy[]>([]);
  const [bullets, setBullets] = useState<Bullet[]>([]);
  const [loot, setLoot] = useState<Loot[]>([]);
  const [safeZoneRadius, setSafeZoneRadius] = useState(ARENA_SIZE / 2);
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [gamePhase, setGamePhase] = useState<'dropping' | 'fighting' | 'won' | 'lost'>('dropping');

  const spawnEnemies = useCallback(() => {
    const newEnemies: Enemy[] = [];
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2;
      const distance = 200 + Math.random() * 200;
      newEnemies.push({
        id: `enemy-${i}`,
        x: ARENA_SIZE/2 + Math.cos(angle) * distance,
        y: ARENA_SIZE/2 + Math.sin(angle) * distance,
        health: 80 + Math.random() * 40,
        weapon: ['pistol', 'rifle', 'shotgun'][Math.floor(Math.random() * 3)],
        color: `hsl(${Math.random() * 360}, 70%, 60%)`,
        ai: ['aggressive', 'defensive', 'hunter'][Math.floor(Math.random() * 3)] as any,
        target: null
      });
    }
    setEnemies(newEnemies);
  }, []);

  const startGame = () => {
    setScore(0);
    setGamePhase('fighting');
    setSafeZoneRadius(ARENA_SIZE / 2);
    spawnEnemies();
    setIsPlaying(true);
    setIsPaused(false);
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // Dark background
    ctx.fillStyle = '#000814';
    ctx.fillRect(0, 0, ARENA_SIZE, ARENA_SIZE);

    // Neon grid
    ctx.strokeStyle = '#0066ff';
    ctx.lineWidth = 1;
    for (let i = 0; i <= ARENA_SIZE; i += 50) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, ARENA_SIZE);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(ARENA_SIZE, i);
      ctx.stroke();
    }

    // Safe zone
    ctx.strokeStyle = '#00ffff';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(ARENA_SIZE/2, ARENA_SIZE/2, safeZoneRadius, 0, Math.PI * 2);
    ctx.stroke();

    // Player
    if (player.isAlive) {
      ctx.fillStyle = player.color;
      ctx.shadowColor = player.color;
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(player.x, player.y, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    // UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.fillText(`Health: ${player.health}`, 10, 30);
    ctx.fillText(`Ammo: ${player.ammo}`, 10, 50);
    ctx.fillText(`Kills: ${player.kills}`, 10, 70);
    ctx.fillText(`Enemies: ${enemies.filter(e => e.health > 0).length}`, 10, 90);

    if (gamePhase === 'won') {
      ctx.fillStyle = '#0aff9d';
      ctx.font = '48px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('VICTORY ROYALE!', ARENA_SIZE/2, ARENA_SIZE/2);
    }
  }, [player, enemies, safeZoneRadius, gamePhase]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: true }));
    const handleKeyUp = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: false }));
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Neon Battle Royale"
      description="Last player standing in the neon arena!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={ARENA_SIZE}
          height={ARENA_SIZE}
          className="border-2 border-neon-green rounded-lg max-w-full h-auto"
        />
        <div className="text-center text-sm text-gray-400 max-w-md">
          WASD to move, mouse to aim, click to shoot. Stay in the safe zone!
        </div>
      </div>
    </GameLayout>
  );
}
