import React, { useState, useEffect, useRef, useCallback } from 'react';
import GameLayout from '@/components/GameLayout';

interface Position {
  x: number;
  y: number;
}

interface Car extends Position {
  vx: number;
  vy: number;
  angle: number;
  speed: number;
  maxSpeed: number;
  color: string;
}

interface Particle extends Position {
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}

interface Checkpoint extends Position {
  id: number;
  passed: boolean;
  angle: number;
}

const NanoRacing: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'playing' | 'paused' | 'finished'>('playing');
  const [score, setScore] = useState(0);
  const [lap, setLap] = useState(1);
  const [speed, setSpeed] = useState(0);
  const [lapTime, setLapTime] = useState(0);
  const [bestLap, setBestLap] = useState(0);
  const [car, setCar] = useState<Car>({
    x: 400,
    y: 500,
    vx: 0,
    vy: 0,
    angle: 0,
    speed: 0,
    maxSpeed: 8,
    color: '#0aff9d'
  });
  const [particles, setParticles] = useState<Particle[]>([]);
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>([]);
  const [keys, setKeys] = useState<Set<string>>(new Set());
  const [currentCheckpoint, setCurrentCheckpoint] = useState(0);

  const gameLoopRef = useRef<number>();
  const frameCount = useRef(0);

  const CANVAS_WIDTH = 800;
  const CANVAS_HEIGHT = 600;

  // Create particles for exhaust
  const createExhaust = useCallback((x: number, y: number, angle: number) => {
    const exhaustAngle = angle + Math.PI;
    const newParticles: Particle[] = [];
    
    for (let i = 0; i < 3; i++) {
      newParticles.push({
        x: x + Math.cos(exhaustAngle) * 15 + (Math.random() - 0.5) * 8,
        y: y + Math.sin(exhaustAngle) * 15 + (Math.random() - 0.5) * 8,
        vx: Math.cos(exhaustAngle) * (2 + Math.random() * 3),
        vy: Math.sin(exhaustAngle) * (2 + Math.random() * 3),
        life: 1.0,
        color: car.speed > 4 ? '#ff6600' : '#ffffff',
        size: 2 + Math.random() * 2
      });
    }
    
    setParticles(prev => [...prev, ...newParticles]);
  }, [car.speed]);

  // Initialize race track
  const initializeTrack = useCallback(() => {
    const newCheckpoints: Checkpoint[] = [];
    const numCheckpoints = 8;
    const centerX = CANVAS_WIDTH / 2;
    const centerY = CANVAS_HEIGHT / 2;
    const radiusX = 280;
    const radiusY = 200;

    for (let i = 0; i < numCheckpoints; i++) {
      const angle = (i / numCheckpoints) * Math.PI * 2;
      newCheckpoints.push({
        id: i,
        x: centerX + Math.cos(angle) * radiusX,
        y: centerY + Math.sin(angle) * radiusY,
        passed: false,
        angle
      });
    }

    setCheckpoints(newCheckpoints);
  }, []);

  // Handle input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => new Set([...prev, e.key.toLowerCase()]));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => {
        const newKeys = new Set(prev);
        newKeys.delete(e.key.toLowerCase());
        return newKeys;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Touch controls
  const handleTouchStart = (e: React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    const x = ((touch.clientX - rect.left) / rect.width) * CANVAS_WIDTH;
    const y = ((touch.clientY - rect.top) / rect.height) * CANVAS_HEIGHT;

    // Simple touch control - accelerate and steer towards touch
    const dx = x - car.x;
    const dy = y - car.y;
    const targetAngle = Math.atan2(dy, dx);
    
    setCar(prev => ({
      ...prev,
      angle: targetAngle,
      speed: Math.min(prev.speed + 0.3, prev.maxSpeed)
    }));
  };

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    const gameLoop = () => {
      frameCount.current++;
      
      // Update car physics
      setCar(prev => {
        let newSpeed = prev.speed;
        let newAngle = prev.angle;
        
        // Handle input
        if (keys.has('arrowup') || keys.has('w')) {
          newSpeed = Math.min(newSpeed + 0.2, prev.maxSpeed);
        }
        if (keys.has('arrowdown') || keys.has('s')) {
          newSpeed = Math.max(newSpeed - 0.3, -prev.maxSpeed * 0.5);
        }
        if (keys.has('arrowleft') || keys.has('a')) {
          newAngle -= 0.08 * (newSpeed / prev.maxSpeed);
        }
        if (keys.has('arrowright') || keys.has('d')) {
          newAngle += 0.08 * (newSpeed / prev.maxSpeed);
        }

        // Apply friction
        newSpeed *= 0.98;

        // Calculate velocity
        const newVx = Math.cos(newAngle) * newSpeed;
        const newVy = Math.sin(newAngle) * newSpeed;

        // Update position
        let newX = prev.x + newVx;
        let newY = prev.y + newVy;

        // Simple track boundaries (elliptical)
        const centerX = CANVAS_WIDTH / 2;
        const centerY = CANVAS_HEIGHT / 2;
        const trackRadiusX = 320;
        const trackRadiusY = 240;
        const innerRadiusX = 180;
        const innerRadiusY = 120;

        const dx = newX - centerX;
        const dy = newY - centerY;
        const outerDist = (dx * dx) / (trackRadiusX * trackRadiusX) + (dy * dy) / (trackRadiusY * trackRadiusY);
        const innerDist = (dx * dx) / (innerRadiusX * innerRadiusX) + (dy * dy) / (innerRadiusY * innerRadiusY);

        // Collision with outer boundary
        if (outerDist > 1) {
          const angle = Math.atan2(dy, dx);
          newX = centerX + Math.cos(angle) * trackRadiusX * 0.95;
          newY = centerY + Math.sin(angle) * trackRadiusY * 0.95;
          newSpeed *= 0.3; // Slow down on collision
        }

        // Collision with inner boundary
        if (innerDist < 1) {
          const angle = Math.atan2(dy, dx);
          newX = centerX + Math.cos(angle) * innerRadiusX * 1.05;
          newY = centerY + Math.sin(angle) * innerRadiusY * 1.05;
          newSpeed *= 0.3; // Slow down on collision
        }

        return {
          ...prev,
          x: newX,
          y: newY,
          vx: newVx,
          vy: newVy,
          speed: newSpeed,
          angle: newAngle
        };
      });

      // Create exhaust particles
      if (car.speed > 1) {
        createExhaust(car.x, car.y, car.angle);
      }

      // Update particles
      setParticles(prev => prev
        .map(p => ({
          ...p,
          x: p.x + p.vx,
          y: p.y + p.vy,
          vx: p.vx * 0.95,
          vy: p.vy * 0.95,
          life: p.life - 0.02,
          size: p.size * 0.98
        }))
        .filter(p => p.life > 0)
      );

      // Check checkpoint collisions
      setCheckpoints(prev => {
        const newCheckpoints = [...prev];
        const currentCP = newCheckpoints[currentCheckpoint];
        
        if (currentCP && !currentCP.passed) {
          const dx = car.x - currentCP.x;
          const dy = car.y - currentCP.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 30) {
            newCheckpoints[currentCheckpoint] = { ...currentCP, passed: true };
            setScore(s => s + 100);
            
            // Check if all checkpoints passed
            const nextCheckpoint = (currentCheckpoint + 1) % newCheckpoints.length;
            if (nextCheckpoint === 0 && currentCheckpoint === newCheckpoints.length - 1) {
              // Completed lap
              const currentLapTime = frameCount.current;
              setLapTime(currentLapTime);
              if (bestLap === 0 || currentLapTime < bestLap) {
                setBestLap(currentLapTime);
              }
              setLap(l => l + 1);
              setScore(s => s + 1000);
              frameCount.current = 0;
              
              // Reset checkpoints
              return newCheckpoints.map(cp => ({ ...cp, passed: false }));
            }
            
            setCurrentCheckpoint(nextCheckpoint);
          }
        }
        
        return newCheckpoints;
      });

      // Update speed display
      setSpeed(Math.abs(car.speed));

      gameLoopRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoopRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [gameState, keys, car, currentCheckpoint, createExhaust, bestLap]);

  // Render game
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#0a0a0f';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw track
    const centerX = CANVAS_WIDTH / 2;
    const centerY = CANVAS_HEIGHT / 2;
    
    // Outer track boundary
    ctx.strokeStyle = '#0aff9d';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.ellipse(centerX, centerY, 320, 240, 0, 0, Math.PI * 2);
    ctx.stroke();
    
    // Inner track boundary
    ctx.strokeStyle = '#7000ff';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.ellipse(centerX, centerY, 180, 120, 0, 0, Math.PI * 2);
    ctx.stroke();

    // Draw track surface with grid
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1;
    ctx.globalAlpha = 0.3;
    for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 8) {
      ctx.beginPath();
      ctx.moveTo(centerX + Math.cos(angle) * 180, centerY + Math.sin(angle) * 120);
      ctx.lineTo(centerX + Math.cos(angle) * 320, centerY + Math.sin(angle) * 240);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    // Draw checkpoints
    checkpoints.forEach((checkpoint, index) => {
      const isActive = index === currentCheckpoint;
      const isPassed = checkpoint.passed;
      
      ctx.fillStyle = isPassed ? '#00ff00' : isActive ? '#ffff00' : '#ff0099';
      ctx.shadowColor = ctx.fillStyle;
      ctx.shadowBlur = isActive ? 15 : 5;
      
      ctx.beginPath();
      ctx.arc(checkpoint.x, checkpoint.y, isActive ? 12 : 8, 0, Math.PI * 2);
      ctx.fill();
      
      // Checkpoint number
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px monospace';
      ctx.textAlign = 'center';
      ctx.shadowBlur = 0;
      ctx.fillText((index + 1).toString(), checkpoint.x, checkpoint.y + 4);
    });

    // Draw particles
    particles.forEach(particle => {
      ctx.globalAlpha = particle.life;
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;

    // Draw car
    ctx.save();
    ctx.translate(car.x, car.y);
    ctx.rotate(car.angle);
    
    ctx.fillStyle = car.color;
    ctx.shadowColor = car.color;
    ctx.shadowBlur = 10;
    ctx.fillRect(-8, -4, 16, 8);
    
    // Car details
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(4, -2, 4, 4); // Front
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(-8, -1, 2, 2); // Rear lights
    
    ctx.restore();
    ctx.shadowBlur = 0;

    // Draw speedometer
    const speedometerX = CANVAS_WIDTH - 120;
    const speedometerY = CANVAS_HEIGHT - 120;
    const speedPercentage = speed / car.maxSpeed;
    
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(speedometerX, speedometerY, 40, Math.PI, Math.PI * 2);
    ctx.stroke();
    
    ctx.strokeStyle = speed > car.maxSpeed * 0.8 ? '#ff0000' : '#0aff9d';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(speedometerX, speedometerY, 40, Math.PI, Math.PI + speedPercentage * Math.PI);
    ctx.stroke();
    
    // Speed text
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(Math.floor(speed * 10).toString(), speedometerX, speedometerY + 5);
    ctx.font = '10px monospace';
    ctx.fillText('km/h', speedometerX, speedometerY + 20);

    // Draw UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '18px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`Lap: ${lap}`, 20, 30);
    ctx.fillText(`Score: ${score.toLocaleString()}`, 20, 55);
    ctx.fillText(`Time: ${(frameCount.current / 60).toFixed(1)}s`, 20, 80);
    
    if (bestLap > 0) {
      ctx.fillText(`Best: ${(bestLap / 60).toFixed(1)}s`, 20, 105);
    }
    
    ctx.fillText(`Next: Checkpoint ${currentCheckpoint + 1}`, 20, 130);

    if (gameState === 'paused') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.fillStyle = '#ffffff';
      ctx.font = '48px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('PAUSED', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
    }
  });

  useEffect(() => {
    initializeTrack();
  }, [initializeTrack]);

  const handlePause = () => {
    setGameState(prev => prev === 'playing' ? 'paused' : 'playing');
  };

  const handleReset = () => {
    setScore(0);
    setLap(1);
    setSpeed(0);
    setLapTime(0);
    setBestLap(0);
    setCurrentCheckpoint(0);
    frameCount.current = 0;
    setCar({
      x: 400,
      y: 500,
      vx: 0,
      vy: 0,
      angle: 0,
      speed: 0,
      maxSpeed: 8,
      color: '#0aff9d'
    });
    setParticles([]);
    initializeTrack();
    setGameState('playing');
  };

  return (
    <GameLayout
      gameTitle="Nano Racing"
      gameCategory="Racing"
      score={score}
      isPlaying={gameState === 'playing'}
      onPause={handlePause}
      onReset={handleReset}
    >
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] p-4">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="border border-neon-green/50 rounded-lg bg-black/20 backdrop-blur-sm shadow-2xl max-w-full h-auto"
            onTouchStart={handleTouchStart}
            style={{ touchAction: 'none' }}
          />
          
          <div className="mt-4 text-center text-sm text-muted-foreground">
            <p className="md:hidden">Touch to steer and accelerate</p>
            <p className="hidden md:block">WASD or Arrow keys to drive • Hit checkpoints in order</p>
          </div>
        </div>
      </div>
    </GameLayout>
  );
};

export default NanoRacing;
