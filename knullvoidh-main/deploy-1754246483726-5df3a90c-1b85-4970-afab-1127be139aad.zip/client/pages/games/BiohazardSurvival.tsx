import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface Player {
  x: number;
  y: number;
  health: number;
  oxygen: number;
  radiation: number;
  hasHazmatSuit: boolean;
  hasMask: boolean;
}

interface Hazard {
  x: number;
  y: number;
  type: 'radiation' | 'toxic_gas' | 'acid_pool';
  intensity: number;
  color: string;
  radius: number;
}

interface Supply {
  x: number;
  y: number;
  type: 'oxygen' | 'medicine' | 'hazmat_suit' | 'mask';
  collected: boolean;
  color: string;
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;

export default function BiohazardSurvival() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [player, setPlayer] = useState<Player>({
    x: 50,
    y: 50,
    health: 100,
    oxygen: 100,
    radiation: 0,
    hasHazmatSuit: false,
    hasMask: false
  });
  const [hazards, setHazards] = useState<Hazard[]>([]);
  const [supplies, setSupplies] = useState<Supply[]>([]);
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});
  const [gameTime, setGameTime] = useState(0);
  const [evacuationZone, setEvacuationZone] = useState({ x: GAME_WIDTH - 100, y: GAME_HEIGHT - 100, active: false });

  const spawnHazard = useCallback(() => {
    const types: Hazard['type'][] = ['radiation', 'toxic_gas', 'acid_pool'];
    const type = types[Math.floor(Math.random() * types.length)];
    const colors = { radiation: '#00ff00', toxic_gas: '#ffff00', acid_pool: '#ff0099' };
    
    const newHazard: Hazard = {
      x: Math.random() * GAME_WIDTH,
      y: Math.random() * GAME_HEIGHT,
      type,
      intensity: 1 + Math.random() * 3,
      color: colors[type],
      radius: 30 + Math.random() * 40
    };
    
    setHazards(prev => [...prev, newHazard]);
  }, []);

  const spawnSupply = useCallback(() => {
    const types: Supply['type'][] = ['oxygen', 'medicine', 'hazmat_suit', 'mask'];
    const type = types[Math.floor(Math.random() * types.length)];
    const colors = { oxygen: '#00ffff', medicine: '#ff6600', hazmat_suit: '#ffff00', mask: '#0066ff' };
    
    const newSupply: Supply = {
      x: Math.random() * (GAME_WIDTH - 40) + 20,
      y: Math.random() * (GAME_HEIGHT - 40) + 20,
      type,
      collected: false,
      color: colors[type]
    };
    
    setSupplies(prev => [...prev, newSupply]);
  }, []);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused) return;

    setGameTime(prev => prev + 1);

    // Move player
    setPlayer(prev => {
      let newX = prev.x;
      let newY = prev.y;
      let newHealth = prev.health;
      let newOxygen = prev.oxygen;
      let newRadiation = prev.radiation;

      if (keys['ArrowLeft'] || keys['a']) newX -= 3;
      if (keys['ArrowRight'] || keys['d']) newX += 3;
      if (keys['ArrowUp'] || keys['w']) newY -= 3;
      if (keys['ArrowDown'] || keys['s']) newY += 3;

      newX = Math.max(10, Math.min(GAME_WIDTH - 10, newX));
      newY = Math.max(10, Math.min(GAME_HEIGHT - 10, newY));

      // Environmental damage
      if (!prev.hasMask) newOxygen -= 0.2;
      if (newRadiation > 50 && !prev.hasHazmatSuit) newHealth -= 0.5;

      // Check hazard exposure
      hazards.forEach(hazard => {
        const distance = Math.sqrt((hazard.x - newX) ** 2 + (hazard.y - newY) ** 2);
        if (distance < hazard.radius) {
          switch (hazard.type) {
            case 'radiation':
              if (!prev.hasHazmatSuit) newRadiation += hazard.intensity;
              break;
            case 'toxic_gas':
              if (!prev.hasMask) {
                newOxygen -= hazard.intensity * 2;
                newHealth -= hazard.intensity * 0.5;
              }
              break;
            case 'acid_pool':
              newHealth -= hazard.intensity;
              break;
          }
        }
      });

      // Check supply collection
      supplies.forEach(supply => {
        if (!supply.collected) {
          const distance = Math.sqrt((supply.x - newX) ** 2 + (supply.y - newY) ** 2);
          if (distance < 20) {
            supply.collected = true;
            setScore(s => s + 50);
            
            switch (supply.type) {
              case 'oxygen':
                newOxygen = Math.min(100, newOxygen + 40);
                break;
              case 'medicine':
                newHealth = Math.min(100, newHealth + 30);
                newRadiation = Math.max(0, newRadiation - 20);
                break;
              case 'hazmat_suit':
                return { ...prev, x: newX, y: newY, hasHazmatSuit: true };
              case 'mask':
                return { ...prev, x: newX, y: newY, hasMask: true };
            }
          }
        }
      });

      // Check evacuation zone
      const distToEvac = Math.sqrt(
        (evacuationZone.x - newX) ** 2 + (evacuationZone.y - newY) ** 2
      );
      if (distToEvac < 50 && evacuationZone.active) {
        setScore(s => s + 1000);
        setIsPlaying(false);
      }

      return {
        ...prev,
        x: newX,
        y: newY,
        health: Math.max(0, newHealth),
        oxygen: Math.max(0, newOxygen),
        radiation: Math.min(100, newRadiation)
      };
    });

    // Spawn elements
    if (gameTime % 180 === 0) spawnHazard();
    if (gameTime % 240 === 0) spawnSupply();

    // Activate evacuation after 30 seconds
    if (gameTime > 1800) {
      setEvacuationZone(prev => ({ ...prev, active: true }));
    }

    // Check game over
    if (player.health <= 0 || player.oxygen <= 0) {
      setIsPlaying(false);
    }

  }, [isPlaying, isPaused, keys, gameTime, player, hazards, supplies, evacuationZone, spawnHazard, spawnSupply]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // Contaminated environment
    ctx.fillStyle = '#1a0f0f';
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Contamination overlay
    ctx.fillStyle = 'rgba(0, 100, 0, 0.1)';
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Hazards
    hazards.forEach(hazard => {
      ctx.save();
      ctx.globalAlpha = 0.6;
      ctx.fillStyle = hazard.color;
      ctx.shadowColor = hazard.color;
      ctx.shadowBlur = 20;
      ctx.beginPath();
      ctx.arc(hazard.x, hazard.y, hazard.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    // Supplies
    supplies.forEach(supply => {
      if (!supply.collected) {
        ctx.fillStyle = supply.color;
        ctx.shadowColor = supply.color;
        ctx.shadowBlur = 10;
        ctx.fillRect(supply.x - 8, supply.y - 8, 16, 16);
        ctx.shadowBlur = 0;
      }
    });

    // Evacuation zone
    if (evacuationZone.active) {
      ctx.strokeStyle = '#00ff00';
      ctx.lineWidth = 3;
      ctx.setLineDash([10, 10]);
      ctx.beginPath();
      ctx.arc(evacuationZone.x, evacuationZone.y, 50, 0, Math.PI * 2);
      ctx.stroke();
      ctx.setLineDash([]);
      
      ctx.fillStyle = '#00ff00';
      ctx.font = '14px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('EVACUATION', evacuationZone.x, evacuationZone.y);
    }

    // Player
    const playerColor = player.hasHazmatSuit ? '#ffff00' : '#0aff9d';
    ctx.fillStyle = playerColor;
    ctx.shadowColor = playerColor;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(player.x, player.y, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    if (player.hasMask) {
      ctx.strokeStyle = '#0066ff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(player.x, player.y, 15, 0, Math.PI * 2);
      ctx.stroke();
    }

    // UI
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    ctx.fillRect(0, 0, GAME_WIDTH, 100);

    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(`Health: ${Math.round(player.health)}%`, 10, 25);
    ctx.fillText(`Oxygen: ${Math.round(player.oxygen)}%`, 10, 45);
    ctx.fillText(`Radiation: ${Math.round(player.radiation)}%`, 10, 65);
    
    ctx.fillText(`Hazmat Suit: ${player.hasHazmatSuit ? 'YES' : 'NO'}`, 200, 25);
    ctx.fillText(`Gas Mask: ${player.hasMask ? 'YES' : 'NO'}`, 200, 45);
    
    if (evacuationZone.active) {
      ctx.fillStyle = '#00ff00';
      ctx.fillText('EVACUATION ZONE ACTIVE!', 200, 65);
    } else {
      ctx.fillStyle = '#ffff00';
      ctx.fillText(`Time to evacuation: ${Math.max(0, 30 - Math.floor(gameTime / 60))}s`, 200, 65);
    }

    ctx.textAlign = 'center';
  }, [player, hazards, supplies, evacuationZone, gameTime]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: true }));
    const handleKeyUp = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: false }));
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = () => {
    setScore(0);
    setGameTime(0);
    setHazards([]);
    setSupplies([]);
    setPlayer({
      x: 50,
      y: 50,
      health: 100,
      oxygen: 100,
      radiation: 0,
      hasHazmatSuit: false,
      hasMask: false
    });
    setEvacuationZone({ x: GAME_WIDTH - 100, y: GAME_HEIGHT - 100, active: false });
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Biohazard Survival"
      description="Survive in contaminated environments!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          className="border-2 border-neon-green rounded-lg max-w-full h-auto"
        />
        <div className="text-center text-sm text-gray-400 max-w-md">
          Navigate contaminated zones, collect supplies, and reach the evacuation point!
        </div>
      </div>
    </GameLayout>
  );
}
