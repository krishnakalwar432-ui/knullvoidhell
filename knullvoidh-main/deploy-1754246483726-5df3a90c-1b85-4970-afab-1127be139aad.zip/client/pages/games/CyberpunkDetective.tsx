import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface Evidence {
  id: string;
  name: string;
  description: string;
  found: boolean;
  x: number;
  y: number;
  color: string;
}

interface Clue {
  id: string;
  text: string;
  revealed: boolean;
  connected: string[];
}

interface Case {
  title: string;
  description: string;
  evidence: Evidence[];
  clues: Clue[];
  solution: string[];
  solved: boolean;
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;

export default function CyberpunkDetective() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentCase, setCurrentCase] = useState<Case | null>(null);
  const [selectedEvidence, setSelectedEvidence] = useState<Evidence[]>([]);
  const [gamePhase, setGamePhase] = useState<'investigation' | 'analysis' | 'solved'>('investigation');
  const [player, setPlayer] = useState({ x: 100, y: 300 });
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});
  const [scanMode, setScanMode] = useState(false);

  const cases: Case[] = [
    {
      title: "The Neon Murder",
      description: "A corpo executive found dead in the cyber district",
      evidence: [
        { id: 'neural-chip', name: 'Neural Chip', description: 'Modified brain implant', found: false, x: 200, y: 150, color: '#0aff9d' },
        { id: 'blood-sample', name: 'Blood Sample', description: 'Nano-enhanced blood', found: false, x: 400, y: 200, color: '#ff0099' },
        { id: 'security-footage', name: 'Security Data', description: 'Corrupted video feed', found: false, x: 600, y: 300, color: '#7000ff' },
        { id: 'weapon', name: 'Plasma Blade', description: 'High-tech assassination tool', found: false, x: 300, y: 450, color: '#00ffff' }
      ],
      clues: [
        { id: 'corpo-conflict', text: 'Victim had corporate enemies', revealed: false, connected: ['neural-chip', 'security-footage'] },
        { id: 'inside-job', text: 'Access required executive clearance', revealed: false, connected: ['security-footage', 'weapon'] },
        { id: 'augmented-killer', text: 'Killer had cybernetic enhancements', revealed: false, connected: ['blood-sample', 'weapon'] }
      ],
      solution: ['neural-chip', 'security-footage', 'weapon'],
      solved: false
    }
  ];

  const generateCase = useCallback(() => {
    const newCase = { ...cases[0] };
    newCase.evidence = newCase.evidence.map(e => ({ ...e, found: false }));
    newCase.clues = newCase.clues.map(c => ({ ...c, revealed: false }));
    newCase.solved = false;
    setCurrentCase(newCase);
  }, []);

  const scanForEvidence = useCallback(() => {
    if (!currentCase || !scanMode) return;

    const scanRadius = 80;
    currentCase.evidence.forEach(evidence => {
      if (!evidence.found) {
        const distance = Math.sqrt(
          (evidence.x - player.x) ** 2 + (evidence.y - player.y) ** 2
        );
        
        if (distance < scanRadius) {
          evidence.found = true;
          setScore(prev => prev + 50);
          
          // Check if this reveals any clues
          currentCase.clues.forEach(clue => {
            if (!clue.revealed && clue.connected.includes(evidence.id)) {
              const foundConnected = clue.connected.filter(id => 
                currentCase.evidence.find(e => e.id === id)?.found
              );
              
              if (foundConnected.length >= 2) {
                clue.revealed = true;
                setScore(prev => prev + 100);
              }
            }
          });
        }
      }
    });
  }, [currentCase, scanMode, player]);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused || gamePhase !== 'investigation') return;

    // Player movement
    setPlayer(prev => {
      let newX = prev.x;
      let newY = prev.y;

      if (keys['ArrowLeft'] || keys['a']) newX -= 3;
      if (keys['ArrowRight'] || keys['d']) newX += 3;
      if (keys['ArrowUp'] || keys['w']) newY -= 3;
      if (keys['ArrowDown'] || keys['s']) newY += 3;

      return {
        x: Math.max(20, Math.min(GAME_WIDTH - 20, newX)),
        y: Math.max(20, Math.min(GAME_HEIGHT - 20, newY))
      };
    });

    // Scan mode
    if (keys[' ']) {
      setScanMode(true);
      scanForEvidence();
    } else {
      setScanMode(false);
    }

    // Check if all evidence found
    if (currentCase && currentCase.evidence.every(e => e.found)) {
      setGamePhase('analysis');
    }

  }, [isPlaying, isPaused, gamePhase, keys, currentCase, scanForEvidence]);

  const analyzeEvidence = useCallback((evidenceId: string) => {
    if (!currentCase) return;

    const evidence = currentCase.evidence.find(e => e.id === evidenceId);
    if (!evidence || !evidence.found) return;

    if (selectedEvidence.includes(evidence)) {
      setSelectedEvidence(prev => prev.filter(e => e.id !== evidenceId));
    } else {
      setSelectedEvidence(prev => [...prev, evidence]);
    }
  }, [currentCase, selectedEvidence]);

  const solveCase = useCallback(() => {
    if (!currentCase) return;

    const selectedIds = selectedEvidence.map(e => e.id).sort();
    const solutionIds = [...currentCase.solution].sort();
    
    if (JSON.stringify(selectedIds) === JSON.stringify(solutionIds)) {
      currentCase.solved = true;
      setGamePhase('solved');
      setScore(prev => prev + 500);
    } else {
      setScore(prev => Math.max(0, prev - 100));
    }
  }, [currentCase, selectedEvidence]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // Cyberpunk city background
    const gradient = ctx.createLinearGradient(0, 0, GAME_WIDTH, GAME_HEIGHT);
    gradient.addColorStop(0, '#001122');
    gradient.addColorStop(0.5, '#002244');
    gradient.addColorStop(1, '#001122');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Neon grid
    ctx.strokeStyle = '#0066ff';
    ctx.lineWidth = 1;
    ctx.globalAlpha = 0.3;
    for (let x = 0; x < GAME_WIDTH; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, GAME_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y < GAME_HEIGHT; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(GAME_WIDTH, y);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;

    if (!currentCase) return;

    if (gamePhase === 'investigation') {
      // Draw evidence
      currentCase.evidence.forEach(evidence => {
        if (evidence.found) {
          ctx.fillStyle = evidence.color;
          ctx.shadowColor = evidence.color;
          ctx.shadowBlur = 15;
          ctx.beginPath();
          ctx.arc(evidence.x, evidence.y, 12, 0, Math.PI * 2);
          ctx.fill();
          ctx.shadowBlur = 0;

          ctx.fillStyle = '#ffffff';
          ctx.font = '10px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(evidence.name, evidence.x, evidence.y - 20);
        } else if (scanMode) {
          // Show outline when scanning
          const distance = Math.sqrt(
            (evidence.x - player.x) ** 2 + (evidence.y - player.y) ** 2
          );
          if (distance < 80) {
            ctx.strokeStyle = evidence.color;
            ctx.lineWidth = 2;
            ctx.globalAlpha = 0.5;
            ctx.beginPath();
            ctx.arc(evidence.x, evidence.y, 12, 0, Math.PI * 2);
            ctx.stroke();
            ctx.globalAlpha = 1;
          }
        }
      });

      // Draw player
      ctx.fillStyle = '#ffff00';
      ctx.shadowColor = '#ffff00';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(player.x, player.y, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Scan radius
      if (scanMode) {
        ctx.strokeStyle = '#00ffff';
        ctx.lineWidth = 2;
        ctx.globalAlpha = 0.5;
        ctx.beginPath();
        ctx.arc(player.x, player.y, 80, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }

      // UI
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.fillRect(0, 0, GAME_WIDTH, 60);

      ctx.fillStyle = '#0aff9d';
      ctx.font = '16px Arial';
      ctx.textAlign = 'left';
      ctx.fillText(currentCase.title, 10, 25);
      ctx.fillText(`Evidence: ${currentCase.evidence.filter(e => e.found).length}/${currentCase.evidence.length}`, 10, 45);

      ctx.fillText('Hold SPACE to scan', GAME_WIDTH - 150, 25);
    } else if (gamePhase === 'analysis') {
      // Analysis interface
      ctx.fillStyle = 'rgba(0, 0, 0, 0.9)';
      ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

      ctx.fillStyle = '#0aff9d';
      ctx.font = '24px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('EVIDENCE ANALYSIS', GAME_WIDTH/2, 50);

      // Evidence grid
      currentCase.evidence.forEach((evidence, i) => {
        if (evidence.found) {
          const x = 100 + (i % 4) * 150;
          const y = 120 + Math.floor(i / 4) * 80;
          
          const isSelected = selectedEvidence.includes(evidence);
          
          ctx.fillStyle = isSelected ? evidence.color : evidence.color + '50';
          ctx.fillRect(x - 40, y - 20, 80, 40);
          
          ctx.fillStyle = '#ffffff';
          ctx.font = '12px Arial';
          ctx.textAlign = 'center';
          ctx.fillText(evidence.name, x, y + 5);
        }
      });

      // Revealed clues
      ctx.fillStyle = '#ffffff';
      ctx.font = '14px Arial';
      ctx.textAlign = 'left';
      ctx.fillText('Revealed Clues:', 50, 350);
      
      currentCase.clues.forEach((clue, i) => {
        if (clue.revealed) {
          ctx.fillStyle = '#ffff00';
          ctx.fillText(`• ${clue.text}`, 50, 380 + i * 25);
        }
      });

      // Solve button
      ctx.fillStyle = '#ff0099';
      ctx.fillRect(GAME_WIDTH/2 - 60, GAME_HEIGHT - 80, 120, 40);
      ctx.fillStyle = '#ffffff';
      ctx.font = '16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('SOLVE CASE', GAME_WIDTH/2, GAME_HEIGHT - 55);

    } else if (gamePhase === 'solved') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
      
      ctx.fillStyle = currentCase.solved ? '#00ff00' : '#ff0000';
      ctx.font = '36px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(currentCase.solved ? 'CASE SOLVED!' : 'CASE FAILED!', GAME_WIDTH/2, GAME_HEIGHT/2);
    }

    ctx.textAlign = 'left';
  }, [currentCase, gamePhase, player, scanMode, selectedEvidence]);

  const handleCanvasClick = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (gamePhase !== 'analysis') return;

    const canvas = canvasRef.current;
    if (!canvas || !currentCase) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = GAME_WIDTH / rect.width;
    const scaleY = GAME_HEIGHT / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;

    // Check evidence clicks
    currentCase.evidence.forEach((evidence, i) => {
      if (evidence.found) {
        const evidenceX = 100 + (i % 4) * 150;
        const evidenceY = 120 + Math.floor(i / 4) * 80;
        
        if (x >= evidenceX - 40 && x <= evidenceX + 40 && y >= evidenceY - 20 && y <= evidenceY + 20) {
          analyzeEvidence(evidence.id);
        }
      }
    });

    // Check solve button
    if (x >= GAME_WIDTH/2 - 60 && x <= GAME_WIDTH/2 + 60 && 
        y >= GAME_HEIGHT - 80 && y <= GAME_HEIGHT - 40) {
      solveCase();
    }
  }, [gamePhase, currentCase, analyzeEvidence, solveCase]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: true }));
    const handleKeyUp = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: false }));
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = () => {
    setScore(0);
    setPlayer({ x: 100, y: 300 });
    setGamePhase('investigation');
    setSelectedEvidence([]);
    setScanMode(false);
    generateCase();
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Cyberpunk Detective"
      description="Solve mysteries in a cyber noir setting!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          onClick={handleCanvasClick}
          className="border-2 border-neon-green rounded-lg cursor-pointer max-w-full h-auto"
        />
        <div className="text-center text-sm text-gray-400 max-w-md">
          WASD to move, SPACE to scan for evidence. Analyze clues to solve the case!
        </div>
      </div>
    </GameLayout>
  );
}
