import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface VRWorld {
  id: string;
  name: string;
  theme: 'cyber' | 'nature' | 'space' | 'abstract';
  objects: VRObject[];
  discovered: number;
  total: number;
}

interface VRObject {
  x: number;
  y: number;
  z: number;
  type: 'artifact' | 'portal' | 'data_node' | 'energy_source';
  discovered: boolean;
  value: number;
  color: string;
  pulse: number;
}

interface Player {
  x: number;
  y: number;
  z: number;
  viewAngle: number;
  energy: number;
}

const WORLD_SIZE = 400;
const VIEW_DISTANCE = 200;

export default function VirtualRealityExplorer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [player, setPlayer] = useState<Player>({
    x: 0, y: 0, z: 0,
    viewAngle: 0,
    energy: 100
  });
  const [currentWorld, setCurrentWorld] = useState<VRWorld | null>(null);
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});
  const [scanMode, setScanMode] = useState(false);
  const [worldIndex, setWorldIndex] = useState(0);

  const vrWorlds: VRWorld[] = [
    {
      id: 'cyber-city',
      name: 'Cyber City',
      theme: 'cyber',
      objects: [],
      discovered: 0,
      total: 8
    },
    {
      id: 'digital-forest',
      name: 'Digital Forest',
      theme: 'nature',
      objects: [],
      discovered: 0,
      total: 10
    },
    {
      id: 'quantum-space',
      name: 'Quantum Space',
      theme: 'space',
      objects: [],
      discovered: 0,
      total: 12
    }
  ];

  const generateWorld = useCallback((world: VRWorld) => {
    const objects: VRObject[] = [];
    const colors = {
      cyber: ['#0aff9d', '#ff0099', '#00ffff', '#7000ff'],
      nature: ['#00ff00', '#ff6600', '#ffff00', '#8B4513'],
      space: ['#ffffff', '#ff0000', '#0000ff', '#ffff00'],
      abstract: ['#ff00ff', '#00ffff', '#ffff00', '#ff8000']
    };

    for (let i = 0; i < world.total; i++) {
      const angle = (i / world.total) * Math.PI * 2;
      const distance = 50 + Math.random() * 150;
      
      objects.push({
        x: Math.cos(angle) * distance,
        y: Math.random() * 100 - 50,
        z: Math.sin(angle) * distance,
        type: ['artifact', 'portal', 'data_node', 'energy_source'][Math.floor(Math.random() * 4)] as any,
        discovered: false,
        value: 10 + Math.random() * 40,
        color: colors[world.theme][Math.floor(Math.random() * colors[world.theme].length)],
        pulse: Math.random() * Math.PI * 2
      });
    }

    world.objects = objects;
    world.discovered = 0;
    setCurrentWorld({ ...world });
  }, []);

  const project3DTo2D = useCallback((x: number, y: number, z: number, playerX: number, playerY: number, playerZ: number, viewAngle: number) => {
    // Translate to player position
    const translatedX = x - playerX;
    const translatedY = y - playerY;
    const translatedZ = z - playerZ;

    // Rotate around Y axis (view angle)
    const cos = Math.cos(viewAngle);
    const sin = Math.sin(viewAngle);
    const rotatedX = translatedX * cos - translatedZ * sin;
    const rotatedZ = translatedX * sin + translatedZ * cos;

    // Project to 2D
    const distance = Math.max(rotatedZ, 1);
    const screenX = 400 + (rotatedX / distance) * 200;
    const screenY = 300 + (translatedY / distance) * 200;
    
    return { x: screenX, y: screenY, distance };
  }, []);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused || !currentWorld) return;

    // Player movement
    setPlayer(prev => {
      let newX = prev.x;
      let newY = prev.y;
      let newZ = prev.z;
      let newAngle = prev.viewAngle;
      let newEnergy = prev.energy;

      const moveSpeed = 3;
      const turnSpeed = 0.05;

      if (keys['ArrowLeft'] || keys['a']) newAngle -= turnSpeed;
      if (keys['ArrowRight'] || keys['d']) newAngle += turnSpeed;
      
      if (keys['ArrowUp'] || keys['w']) {
        newX += Math.sin(newAngle) * moveSpeed;
        newZ += Math.cos(newAngle) * moveSpeed;
      }
      if (keys['ArrowDown'] || keys['s']) {
        newX -= Math.sin(newAngle) * moveSpeed;
        newZ -= Math.cos(newAngle) * moveSpeed;
      }
      
      if (keys[' ']) newY += moveSpeed;
      if (keys['Shift']) newY -= moveSpeed;

      // Boundaries
      const boundary = WORLD_SIZE / 2;
      newX = Math.max(-boundary, Math.min(boundary, newX));
      newY = Math.max(-100, Math.min(100, newY));
      newZ = Math.max(-boundary, Math.min(boundary, newZ));

      // Energy management
      if (keys['f'] && !scanMode) {
        setScanMode(true);
        newEnergy -= 2;
      } else if (!keys['f']) {
        setScanMode(false);
        newEnergy = Math.min(100, newEnergy + 0.5);
      }

      return { ...prev, x: newX, y: newY, z: newZ, viewAngle: newAngle, energy: Math.max(0, newEnergy) };
    });

    // Scan for objects
    if (scanMode && player.energy > 0) {
      currentWorld.objects.forEach(obj => {
        if (!obj.discovered) {
          const distance = Math.sqrt(
            (obj.x - player.x) ** 2 + 
            (obj.y - player.y) ** 2 + 
            (obj.z - player.z) ** 2
          );
          
          if (distance < 50) {
            obj.discovered = true;
            currentWorld.discovered++;
            setScore(prev => prev + Math.round(obj.value));
          }
        }
      });

      // Check world completion
      if (currentWorld.discovered >= currentWorld.total) {
        setScore(prev => prev + 500);
        if (worldIndex < vrWorlds.length - 1) {
          setWorldIndex(prev => prev + 1);
          generateWorld(vrWorlds[worldIndex + 1]);
        }
      }
    }

  }, [isPlaying, isPaused, currentWorld, player, keys, scanMode, worldIndex, generateWorld]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !currentWorld) return;

    // VR interface background
    const gradient = ctx.createRadialGradient(400, 300, 0, 400, 300, 400);
    gradient.addColorStop(0, '#001122');
    gradient.addColorStop(0.7, '#002244');
    gradient.addColorStop(1, '#000011');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 600);

    // VR Grid floor
    ctx.strokeStyle = '#003366';
    ctx.lineWidth = 1;
    for (let i = -10; i <= 10; i++) {
      const startProj = project3DTo2D(i * 20, -50, -200, player.x, player.y, player.z, player.viewAngle);
      const endProj = project3DTo2D(i * 20, -50, 200, player.x, player.y, player.z, player.viewAngle);
      
      if (startProj.distance > 0 && endProj.distance > 0) {
        ctx.beginPath();
        ctx.moveTo(startProj.x, startProj.y);
        ctx.lineTo(endProj.x, endProj.y);
        ctx.stroke();
      }

      const startProj2 = project3DTo2D(-200, -50, i * 20, player.x, player.y, player.z, player.viewAngle);
      const endProj2 = project3DTo2D(200, -50, i * 20, player.x, player.y, player.z, player.viewAngle);
      
      if (startProj2.distance > 0 && endProj2.distance > 0) {
        ctx.beginPath();
        ctx.moveTo(startProj2.x, startProj2.y);
        ctx.lineTo(endProj2.x, endProj2.y);
        ctx.stroke();
      }
    }

    // VR Objects
    const sortedObjects = [...currentWorld.objects].sort((a, b) => {
      const distA = Math.sqrt((a.x - player.x) ** 2 + (a.z - player.z) ** 2);
      const distB = Math.sqrt((b.x - player.x) ** 2 + (b.z - player.z) ** 2);
      return distB - distA;
    });

    sortedObjects.forEach(obj => {
      const proj = project3DTo2D(obj.x, obj.y, obj.z, player.x, player.y, player.z, player.viewAngle);
      
      if (proj.distance > 0 && proj.x >= 0 && proj.x <= 800 && proj.y >= 0 && proj.y <= 600) {
        const size = Math.max(5, 30 / proj.distance * 10);
        const alpha = obj.discovered ? 1 : (scanMode ? 0.7 : 0.3);
        
        ctx.save();
        ctx.globalAlpha = alpha;
        
        if (obj.discovered || scanMode) {
          ctx.fillStyle = obj.color;
          ctx.shadowColor = obj.color;
          ctx.shadowBlur = 10;
          
          // Pulsing effect
          obj.pulse += 0.1;
          const pulseSize = size + Math.sin(obj.pulse) * 3;
          
          switch (obj.type) {
            case 'artifact':
              ctx.fillRect(proj.x - pulseSize/2, proj.y - pulseSize/2, pulseSize, pulseSize);
              break;
            case 'portal':
              ctx.beginPath();
              ctx.arc(proj.x, proj.y, pulseSize, 0, Math.PI * 2);
              ctx.fill();
              break;
            case 'data_node':
              ctx.beginPath();
              for (let i = 0; i < 6; i++) {
                const angle = (i / 6) * Math.PI * 2;
                const x = proj.x + Math.cos(angle) * pulseSize;
                const y = proj.y + Math.sin(angle) * pulseSize;
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
              }
              ctx.closePath();
              ctx.fill();
              break;
            case 'energy_source':
              ctx.beginPath();
              for (let i = 0; i < 5; i++) {
                const angle = (i * Math.PI * 2) / 5;
                const radius = i % 2 === 0 ? pulseSize : pulseSize * 0.6;
                const x = proj.x + Math.cos(angle) * radius;
                const y = proj.y + Math.sin(angle) * radius;
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
              }
              ctx.closePath();
              ctx.fill();
              break;
          }
        }
        
        ctx.restore();
      }
    });

    // VR HUD
    ctx.fillStyle = 'rgba(0, 100, 150, 0.8)';
    ctx.fillRect(0, 0, 800, 80);
    ctx.fillRect(0, 520, 800, 80);

    ctx.fillStyle = '#00ffff';
    ctx.font = '18px Arial';
    ctx.fillText(`World: ${currentWorld.name}`, 20, 30);
    ctx.fillText(`Discovered: ${currentWorld.discovered}/${currentWorld.total}`, 20, 55);
    
    ctx.fillText(`Energy: ${Math.round(player.energy)}%`, 400, 30);
    ctx.fillText(scanMode ? 'SCANNING...' : 'Hold F to scan', 400, 55);

    // Energy bar
    const energyPercent = player.energy / 100;
    ctx.fillStyle = '#000066';
    ctx.fillRect(600, 35, 180, 15);
    ctx.fillStyle = energyPercent > 0.3 ? '#00ff00' : '#ff0000';
    ctx.fillRect(600, 35, 180 * energyPercent, 15);

    // Instructions
    ctx.fillStyle = '#ffffff';
    ctx.font = '14px Arial';
    ctx.fillText('WASD: Move | Arrows: Turn | Space/Shift: Up/Down | F: Scan', 20, 550);

    // Crosshair
    ctx.strokeStyle = '#00ffff';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(390, 300);
    ctx.lineTo(410, 300);
    ctx.moveTo(400, 290);
    ctx.lineTo(400, 310);
    ctx.stroke();

  }, [currentWorld, player, scanMode, project3DTo2D]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: true }));
    const handleKeyUp = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: false }));
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = () => {
    setScore(0);
    setWorldIndex(0);
    setPlayer({ x: 0, y: 0, z: 0, viewAngle: 0, energy: 100 });
    setScanMode(false);
    generateWorld(vrWorlds[0]);
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Virtual Reality Explorer"
      description="Explore virtual worlds and discover hidden objects!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="border-2 border-neon-green rounded-lg max-w-full h-auto"
        />
        <div className="text-center text-sm text-gray-400 max-w-md">
          Navigate VR worlds and scan for hidden objects. Use F to scan and discover artifacts!
        </div>
      </div>
    </GameLayout>
  );
}
