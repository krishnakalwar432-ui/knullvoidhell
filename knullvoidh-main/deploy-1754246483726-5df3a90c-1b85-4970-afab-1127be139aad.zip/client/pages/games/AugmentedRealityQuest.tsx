import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface ARObject {
  id: string;
  x: number;
  y: number;
  type: 'target' | 'obstacle' | 'powerup' | 'quest_item';
  collected: boolean;
  color: string;
  scale: number;
  rotation: number;
}

interface Player {
  x: number;
  y: number;
  scanRadius: number;
  energy: number;
  maxEnergy: number;
  questItems: number;
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;

export default function AugmentedRealityQuest() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [player, setPlayer] = useState<Player>({
    x: GAME_WIDTH / 2,
    y: GAME_HEIGHT / 2,
    scanRadius: 100,
    energy: 100,
    maxEnergy: 100,
    questItems: 0
  });
  const [arObjects, setArObjects] = useState<ARObject[]>([]);
  const [scanning, setScanning] = useState(false);
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});
  const [gameTime, setGameTime] = useState(0);

  const spawnARObject = useCallback(() => {
    const types: ARObject['type'][] = ['target', 'obstacle', 'powerup', 'quest_item'];
    const colors = ['#ff0099', '#00ffff', '#ffff00', '#0aff9d'];
    const type = types[Math.floor(Math.random() * types.length)];
    
    const newObject: ARObject = {
      id: `ar-${Date.now()}-${Math.random()}`,
      x: Math.random() * (GAME_WIDTH - 40) + 20,
      y: Math.random() * (GAME_HEIGHT - 40) + 20,
      type,
      collected: false,
      color: colors[types.indexOf(type)],
      scale: 0.5 + Math.random() * 0.5,
      rotation: Math.random() * Math.PI * 2
    };
    
    setArObjects(prev => [...prev, newObject]);
  }, []);

  const scanForObjects = useCallback(() => {
    if (player.energy < 10) return;
    
    setScanning(true);
    setPlayer(prev => ({ ...prev, energy: prev.energy - 10 }));
    
    setTimeout(() => setScanning(false), 500);
    
    arObjects.forEach(obj => {
      const distance = Math.sqrt(
        (obj.x - player.x) ** 2 + (obj.y - player.y) ** 2
      );
      
      if (distance <= player.scanRadius && !obj.collected) {
        obj.collected = true;
        
        switch (obj.type) {
          case 'target':
            setScore(prev => prev + 20);
            break;
          case 'powerup':
            setPlayer(prev => ({ 
              ...prev, 
              scanRadius: Math.min(200, prev.scanRadius + 20),
              energy: Math.min(prev.maxEnergy, prev.energy + 30)
            }));
            break;
          case 'quest_item':
            setPlayer(prev => ({ ...prev, questItems: prev.questItems + 1 }));
            setScore(prev => prev + 50);
            break;
        }
      }
    });
  }, [player, arObjects]);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused) return;

    setGameTime(prev => prev + 1);

    // Move player
    setPlayer(prev => {
      let newX = prev.x;
      let newY = prev.y;

      if (keys['ArrowLeft'] || keys['a']) newX -= 3;
      if (keys['ArrowRight'] || keys['d']) newX += 3;
      if (keys['ArrowUp'] || keys['w']) newY -= 3;
      if (keys['ArrowDown'] || keys['s']) newY += 3;

      return {
        ...prev,
        x: Math.max(20, Math.min(GAME_WIDTH - 20, newX)),
        y: Math.max(20, Math.min(GAME_HEIGHT - 20, newY)),
        energy: Math.min(prev.maxEnergy, prev.energy + 0.2)
      };
    });

    // Spawn objects
    if (gameTime % 120 === 0) {
      spawnARObject();
    }

    // Handle scanning
    if (keys[' '] && !scanning) {
      scanForObjects();
    }

  }, [isPlaying, isPaused, keys, gameTime, scanning, spawnARObject, scanForObjects]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // AR interface background
    ctx.fillStyle = '#000814';
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Grid overlay
    ctx.strokeStyle = '#003366';
    ctx.lineWidth = 1;
    for (let x = 0; x < GAME_WIDTH; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, GAME_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y < GAME_HEIGHT; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(GAME_WIDTH, y);
      ctx.stroke();
    }

    // AR Objects
    arObjects.forEach(obj => {
      if (obj.collected) return;

      ctx.save();
      ctx.translate(obj.x, obj.y);
      ctx.rotate(obj.rotation);
      ctx.scale(obj.scale, obj.scale);

      ctx.fillStyle = obj.color;
      ctx.shadowColor = obj.color;
      ctx.shadowBlur = 10;

      switch (obj.type) {
        case 'target':
          ctx.beginPath();
          ctx.arc(0, 0, 15, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 'obstacle':
          ctx.fillRect(-15, -15, 30, 30);
          break;
        case 'powerup':
          ctx.beginPath();
          for (let i = 0; i < 5; i++) {
            const angle = (i * Math.PI * 2) / 5;
            const radius = i % 2 === 0 ? 15 : 8;
            const x = Math.cos(angle) * radius;
            const y = Math.sin(angle) * radius;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.closePath();
          ctx.fill();
          break;
        case 'quest_item':
          ctx.fillRect(-10, -10, 20, 20);
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(-5, -5, 10, 10);
          break;
      }

      ctx.shadowBlur = 0;
      ctx.restore();
    });

    // Player
    ctx.fillStyle = '#0aff9d';
    ctx.shadowColor = '#0aff9d';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(player.x, player.y, 12, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Scan radius
    if (scanning) {
      ctx.strokeStyle = '#00ffff';
      ctx.lineWidth = 3;
      ctx.globalAlpha = 0.7;
      ctx.beginPath();
      ctx.arc(player.x, player.y, player.scanRadius, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.fillText(`Energy: ${Math.round(player.energy)}`, 10, 30);
    ctx.fillText(`Quest Items: ${player.questItems}`, 10, 50);
    ctx.fillText(`Scan Radius: ${player.scanRadius}`, 10, 70);

    // Instructions
    ctx.fillStyle = '#666666';
    ctx.font = '12px Arial';
    ctx.fillText('Hold SPACE to scan for AR objects', 10, GAME_HEIGHT - 20);

  }, [player, arObjects, scanning]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: true }));
    const handleKeyUp = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: false }));
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = () => {
    setScore(0);
    setGameTime(0);
    setArObjects([]);
    setPlayer({
      x: GAME_WIDTH / 2,
      y: GAME_HEIGHT / 2,
      scanRadius: 100,
      energy: 100,
      maxEnergy: 100,
      questItems: 0
    });
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Augmented Reality Quest"
      description="Scan and collect AR objects in virtual space!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          className="border-2 border-neon-green rounded-lg max-w-full h-auto"
        />
        <div className="text-center text-sm text-gray-400 max-w-md">
          Move with WASD, hold SPACE to scan for AR objects. Find quest items for bonus points!
        </div>
      </div>
    </GameLayout>
  );
}
