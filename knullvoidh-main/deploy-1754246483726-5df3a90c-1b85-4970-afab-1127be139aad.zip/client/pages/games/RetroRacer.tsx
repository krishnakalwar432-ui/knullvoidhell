import React, { useState, useEffect, useRef, useCallback } from 'react';
import GameLayout from '@/components/GameLayout';

interface Car {
  x: number;
  y: number;
  speed: number;
  color: string;
  ai: boolean;
}

interface RoadSegment {
  curve: number;
  hill: number;
  color: string;
}

const RetroRacer: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'playing' | 'paused' | 'finished'>('playing');
  const [score, setScore] = useState(0);
  const [speed, setSpeed] = useState(0);
  const [position, setPosition] = useState(0);
  const [playerX, setPlayerX] = useState(0);
  const [cars, setCars] = useState<Car[]>([]);
  const [roadSegments] = useState<RoadSegment[]>(() => {
    const segments: RoadSegment[] = [];
    for (let i = 0; i < 1000; i++) {
      segments.push({
        curve: Math.sin(i * 0.02) * 0.002 + Math.sin(i * 0.008) * 0.001,
        hill: Math.sin(i * 0.01) * 0.002,
        color: Math.floor(i / 3) % 2 === 0 ? '#ff0099' : '#7000ff'
      });
    }
    return segments;
  });
  const [keys, setKeys] = useState<Set<string>>(new Set());

  const gameLoopRef = useRef<number>();
  const CANVAS_WIDTH = 800;
  const CANVAS_HEIGHT = 600;
  const ROAD_WIDTH = 300;
  const MAX_SPEED = 8;

  // Handle input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => new Set([...prev, e.key.toLowerCase()]));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => {
        const newKeys = new Set(prev);
        newKeys.delete(e.key.toLowerCase());
        return newKeys;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Touch controls
  const handleTouchStart = (e: React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const touch = e.touches[0];
    const x = touch.clientX - rect.left;
    const centerX = rect.width / 2;

    if (x < centerX - 50) {
      setKeys(prev => new Set([...prev, 'a']));
    } else if (x > centerX + 50) {
      setKeys(prev => new Set([...prev, 'd']));
    } else {
      setKeys(prev => new Set([...prev, 'w']));
    }
  };

  const handleTouchEnd = () => {
    setKeys(new Set());
  };

  // Generate AI cars
  const spawnCar = useCallback(() => {
    if (cars.length < 5 && Math.random() < 0.02) {
      setCars(prev => [...prev, {
        x: (Math.random() - 0.5) * 0.8,
        y: Math.random() * 100 + position + 200,
        speed: 3 + Math.random() * 2,
        color: ['#0aff9d', '#ff6600', '#00ffff', '#ffff00'][Math.floor(Math.random() * 4)],
        ai: true
      }]);
    }
  }, [cars.length, position]);

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    const gameLoop = () => {
      // Handle player input
      let newSpeed = speed;
      let newPlayerX = playerX;
      
      if (keys.has('w') || keys.has('arrowup')) {
        newSpeed = Math.min(speed + 0.2, MAX_SPEED);
      } else if (keys.has('s') || keys.has('arrowdown')) {
        newSpeed = Math.max(speed - 0.3, 0);
      } else {
        newSpeed = Math.max(speed - 0.1, 0);
      }

      if (keys.has('a') || keys.has('arrowleft')) {
        newPlayerX = Math.max(playerX - 0.02, -0.8);
      }
      if (keys.has('d') || keys.has('arrowright')) {
        newPlayerX = Math.min(playerX + 0.02, 0.8);
      }

      // Update position based on speed
      const newPosition = position + newSpeed;
      
      // Apply road curve to player
      const segmentIndex = Math.floor(newPosition) % roadSegments.length;
      const curve = roadSegments[segmentIndex].curve;
      newPlayerX += curve * newSpeed * 0.5;

      setSpeed(newSpeed);
      setPlayerX(newPlayerX);
      setPosition(newPosition);
      setScore(Math.floor(newPosition / 10));

      // Update AI cars
      setCars(prev => prev
        .map(car => ({
          ...car,
          y: car.y - newSpeed + car.speed,
          x: car.x + roadSegments[Math.floor(car.y) % roadSegments.length]?.curve * car.speed * 0.3 || 0
        }))
        .filter(car => car.y > position - 50 && car.y < position + 300)
      );

      // Spawn new cars
      spawnCar();

      // Check collisions
      cars.forEach(car => {
        const dx = Math.abs(car.x - newPlayerX);
        const dy = Math.abs(car.y - newPosition);
        if (dx < 0.1 && dy < 20) {
          setSpeed(prev => prev * 0.5);
          setScore(prev => prev - 50);
        }
      });

      gameLoopRef.current = requestAnimationFrame(gameLoop);
    };

    gameLoopRef.current = requestAnimationFrame(gameLoop);

    return () => {
      if (gameLoopRef.current) {
        cancelAnimationFrame(gameLoopRef.current);
      }
    };
  }, [gameState, speed, playerX, position, keys, cars, roadSegments, spawnCar]);

  // Render game
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear with synthwave sky
    const gradient = ctx.createLinearGradient(0, 0, 0, CANVAS_HEIGHT);
    gradient.addColorStop(0, '#ff006e');
    gradient.addColorStop(0.3, '#8338ec');
    gradient.addColorStop(0.6, '#3a86ff');
    gradient.addColorStop(1, '#06ffa5');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw sun
    const sunGradient = ctx.createRadialGradient(CANVAS_WIDTH/2, 150, 0, CANVAS_WIDTH/2, 150, 100);
    sunGradient.addColorStop(0, '#ffbe0b');
    sunGradient.addColorStop(1, '#fb5607');
    ctx.fillStyle = sunGradient;
    ctx.beginPath();
    ctx.arc(CANVAS_WIDTH/2, 150, 80, 0, Math.PI * 2);
    ctx.fill();

    // Draw mountains
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.moveTo(0, 300);
    for (let x = 0; x < CANVAS_WIDTH; x += 50) {
      ctx.lineTo(x, 250 + Math.sin((x + position) * 0.01) * 50);
    }
    ctx.lineTo(CANVAS_WIDTH, 300);
    ctx.closePath();
    ctx.fill();

    // Draw road
    const roadY = CANVAS_HEIGHT * 0.6;
    const segments = 50;
    
    for (let i = 0; i < segments; i++) {
      const z = i / segments;
      const segmentIndex = Math.floor(position + i * 5) % roadSegments.length;
      const segment = roadSegments[segmentIndex];
      
      const y = roadY + z * (CANVAS_HEIGHT - roadY);
      const scale = 1 - z * 0.8;
      const roadWidth = ROAD_WIDTH * scale;
      
      // Road surface
      ctx.fillStyle = i % 3 === 0 ? '#333' : '#222';
      ctx.fillRect(CANVAS_WIDTH/2 - roadWidth/2, y, roadWidth, 5);
      
      // Road lines
      if (i % 6 === 0) {
        ctx.fillStyle = '#ffff00';
        ctx.fillRect(CANVAS_WIDTH/2 - 5, y, 10, 3);
      }
      
      // Road edges
      ctx.fillStyle = segment.color;
      ctx.fillRect(CANVAS_WIDTH/2 - roadWidth/2 - 10, y, 10, 5);
      ctx.fillRect(CANVAS_WIDTH/2 + roadWidth/2, y, 10, 5);
    }

    // Draw cars
    cars.forEach(car => {
      const carZ = Math.max(0, Math.min(1, (car.y - position) / 200));
      const carY = roadY + carZ * (CANVAS_HEIGHT - roadY);
      const carScale = 1 - carZ * 0.8;
      const carScreenX = CANVAS_WIDTH/2 + car.x * ROAD_WIDTH * carScale;
      
      if (carZ < 1) {
        ctx.fillStyle = car.color;
        ctx.shadowColor = car.color;
        ctx.shadowBlur = 10;
        const carWidth = 20 * carScale;
        const carHeight = 30 * carScale;
        ctx.fillRect(carScreenX - carWidth/2, carY - carHeight, carWidth, carHeight);
        ctx.shadowBlur = 0;
      }
    });

    // Draw player car
    const playerScreenX = CANVAS_WIDTH/2 + playerX * ROAD_WIDTH;
    const playerY = CANVAS_HEIGHT - 80;
    
    ctx.fillStyle = '#0aff9d';
    ctx.shadowColor = '#0aff9d';
    ctx.shadowBlur = 15;
    ctx.fillRect(playerScreenX - 15, playerY - 30, 30, 40);
    
    // Car details
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(playerScreenX - 10, playerY - 25, 20, 15);
    ctx.fillStyle = '#ff0000';
    ctx.fillRect(playerScreenX - 8, playerY - 5, 16, 3);
    
    ctx.shadowBlur = 0;

    // Draw speedometer
    const speedometerX = CANVAS_WIDTH - 120;
    const speedometerY = CANVAS_HEIGHT - 120;
    const speedPercentage = speed / MAX_SPEED;
    
    // Background
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(speedometerX, speedometerY, 40, Math.PI, Math.PI * 2);
    ctx.stroke();
    
    // Speed arc
    ctx.strokeStyle = speed > MAX_SPEED * 0.8 ? '#ff0000' : '#0aff9d';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(speedometerX, speedometerY, 40, Math.PI, Math.PI + speedPercentage * Math.PI);
    ctx.stroke();
    
    // Speed text
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(Math.floor(speed * 50).toString(), speedometerX, speedometerY + 5);
    ctx.font = '10px monospace';
    ctx.fillText('KM/H', speedometerX, speedometerY + 20);

    // Draw UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '18px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`Distance: ${score}km`, 20, 30);
    ctx.fillText(`Speed: ${Math.floor(speed * 50)} km/h`, 20, 55);
    
    // Position indicator
    const lapProgress = (position % 1000) / 1000;
    ctx.fillStyle = '#333';
    ctx.fillRect(20, 80, 200, 10);
    ctx.fillStyle = '#0aff9d';
    ctx.fillRect(20, 80, lapProgress * 200, 10);
    ctx.strokeStyle = '#ffffff';
    ctx.strokeRect(20, 80, 200, 10);

    if (gameState === 'paused') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.fillStyle = '#ffffff';
      ctx.font = '48px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('PAUSED', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
      ctx.textAlign = 'left';
    }
  });

  const handlePause = () => {
    setGameState(prev => prev === 'playing' ? 'paused' : 'playing');
  };

  const handleReset = () => {
    setScore(0);
    setSpeed(0);
    setPosition(0);
    setPlayerX(0);
    setCars([]);
    setGameState('playing');
  };

  return (
    <GameLayout
      gameTitle="Retro Racer"
      gameCategory="Racing"
      score={score}
      isPlaying={gameState === 'playing'}
      onPause={handlePause}
      onReset={handleReset}
    >
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] p-4">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="border border-neon-pink/50 rounded-lg bg-black/20 backdrop-blur-sm shadow-2xl max-w-full h-auto"
            onTouchStart={handleTouchStart}
            onTouchEnd={handleTouchEnd}
            style={{ touchAction: 'none' }}
          />
          
          <div className="mt-4 text-center text-sm text-muted-foreground">
            <p className="md:hidden">Touch left/right to steer • Center to accelerate</p>
            <p className="hidden md:block">WASD or Arrow keys • Avoid other cars • Go fast!</p>
          </div>
        </div>
      </div>
    </GameLayout>
  );
};

export default RetroRacer;
