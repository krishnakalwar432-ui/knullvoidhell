import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface CircuitNode {
  id: string;
  x: number;
  y: number;
  type: 'input' | 'output' | 'and' | 'or' | 'not' | 'xor';
  inputs: string[];
  outputs: string[];
  value: boolean;
  powered: boolean;
}

interface Connection {
  id: string;
  from: string;
  to: string;
  fromPort: number;
  toPort: number;
  active: boolean;
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const NODE_SIZE = 40;

const nodeTypes = {
  input: { color: '#0aff9d', inputs: 0, outputs: 1 },
  output: { color: '#ff0099', inputs: 1, outputs: 0 },
  and: { color: '#7000ff', inputs: 2, outputs: 1 },
  or: { color: '#00ffff', inputs: 2, outputs: 1 },
  not: { color: '#ffa500', inputs: 1, outputs: 1 },
  xor: { color: '#ff6600', inputs: 2, outputs: 1 }
};

export default function CircuitBreaker() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [level, setLevel] = useState(1);
  const [nodes, setNodes] = useState<CircuitNode[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [dragging, setDragging] = useState<{ nodeId: string; offsetX: number; offsetY: number } | null>(null);
  const [connecting, setConnecting] = useState<{ fromNode: string; fromPort: number } | null>(null);
  const [targetPattern, setTargetPattern] = useState<boolean[]>([]);
  const [currentPattern, setCurrentPattern] = useState<boolean[]>([]);
  const [levelComplete, setLevelComplete] = useState(false);

  const generateLevel = useCallback((levelNum: number) => {
    const newNodes: CircuitNode[] = [];
    const newConnections: Connection[] = [];
    
    // Create input nodes
    const inputCount = Math.min(3 + Math.floor(levelNum / 2), 4);
    for (let i = 0; i < inputCount; i++) {
      newNodes.push({
        id: `input-${i}`,
        x: 50,
        y: 100 + i * 80,
        type: 'input',
        inputs: [],
        outputs: [`input-${i}-out`],
        value: Math.random() > 0.5,
        powered: false
      });
    }

    // Create output nodes
    const outputCount = Math.min(2 + Math.floor(levelNum / 3), 3);
    for (let i = 0; i < outputCount; i++) {
      newNodes.push({
        id: `output-${i}`,
        x: GAME_WIDTH - 100,
        y: 150 + i * 100,
        type: 'output',
        inputs: [`output-${i}-in`],
        outputs: [],
        value: false,
        powered: false
      });
    }

    // Generate target pattern
    const newTargetPattern: boolean[] = [];
    for (let i = 0; i < outputCount; i++) {
      newTargetPattern.push(Math.random() > 0.5);
    }

    setNodes(newNodes);
    setConnections(newConnections);
    setTargetPattern(newTargetPattern);
    setCurrentPattern(new Array(outputCount).fill(false));
    setLevelComplete(false);
  }, []);

  const addNode = useCallback((type: keyof typeof nodeTypes, x: number, y: number) => {
    const nodeId = `${type}-${Date.now()}`;
    const nodeConfig = nodeTypes[type];
    
    const newNode: CircuitNode = {
      id: nodeId,
      x,
      y,
      type,
      inputs: Array.from({ length: nodeConfig.inputs }, (_, i) => `${nodeId}-in-${i}`),
      outputs: Array.from({ length: nodeConfig.outputs }, (_, i) => `${nodeId}-out-${i}`),
      value: type === 'input' ? Math.random() > 0.5 : false,
      powered: false
    };

    setNodes(prev => [...prev, newNode]);
  }, []);

  const calculateNodeValue = useCallback((node: CircuitNode): boolean => {
    if (node.type === 'input') return node.value;
    
    const inputConnections = connections.filter(conn => 
      node.inputs.some(input => input === conn.to)
    );
    
    const inputValues = inputConnections.map(conn => {
      const sourceNode = nodes.find(n => n.outputs.includes(conn.from));
      return sourceNode ? calculateNodeValue(sourceNode) : false;
    });

    switch (node.type) {
      case 'and':
        return inputValues.length === 2 && inputValues.every(v => v);
      case 'or':
        return inputValues.some(v => v);
      case 'not':
        return !inputValues[0];
      case 'xor':
        return inputValues.length === 2 && inputValues[0] !== inputValues[1];
      default:
        return false;
    }
  }, [nodes, connections]);

  const updateCircuit = useCallback(() => {
    const updatedNodes = nodes.map(node => ({
      ...node,
      powered: calculateNodeValue(node)
    }));

    const newCurrentPattern = updatedNodes
      .filter(node => node.type === 'output')
      .map(node => node.powered);

    setNodes(updatedNodes);
    setCurrentPattern(newCurrentPattern);
    
    // Check if level is complete
    if (newCurrentPattern.length === targetPattern.length && 
        newCurrentPattern.every((val, i) => val === targetPattern[i])) {
      if (!levelComplete) {
        setLevelComplete(true);
        setScore(prev => prev + level * 100);
      }
    }
  }, [nodes, connections, calculateNodeValue, targetPattern, levelComplete, level]);

  const handleMouseDown = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPlaying || isPaused) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = GAME_WIDTH / rect.width;
    const scaleY = GAME_HEIGHT / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;

    // Check if clicking on a node
    const clickedNode = nodes.find(node => {
      const dx = x - node.x;
      const dy = y - node.y;
      return Math.sqrt(dx * dx + dy * dy) < NODE_SIZE / 2;
    });

    if (clickedNode) {
      if (clickedNode.type === 'input') {
        // Toggle input value
        setNodes(prev => prev.map(node => 
          node.id === clickedNode.id ? { ...node, value: !node.value } : node
        ));
      } else {
        // Start dragging
        setDragging({
          nodeId: clickedNode.id,
          offsetX: x - clickedNode.x,
          offsetY: y - clickedNode.y
        });
      }
      setSelectedNode(clickedNode.id);
    } else {
      setSelectedNode(null);
    }
  }, [isPlaying, isPaused, nodes]);

  const handleMouseMove = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!dragging) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = GAME_WIDTH / rect.width;
    const scaleY = GAME_HEIGHT / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;

    setNodes(prev => prev.map(node => 
      node.id === dragging.nodeId 
        ? { 
            ...node, 
            x: Math.max(NODE_SIZE/2, Math.min(GAME_WIDTH - NODE_SIZE/2, x - dragging.offsetX)),
            y: Math.max(NODE_SIZE/2, Math.min(GAME_HEIGHT - NODE_SIZE/2, y - dragging.offsetY))
          }
        : node
    ));
  }, [dragging]);

  const handleMouseUp = useCallback(() => {
    setDragging(null);
  }, []);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;

    // Clear canvas
    const gradient = ctx.createLinearGradient(0, 0, GAME_WIDTH, GAME_HEIGHT);
    gradient.addColorStop(0, '#000814');
    gradient.addColorStop(1, '#001d3d');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Draw grid
    ctx.strokeStyle = '#001a33';
    ctx.lineWidth = 1;
    for (let x = 0; x < GAME_WIDTH; x += 20) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, GAME_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y < GAME_HEIGHT; y += 20) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(GAME_WIDTH, y);
      ctx.stroke();
    }

    // Draw connections
    connections.forEach(connection => {
      const fromNode = nodes.find(n => n.outputs.includes(connection.from));
      const toNode = nodes.find(n => n.inputs.includes(connection.to));
      
      if (fromNode && toNode) {
        ctx.strokeStyle = connection.active ? '#0aff9d' : '#666666';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(fromNode.x + NODE_SIZE/2, fromNode.y);
        ctx.lineTo(toNode.x - NODE_SIZE/2, toNode.y);
        ctx.stroke();
      }
    });

    // Draw nodes
    nodes.forEach(node => {
      const nodeConfig = nodeTypes[node.type];
      
      // Node body
      ctx.fillStyle = node.powered ? nodeConfig.color : nodeConfig.color + '40';
      ctx.strokeStyle = selectedNode === node.id ? '#ffffff' : nodeConfig.color;
      ctx.lineWidth = selectedNode === node.id ? 3 : 2;
      
      if (node.powered) {
        ctx.shadowColor = nodeConfig.color;
        ctx.shadowBlur = 15;
      }
      
      ctx.beginPath();
      ctx.arc(node.x, node.y, NODE_SIZE/2, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Node label
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(node.type.toUpperCase(), node.x, node.y + 4);
      
      if (node.type === 'input') {
        ctx.fillText(node.value ? '1' : '0', node.x, node.y - 25);
      }
    });

    // Draw target pattern
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('Target Pattern:', 10, 30);
    
    targetPattern.forEach((target, i) => {
      ctx.fillStyle = target ? '#0aff9d' : '#ff0099';
      ctx.fillRect(150 + i * 30, 15, 20, 20);
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(target ? '1' : '0', 160 + i * 30, 29);
    });

    // Draw current pattern
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';
    ctx.fillText('Current:', 10, 60);
    
    currentPattern.forEach((current, i) => {
      const matches = current === targetPattern[i];
      ctx.fillStyle = matches ? (current ? '#0aff9d' : '#333333') : '#ff0000';
      ctx.fillRect(100 + i * 30, 45, 20, 20);
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText(current ? '1' : '0', 110 + i * 30, 59);
    });

    // Level complete message
    if (levelComplete) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
      
      ctx.fillStyle = '#0aff9d';
      ctx.font = 'bold 36px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('LEVEL COMPLETE!', GAME_WIDTH/2, GAME_HEIGHT/2);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '18px Arial';
      ctx.fillText('Click to continue', GAME_WIDTH/2, GAME_HEIGHT/2 + 40);
    }

    ctx.textAlign = 'left';
  }, [nodes, connections, selectedNode, targetPattern, currentPattern, levelComplete]);

  useEffect(() => {
    updateCircuit();
  }, [nodes, connections, updateCircuit]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    if (levelComplete) {
      setTimeout(() => {
        setLevel(prev => prev + 1);
        generateLevel(level + 1);
      }, 2000);
    }
  }, [levelComplete, level, generateLevel]);

  const startGame = () => {
    setScore(0);
    setLevel(1);
    generateLevel(1);
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => {
    setIsPlaying(false);
    setScore(0);
    setLevel(1);
  };

  return (
    <GameLayout
      title="Circuit Breaker"
      description="Design logic circuits to match target patterns!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          className="border-2 border-neon-green rounded-lg cursor-pointer max-w-full h-auto"
          style={{ background: 'linear-gradient(135deg, #000814, #001d3d)' }}
        />
        
        {isPlaying && (
          <div className="flex gap-2 flex-wrap justify-center">
            {Object.entries(nodeTypes).map(([type, config]) => (
              <button
                key={type}
                onClick={() => addNode(type as keyof typeof nodeTypes, 300, 300)}
                className="px-3 py-2 rounded border-2 hover:bg-opacity-20 transition-all"
                style={{ 
                  borderColor: config.color,
                  backgroundColor: config.color + '10',
                  color: config.color
                }}
              >
                {type.toUpperCase()}
              </button>
            ))}
          </div>
        )}
        
        <div className="text-center text-sm text-gray-400 max-w-md">
          Level: {level} | Click inputs to toggle, drag nodes to move them. 
          Create logic circuits to match the target output pattern!
        </div>
      </div>
    </GameLayout>
  );
}
