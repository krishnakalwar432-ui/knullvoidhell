import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface Player {
  x: number;
  y: number;
  health: number;
  maxHealth: number;
  mana: number;
  maxMana: number;
  level: number;
  xp: number;
  xpToNext: number;
  inventory: string[];
}

interface Enemy {
  id: string;
  x: number;
  y: number;
  health: number;
  maxHealth: number;
  type: 'virus' | 'firewall' | 'trojan' | 'spam_bot';
  damage: number;
  color: string;
  ai: 'passive' | 'aggressive' | 'guard';
}

interface Item {
  id: string;
  x: number;
  y: number;
  type: 'health_kit' | 'mana_crystal' | 'upgrade_chip' | 'key_data';
  collected: boolean;
  color: string;
}

interface DungeonCell {
  x: number;
  y: number;
  type: 'wall' | 'floor' | 'door' | 'stairs';
  passable: boolean;
}

const DUNGEON_SIZE = 20;
const CELL_SIZE = 25;
const CANVAS_WIDTH = DUNGEON_SIZE * CELL_SIZE;
const CANVAS_HEIGHT = DUNGEON_SIZE * CELL_SIZE;

export default function DigitalDungeonCrawler() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [player, setPlayer] = useState<Player>({
    x: 1, y: 1,
    health: 100, maxHealth: 100,
    mana: 50, maxMana: 50,
    level: 1, xp: 0, xpToNext: 100,
    inventory: []
  });
  const [dungeon, setDungeon] = useState<DungeonCell[][]>([]);
  const [enemies, setEnemies] = useState<Enemy[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});
  const [floor, setFloor] = useState(1);
  const [turnBased, setTurnBased] = useState(false);

  const generateDungeon = useCallback(() => {
    const newDungeon: DungeonCell[][] = [];
    
    // Initialize with walls
    for (let y = 0; y < DUNGEON_SIZE; y++) {
      newDungeon[y] = [];
      for (let x = 0; x < DUNGEON_SIZE; x++) {
        newDungeon[y][x] = {
          x, y,
          type: 'wall',
          passable: false
        };
      }
    }

    // Create simple maze pattern
    for (let y = 1; y < DUNGEON_SIZE - 1; y += 2) {
      for (let x = 1; x < DUNGEON_SIZE - 1; x += 2) {
        newDungeon[y][x] = { x, y, type: 'floor', passable: true };
        
        // Random connections
        if (x + 2 < DUNGEON_SIZE - 1 && Math.random() > 0.3) {
          newDungeon[y][x + 1] = { x: x + 1, y, type: 'floor', passable: true };
        }
        if (y + 2 < DUNGEON_SIZE - 1 && Math.random() > 0.3) {
          newDungeon[y + 1][x] = { x, y: y + 1, type: 'floor', passable: true };
        }
      }
    }

    // Add stairs
    newDungeon[DUNGEON_SIZE - 2][DUNGEON_SIZE - 2] = {
      x: DUNGEON_SIZE - 2, y: DUNGEON_SIZE - 2,
      type: 'stairs', passable: true
    };

    setDungeon(newDungeon);
    
    // Generate enemies
    const newEnemies: Enemy[] = [];
    const enemyTypes = [
      { type: 'virus' as const, health: 30, damage: 15, color: '#ff0099', ai: 'aggressive' as const },
      { type: 'firewall' as const, health: 60, damage: 10, color: '#ff6600', ai: 'guard' as const },
      { type: 'trojan' as const, health: 40, damage: 20, color: '#7000ff', ai: 'passive' as const },
      { type: 'spam_bot' as const, health: 20, damage: 8, color: '#ffff00', ai: 'aggressive' as const }
    ];

    for (let i = 0; i < 3 + floor; i++) {
      const enemyTemplate = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
      let x, y;
      do {
        x = Math.floor(Math.random() * DUNGEON_SIZE);
        y = Math.floor(Math.random() * DUNGEON_SIZE);
      } while (!newDungeon[y] || !newDungeon[y][x] || !newDungeon[y][x].passable || (x === 1 && y === 1));

      newEnemies.push({
        id: `enemy-${i}`,
        x, y,
        health: enemyTemplate.health + floor * 5,
        maxHealth: enemyTemplate.health + floor * 5,
        type: enemyTemplate.type,
        damage: enemyTemplate.damage + floor * 2,
        color: enemyTemplate.color,
        ai: enemyTemplate.ai
      });
    }
    setEnemies(newEnemies);

    // Generate items
    const newItems: Item[] = [];
    const itemTypes = [
      { type: 'health_kit' as const, color: '#00ff00' },
      { type: 'mana_crystal' as const, color: '#0066ff' },
      { type: 'upgrade_chip' as const, color: '#ffff00' },
      { type: 'key_data' as const, color: '#ff00ff' }
    ];

    for (let i = 0; i < 5; i++) {
      const itemTemplate = itemTypes[Math.floor(Math.random() * itemTypes.length)];
      let x, y;
      do {
        x = Math.floor(Math.random() * DUNGEON_SIZE);
        y = Math.floor(Math.random() * DUNGEON_SIZE);
      } while (!newDungeon[y] || !newDungeon[y][x] || !newDungeon[y][x].passable);

      newItems.push({
        id: `item-${i}`,
        x, y,
        type: itemTemplate.type,
        collected: false,
        color: itemTemplate.color
      });
    }
    setItems(newItems);

  }, [floor]);

  const movePlayer = useCallback((dx: number, dy: number) => {
    if (turnBased) return;

    setPlayer(prev => {
      const newX = prev.x + dx;
      const newY = prev.y + dy;

      // Check bounds and passability
      if (newX < 0 || newX >= DUNGEON_SIZE || newY < 0 || newY >= DUNGEON_SIZE) return prev;
      if (!dungeon[newY] || !dungeon[newY][newX] || !dungeon[newY][newX].passable) return prev;

      // Check for stairs
      if (dungeon[newY][newX].type === 'stairs') {
        setFloor(f => f + 1);
        setScore(s => s + 200);
        setTimeout(() => generateDungeon(), 100);
        return { ...prev, x: 1, y: 1 };
      }

      setTurnBased(true);
      setTimeout(() => setTurnBased(false), 200);

      return { ...prev, x: newX, y: newY };
    });
  }, [dungeon, turnBased, generateDungeon]);

  const combat = useCallback((enemy: Enemy) => {
    // Player attacks enemy
    const playerDamage = 20 + player.level * 5;
    enemy.health -= playerDamage;

    if (enemy.health <= 0) {
      setEnemies(prev => prev.filter(e => e.id !== enemy.id));
      const xpGain = 20 + enemy.maxHealth / 5;
      setPlayer(prev => {
        const newXp = prev.xp + xpGain;
        const levelUp = newXp >= prev.xpToNext;
        return {
          ...prev,
          xp: levelUp ? newXp - prev.xpToNext : newXp,
          level: levelUp ? prev.level + 1 : prev.level,
          xpToNext: levelUp ? prev.xpToNext + 50 : prev.xpToNext,
          maxHealth: levelUp ? prev.maxHealth + 20 : prev.maxHealth,
          health: levelUp ? prev.maxHealth + 20 : prev.health
        };
      });
      setScore(prev => prev + 50);
    } else {
      // Enemy attacks back
      setPlayer(prev => ({
        ...prev,
        health: Math.max(0, prev.health - enemy.damage)
      }));
    }
  }, [player.level]);

  const useItem = useCallback((item: Item) => {
    if (item.collected) return;

    item.collected = true;
    
    switch (item.type) {
      case 'health_kit':
        setPlayer(prev => ({ ...prev, health: Math.min(prev.maxHealth, prev.health + 40) }));
        break;
      case 'mana_crystal':
        setPlayer(prev => ({ ...prev, mana: Math.min(prev.maxMana, prev.mana + 20) }));
        break;
      case 'upgrade_chip':
        setPlayer(prev => ({ ...prev, maxHealth: prev.maxHealth + 10, maxMana: prev.maxMana + 5 }));
        break;
      case 'key_data':
        setPlayer(prev => ({ ...prev, inventory: [...prev.inventory, 'key_data'] }));
        break;
    }
    
    setScore(prev => prev + 25);
  }, []);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused || turnBased) return;

    // Move enemies
    setEnemies(prev => prev.map(enemy => {
      if (enemy.ai === 'passive') return enemy;

      const dx = player.x - enemy.x;
      const dy = player.y - enemy.y;
      const distance = Math.abs(dx) + Math.abs(dy);

      if (enemy.ai === 'aggressive' && distance < 5) {
        const moveX = dx > 0 ? 1 : dx < 0 ? -1 : 0;
        const moveY = dy > 0 ? 1 : dy < 0 ? -1 : 0;
        
        let newX = enemy.x;
        let newY = enemy.y;

        if (Math.abs(dx) > Math.abs(dy)) {
          newX += moveX;
        } else {
          newY += moveY;
        }

        // Check if move is valid
        if (dungeon[newY] && dungeon[newY][newX] && dungeon[newY][newX].passable) {
          // Check for collision with player
          if (newX === player.x && newY === player.y) {
            combat(enemy);
            return enemy;
          }
          return { ...enemy, x: newX, y: newY };
        }
      }

      return enemy;
    }));

    // Check item collection
    items.forEach(item => {
      if (!item.collected && item.x === player.x && item.y === player.y) {
        useItem(item);
      }
    });

    // Check game over
    if (player.health <= 0) {
      setIsPlaying(false);
    }

  }, [isPlaying, isPaused, turnBased, player, dungeon, items, combat, useItem]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#000814';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw dungeon
    dungeon.forEach(row => {
      row.forEach(cell => {
        const x = cell.x * CELL_SIZE;
        const y = cell.y * CELL_SIZE;

        switch (cell.type) {
          case 'wall':
            ctx.fillStyle = '#333333';
            ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
            break;
          case 'floor':
            ctx.fillStyle = '#001122';
            ctx.fillRect(x, y, CELL_SIZE, CELL_SIZE);
            ctx.strokeStyle = '#002244';
            ctx.strokeRect(x, y, CELL_SIZE, CELL_SIZE);
            break;
          case 'stairs':
            ctx.fillStyle = '#ffff00';
            ctx.fillRect(x + 5, y + 5, CELL_SIZE - 10, CELL_SIZE - 10);
            break;
        }
      });
    });

    // Draw items
    items.forEach(item => {
      if (!item.collected) {
        const x = item.x * CELL_SIZE + CELL_SIZE/2;
        const y = item.y * CELL_SIZE + CELL_SIZE/2;
        
        ctx.fillStyle = item.color;
        ctx.shadowColor = item.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    });

    // Draw enemies
    enemies.forEach(enemy => {
      const x = enemy.x * CELL_SIZE + CELL_SIZE/2;
      const y = enemy.y * CELL_SIZE + CELL_SIZE/2;
      
      ctx.fillStyle = enemy.color;
      ctx.shadowColor = enemy.color;
      ctx.shadowBlur = 10;
      ctx.fillRect(x - 8, y - 8, 16, 16);
      ctx.shadowBlur = 0;

      // Health bar
      const healthPercent = enemy.health / enemy.maxHealth;
      ctx.fillStyle = '#ff0000';
      ctx.fillRect(x - 10, y - 15, 20, 3);
      ctx.fillStyle = '#00ff00';
      ctx.fillRect(x - 10, y - 15, 20 * healthPercent, 3);
    });

    // Draw player
    const playerX = player.x * CELL_SIZE + CELL_SIZE/2;
    const playerY = player.y * CELL_SIZE + CELL_SIZE/2;
    
    ctx.fillStyle = '#0aff9d';
    ctx.shadowColor = '#0aff9d';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(playerX, playerY, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

  }, [dungeon, player, enemies, items]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 200);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => ({ ...prev, [e.key]: true }));
      
      if (!turnBased) {
        switch (e.key) {
          case 'ArrowUp':
          case 'w':
          case 'W':
            movePlayer(0, -1);
            break;
          case 'ArrowDown':
          case 's':
          case 'S':
            movePlayer(0, 1);
            break;
          case 'ArrowLeft':
          case 'a':
          case 'A':
            movePlayer(-1, 0);
            break;
          case 'ArrowRight':
          case 'd':
          case 'D':
            movePlayer(1, 0);
            break;
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => ({ ...prev, [e.key]: false }));
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [movePlayer, turnBased]);

  const startGame = () => {
    setScore(0);
    setFloor(1);
    setPlayer({
      x: 1, y: 1,
      health: 100, maxHealth: 100,
      mana: 50, maxMana: 50,
      level: 1, xp: 0, xpToNext: 100,
      inventory: []
    });
    setTurnBased(false);
    generateDungeon();
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Digital Dungeon Crawler"
      description="Explore dungeons in digital space!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <div className="flex gap-4 items-start">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="border-2 border-neon-green rounded-lg"
          />
          
          {isPlaying && (
            <div className="bg-gray-800 p-4 rounded-lg text-white min-w-[200px]">
              <h3 className="text-lg font-bold mb-2">Player Stats</h3>
              <div className="space-y-1 text-sm">
                <div>Level: {player.level}</div>
                <div>XP: {player.xp}/{player.xpToNext}</div>
                <div>Health: {player.health}/{player.maxHealth}</div>
                <div>Mana: {player.mana}/{player.maxMana}</div>
                <div>Floor: {floor}</div>
              </div>
              
              {player.inventory.length > 0 && (
                <div className="mt-4">
                  <h4 className="font-bold">Inventory:</h4>
                  <div className="text-xs">
                    {player.inventory.map((item, i) => (
                      <div key={i}>{item}</div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        
        <div className="text-center text-sm text-gray-400 max-w-md">
          WASD/Arrows to move. Fight enemies, collect items, find stairs to next floor!
        </div>
      </div>
    </GameLayout>
  );
}
