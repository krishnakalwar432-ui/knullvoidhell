import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
  width: number;
  height: number;
  onGround: boolean;
  gravityDirection: 'down' | 'up' | 'left' | 'right';
  trail: {x: number, y: number, alpha: number}[];
}

interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'solid' | 'gravity_zone' | 'moving';
  color: string;
  gravityDirection?: 'down' | 'up' | 'left' | 'right';
  moveDirection?: number;
  moveSpeed?: number;
}

interface GravityOrb {
  x: number;
  y: number;
  collected: boolean;
  gravityDirection: 'down' | 'up' | 'left' | 'right';
  color: string;
  pulsePhase: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  gravityDirection: 'down' | 'up' | 'left' | 'right';
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const MOVE_SPEED = 5;
const JUMP_FORCE = 12;

const gravityColors = {
  down: '#ff0099',
  up: '#0aff9d',
  left: '#7000ff',
  right: '#00ffff'
};

export default function GravityFlipAdventure() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [level, setLevel] = useState(1);
  const [player, setPlayer] = useState<Player>({
    x: 50,
    y: GAME_HEIGHT - 100,
    vx: 0,
    vy: 0,
    width: 20,
    height: 30,
    onGround: false,
    gravityDirection: 'down',
    trail: []
  });
  const [platforms, setPlatforms] = useState<Platform[]>([]);
  const [gravityOrbs, setGravityOrbs] = useState<GravityOrb[]>([]);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});
  const [levelComplete, setLevelComplete] = useState(false);

  const generateLevel = useCallback((levelNum: number) => {
    const newPlatforms: Platform[] = [
      // Boundaries
      { x: 0, y: -20, width: GAME_WIDTH, height: 20, color: '#001d3d', type: 'solid' },
      { x: 0, y: GAME_HEIGHT, width: GAME_WIDTH, height: 20, color: '#001d3d', type: 'solid' },
      { x: -20, y: 0, width: 20, height: GAME_HEIGHT, color: '#001d3d', type: 'solid' },
      { x: GAME_WIDTH, y: 0, width: 20, height: GAME_HEIGHT, color: '#001d3d', type: 'solid' },
      
      // Starting platform
      { x: 0, y: GAME_HEIGHT - 50, width: 150, height: 50, color: '#7000ff', type: 'solid' },
      
      // Regular platforms
      { x: 200, y: GAME_HEIGHT - 150, width: 100, height: 20, color: '#ff0099', type: 'solid' },
      { x: 350, y: GAME_HEIGHT - 250, width: 80, height: 20, color: '#00ffff', type: 'moving', moveDirection: 1, moveSpeed: 2 },
      { x: 500, y: GAME_HEIGHT - 200, width: 120, height: 20, color: '#0aff9d', type: 'solid' },
      
      // Gravity zones
      { x: 150, y: GAME_HEIGHT - 300, width: 60, height: 100, color: gravityColors.up, type: 'gravity_zone', gravityDirection: 'up' },
      { x: 650, y: 200, width: 100, height: 60, color: gravityColors.left, type: 'gravity_zone', gravityDirection: 'left' },
      { x: 300, y: 100, width: 200, height: 60, color: gravityColors.right, type: 'gravity_zone', gravityDirection: 'right' },
      
      // Additional platforms for higher levels
      ...(levelNum > 1 ? [
        { x: 100, y: 150, width: 80, height: 20, color: '#ffa500', type: 'solid' },
        { x: 600, y: 50, width: 60, height: 60, color: gravityColors.down, type: 'gravity_zone', gravityDirection: 'down' }
      ] : [])
    ];

    const newGravityOrbs: GravityOrb[] = [
      { x: 225, y: GAME_HEIGHT - 190, collected: false, gravityDirection: 'up', color: gravityColors.up, pulsePhase: 0 },
      { x: 375, y: GAME_HEIGHT - 290, collected: false, gravityDirection: 'left', color: gravityColors.left, pulsePhase: 0 },
      { x: 525, y: GAME_HEIGHT - 240, collected: false, gravityDirection: 'right', color: gravityColors.right, pulsePhase: 0 },
      { x: 700, y: 250, collected: false, gravityDirection: 'down', color: gravityColors.down, pulsePhase: 0 }
    ];

    setPlatforms(newPlatforms);
    setGravityOrbs(newGravityOrbs);
    setParticles([]);
    setPlayer(prev => ({
      ...prev,
      x: 50,
      y: GAME_HEIGHT - 100,
      vx: 0,
      vy: 0,
      gravityDirection: 'down',
      trail: []
    }));
    setLevelComplete(false);
  }, []);

  const createParticles = useCallback((x: number, y: number, color: string, count: number = 8) => {
    const newParticles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      newParticles.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 10,
        vy: (Math.random() - 0.5) * 10,
        life: 30,
        color,
        gravityDirection: player.gravityDirection
      });
    }
    setParticles(prev => [...prev, ...newParticles]);
  }, [player.gravityDirection]);

  const applyGravity = useCallback((entity: {vx: number, vy: number}, direction: string, strength: number = 0.5) => {
    switch (direction) {
      case 'down':
        entity.vy += strength;
        break;
      case 'up':
        entity.vy -= strength;
        break;
      case 'left':
        entity.vx -= strength;
        break;
      case 'right':
        entity.vx += strength;
        break;
    }
  }, []);

  const checkCollision = useCallback((rect1: any, rect2: any) => {
    return rect1.x < rect2.x + rect2.width &&
           rect1.x + rect1.width > rect2.x &&
           rect1.y < rect2.y + rect2.height &&
           rect1.y + rect1.height > rect2.y;
  }, []);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused) return;

    setPlayer(prevPlayer => {
      let newPlayer = { ...prevPlayer };

      // Handle input based on gravity direction
      const jumpForce = JUMP_FORCE;
      if (keys['ArrowLeft'] || keys['a'] || keys['A']) {
        if (newPlayer.gravityDirection === 'up' || newPlayer.gravityDirection === 'down') {
          newPlayer.vx = -MOVE_SPEED;
        } else {
          newPlayer.vy = -MOVE_SPEED;
        }
      } else if (keys['ArrowRight'] || keys['d'] || keys['D']) {
        if (newPlayer.gravityDirection === 'up' || newPlayer.gravityDirection === 'down') {
          newPlayer.vx = MOVE_SPEED;
        } else {
          newPlayer.vy = MOVE_SPEED;
        }
      } else {
        // Apply friction
        if (newPlayer.gravityDirection === 'up' || newPlayer.gravityDirection === 'down') {
          newPlayer.vx *= 0.8;
        } else {
          newPlayer.vy *= 0.8;
        }
      }

      if ((keys['ArrowUp'] || keys['w'] || keys['W'] || keys[' ']) && newPlayer.onGround) {
        switch (newPlayer.gravityDirection) {
          case 'down':
            newPlayer.vy = -jumpForce;
            break;
          case 'up':
            newPlayer.vy = jumpForce;
            break;
          case 'left':
            newPlayer.vx = jumpForce;
            break;
          case 'right':
            newPlayer.vx = -jumpForce;
            break;
        }
        newPlayer.onGround = false;
        createParticles(newPlayer.x + newPlayer.width/2, newPlayer.y + newPlayer.height/2, gravityColors[newPlayer.gravityDirection]);
      }

      // Apply gravity
      applyGravity(newPlayer, newPlayer.gravityDirection);

      // Update position
      newPlayer.x += newPlayer.vx;
      newPlayer.y += newPlayer.vy;

      // Check platform collisions
      newPlayer.onGround = false;
      platforms.forEach(platform => {
        if (platform.type === 'gravity_zone') {
          if (checkCollision(newPlayer, platform) && platform.gravityDirection) {
            if (newPlayer.gravityDirection !== platform.gravityDirection) {
              newPlayer.gravityDirection = platform.gravityDirection;
              newPlayer.vx *= 0.5;
              newPlayer.vy *= 0.5;
              createParticles(newPlayer.x + newPlayer.width/2, newPlayer.y + newPlayer.height/2, platform.color, 15);
            }
          }
          return;
        }

        if (checkCollision(newPlayer, platform)) {
          // Handle collision based on gravity direction
          switch (newPlayer.gravityDirection) {
            case 'down':
              if (prevPlayer.y + prevPlayer.height <= platform.y && newPlayer.vy > 0) {
                newPlayer.y = platform.y - newPlayer.height;
                newPlayer.vy = 0;
                newPlayer.onGround = true;
              }
              break;
            case 'up':
              if (prevPlayer.y >= platform.y + platform.height && newPlayer.vy < 0) {
                newPlayer.y = platform.y + platform.height;
                newPlayer.vy = 0;
                newPlayer.onGround = true;
              }
              break;
            case 'left':
              if (prevPlayer.x >= platform.x + platform.width && newPlayer.vx < 0) {
                newPlayer.x = platform.x + platform.width;
                newPlayer.vx = 0;
                newPlayer.onGround = true;
              }
              break;
            case 'right':
              if (prevPlayer.x + prevPlayer.width <= platform.x && newPlayer.vx > 0) {
                newPlayer.x = platform.x - newPlayer.width;
                newPlayer.vx = 0;
                newPlayer.onGround = true;
              }
              break;
          }
        }
      });

      // Update trail
      newPlayer.trail.push({
        x: newPlayer.x + newPlayer.width/2,
        y: newPlayer.y + newPlayer.height/2,
        alpha: 1
      });
      
      newPlayer.trail = newPlayer.trail.map(point => ({
        ...point,
        alpha: point.alpha - 0.05
      })).filter(point => point.alpha > 0).slice(-20);

      // Boundary checks with wrapping or stopping
      if (newPlayer.x < 0) newPlayer.x = 0;
      if (newPlayer.x + newPlayer.width > GAME_WIDTH) newPlayer.x = GAME_WIDTH - newPlayer.width;
      if (newPlayer.y < 0) newPlayer.y = 0;
      if (newPlayer.y + newPlayer.height > GAME_HEIGHT) newPlayer.y = GAME_HEIGHT - newPlayer.height;

      return newPlayer;
    });

    // Update moving platforms
    setPlatforms(prevPlatforms => prevPlatforms.map(platform => {
      if (platform.type === 'moving' && platform.moveDirection !== undefined) {
        let newX = platform.x + (platform.moveSpeed || 1) * platform.moveDirection;
        let newDirection = platform.moveDirection;
        
        if (newX <= 0 || newX + platform.width >= GAME_WIDTH) {
          newDirection = -platform.moveDirection;
          newX = platform.x + (platform.moveSpeed || 1) * newDirection;
        }
        
        return { ...platform, x: newX, moveDirection: newDirection };
      }
      return platform;
    }));

    // Update gravity orbs
    setGravityOrbs(prevOrbs => prevOrbs.map(orb => {
      const newOrb = { ...orb, pulsePhase: orb.pulsePhase + 0.1 };
      
      if (!newOrb.collected && checkCollision(player, { ...newOrb, width: 20, height: 20 })) {
        setScore(prevScore => prevScore + 50);
        createParticles(orb.x + 10, orb.y + 10, orb.color, 12);
        newOrb.collected = true;
      }
      
      return newOrb;
    }));

    // Update particles
    setParticles(prevParticles => prevParticles.map(particle => {
      applyGravity(particle, particle.gravityDirection, 0.1);
      
      return {
        ...particle,
        x: particle.x + particle.vx,
        y: particle.y + particle.vy,
        vx: particle.vx * 0.98,
        vy: particle.vy * 0.98,
        life: particle.life - 1
      };
    }).filter(particle => particle.life > 0));

    // Check level completion
    const allCollected = gravityOrbs.every(orb => orb.collected);
    if (allCollected && player.x > GAME_WIDTH - 100) {
      setLevelComplete(true);
    }

  }, [isPlaying, isPaused, keys, player, platforms, gravityOrbs, checkCollision, applyGravity, createParticles]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;

    // Dynamic background based on gravity
    const bgGradient = ctx.createLinearGradient(0, 0, GAME_WIDTH, GAME_HEIGHT);
    const gravityColor = gravityColors[player.gravityDirection];
    bgGradient.addColorStop(0, '#000814');
    bgGradient.addColorStop(0.5, gravityColor + '20');
    bgGradient.addColorStop(1, '#001122');
    ctx.fillStyle = bgGradient;
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Gravity field lines
    ctx.strokeStyle = gravityColor + '30';
    ctx.lineWidth = 1;
    const lineSpacing = 40;
    
    switch (player.gravityDirection) {
      case 'down':
        for (let x = 0; x < GAME_WIDTH; x += lineSpacing) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, GAME_HEIGHT);
          ctx.stroke();
        }
        break;
      case 'up':
        for (let x = 0; x < GAME_WIDTH; x += lineSpacing) {
          ctx.beginPath();
          ctx.moveTo(x, GAME_HEIGHT);
          ctx.lineTo(x, 0);
          ctx.stroke();
        }
        break;
      case 'left':
        for (let y = 0; y < GAME_HEIGHT; y += lineSpacing) {
          ctx.beginPath();
          ctx.moveTo(GAME_WIDTH, y);
          ctx.lineTo(0, y);
          ctx.stroke();
        }
        break;
      case 'right':
        for (let y = 0; y < GAME_HEIGHT; y += lineSpacing) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(GAME_WIDTH, y);
          ctx.stroke();
        }
        break;
    }

    // Draw platforms
    platforms.forEach(platform => {
      ctx.fillStyle = platform.color;
      if (platform.type === 'gravity_zone') {
        ctx.globalAlpha = 0.4;
        ctx.shadowColor = platform.color;
        ctx.shadowBlur = 15;
      } else {
        ctx.globalAlpha = 1;
        ctx.shadowBlur = 8;
      }
      
      ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;
      
      // Gravity zone arrows
      if (platform.type === 'gravity_zone' && platform.gravityDirection) {
        ctx.fillStyle = '#ffffff';
        ctx.font = '20px Arial';
        ctx.textAlign = 'center';
        const arrows = { down: '↓', up: '↑', left: '←', right: '→' };
        ctx.fillText(
          arrows[platform.gravityDirection],
          platform.x + platform.width/2,
          platform.y + platform.height/2 + 7
        );
      }
    });

    // Draw player trail
    player.trail.forEach((point, index) => {
      ctx.save();
      ctx.globalAlpha = point.alpha;
      ctx.fillStyle = gravityColors[player.gravityDirection];
      ctx.beginPath();
      ctx.arc(point.x, point.y, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });

    // Draw player
    ctx.fillStyle = gravityColors[player.gravityDirection];
    ctx.shadowColor = gravityColors[player.gravityDirection];
    ctx.shadowBlur = 12;
    ctx.fillRect(player.x, player.y, player.width, player.height);
    ctx.shadowBlur = 0;

    // Draw gravity orbs
    gravityOrbs.forEach(orb => {
      if (!orb.collected) {
        const pulse = Math.sin(orb.pulsePhase) * 0.3 + 0.7;
        
        ctx.save();
        ctx.globalAlpha = pulse;
        ctx.fillStyle = orb.color;
        ctx.shadowColor = orb.color;
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.arc(orb.x + 10, orb.y + 10, 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    });

    // Draw particles
    particles.forEach(particle => {
      ctx.save();
      ctx.globalAlpha = particle.life / 30;
      ctx.fillStyle = particle.color;
      ctx.fillRect(particle.x - 1, particle.y - 1, 2, 2);
      ctx.restore();
    });

    // UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(`Level: ${level}`, 10, 30);
    ctx.fillText(`Gravity: ${player.gravityDirection.toUpperCase()}`, 10, 50);
    
    if (levelComplete) {
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);
      
      ctx.fillStyle = gravityColors[player.gravityDirection];
      ctx.font = 'bold 32px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('GRAVITY MASTERED!', GAME_WIDTH/2, GAME_HEIGHT/2);
      ctx.textAlign = 'left';
    }
  }, [player, platforms, gravityOrbs, particles, level, levelComplete]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => ({ ...prev, [e.key]: true }));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => ({ ...prev, [e.key]: false }));
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useEffect(() => {
    if (levelComplete) {
      setTimeout(() => {
        setLevel(prev => prev + 1);
        generateLevel(level + 1);
      }, 2000);
    }
  }, [levelComplete, level, generateLevel]);

  const startGame = () => {
    setScore(0);
    setLevel(1);
    generateLevel(1);
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => {
    setIsPlaying(false);
    setScore(0);
    setLevel(1);
  };

  return (
    <GameLayout
      title="Gravity Flip Adventure"
      description="Navigate through worlds where gravity changes direction!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          className="border-2 border-neon-green rounded-lg max-w-full h-auto"
          style={{ background: 'linear-gradient(135deg, #000814, #001122)' }}
        />
        
        <div className="text-center text-sm text-gray-400 max-w-md">
          WASD/Arrows to move, Space to jump. Walk through colored zones to change gravity direction.
          Collect all gravity orbs to complete each level!
        </div>
      </div>
    </GameLayout>
  );
}
