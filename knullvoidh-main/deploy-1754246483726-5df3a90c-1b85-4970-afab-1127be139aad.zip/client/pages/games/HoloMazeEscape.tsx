import React, { useState, useEffect, useRef, useCallback } from 'react';
import GameLayout from '@/components/GameLayout';

interface Position {
  x: number;
  y: number;
}

const HoloMazeEscape: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<'playing' | 'paused' | 'won'>('playing');
  const [score, setScore] = useState(0);
  const [level, setLevel] = useState(1);
  const [player, setPlayer] = useState<Position>({ x: 1, y: 1 });
  const [maze, setMaze] = useState<number[][]>([]);
  const [exit, setExit] = useState<Position>({ x: 18, y: 18 });
  const [keys, setKeys] = useState<Set<string>>(new Set());
  const [timeLeft, setTimeLeft] = useState(60);

  const CANVAS_WIDTH = 600;
  const CANVAS_HEIGHT = 600;
  const MAZE_SIZE = 20;
  const CELL_SIZE = CANVAS_WIDTH / MAZE_SIZE;

  // Generate maze using simple algorithm
  const generateMaze = useCallback(() => {
    const newMaze: number[][] = Array(MAZE_SIZE).fill(0).map(() => Array(MAZE_SIZE).fill(1));
    
    // Simple maze generation - create paths
    for (let y = 1; y < MAZE_SIZE - 1; y += 2) {
      for (let x = 1; x < MAZE_SIZE - 1; x += 2) {
        newMaze[y][x] = 0; // Create open space
        
        // Random path direction
        if (Math.random() > 0.5 && x + 2 < MAZE_SIZE - 1) {
          newMaze[y][x + 1] = 0;
        }
        if (Math.random() > 0.5 && y + 2 < MAZE_SIZE - 1) {
          newMaze[y + 1][x] = 0;
        }
      }
    }
    
    // Ensure start and exit are open
    newMaze[1][1] = 0;
    newMaze[MAZE_SIZE - 2][MAZE_SIZE - 2] = 0;
    
    setMaze(newMaze);
    setPlayer({ x: 1, y: 1 });
    setExit({ x: MAZE_SIZE - 2, y: MAZE_SIZE - 2 });
  }, []);

  // Handle input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => new Set([...prev, e.key.toLowerCase()]));
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => {
        const newKeys = new Set(prev);
        newKeys.delete(e.key.toLowerCase());
        return newKeys;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    const interval = setInterval(() => {
      // Move player
      setPlayer(prev => {
        let newX = prev.x;
        let newY = prev.y;

        if (keys.has('w') || keys.has('arrowup')) newY = Math.max(0, prev.y - 1);
        if (keys.has('s') || keys.has('arrowdown')) newY = Math.min(MAZE_SIZE - 1, prev.y + 1);
        if (keys.has('a') || keys.has('arrowleft')) newX = Math.max(0, prev.x - 1);
        if (keys.has('d') || keys.has('arrowright')) newX = Math.min(MAZE_SIZE - 1, prev.x + 1);

        // Check wall collision
        if (maze[newY] && maze[newY][newX] === 1) {
          return prev;
        }

        return { x: newX, y: newY };
      });

      // Update timer
      setTimeLeft(prev => {
        if (prev <= 1) {
          setGameState('paused');
          return 0;
        }
        return prev - 1;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [gameState, keys, maze]);

  // Check win condition
  useEffect(() => {
    if (player.x === exit.x && player.y === exit.y) {
      setScore(prev => prev + timeLeft * 10 + level * 100);
      setLevel(prev => prev + 1);
      setTimeLeft(60 + level * 10);
      setGameState('won');
      setTimeout(() => {
        generateMaze();
        setGameState('playing');
      }, 2000);
    }
  }, [player, exit, timeLeft, level, generateMaze]);

  // Render
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#000011';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Draw maze
    for (let y = 0; y < MAZE_SIZE; y++) {
      for (let x = 0; x < MAZE_SIZE; x++) {
        if (maze[y] && maze[y][x] === 1) {
          ctx.fillStyle = '#0aff9d';
          ctx.shadowColor = '#0aff9d';
          ctx.shadowBlur = 5;
          ctx.fillRect(x * CELL_SIZE, y * CELL_SIZE, CELL_SIZE, CELL_SIZE);
          ctx.shadowBlur = 0;
        }
      }
    }

    // Draw exit
    ctx.fillStyle = '#ff0099';
    ctx.shadowColor = '#ff0099';
    ctx.shadowBlur = 15;
    ctx.fillRect(exit.x * CELL_SIZE + 5, exit.y * CELL_SIZE + 5, CELL_SIZE - 10, CELL_SIZE - 10);
    ctx.shadowBlur = 0;

    // Draw player
    ctx.fillStyle = '#ffff00';
    ctx.shadowColor = '#ffff00';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(
      player.x * CELL_SIZE + CELL_SIZE / 2,
      player.y * CELL_SIZE + CELL_SIZE / 2,
      CELL_SIZE / 3,
      0,
      Math.PI * 2
    );
    ctx.fill();
    ctx.shadowBlur = 0;

    // Draw UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px monospace';
    ctx.fillText(`Level: ${level}`, 10, 25);
    ctx.fillText(`Score: ${score}`, 10, 45);
    ctx.fillText(`Time: ${timeLeft}s`, 10, 65);

    if (gameState === 'won') {
      ctx.fillStyle = 'rgba(0, 255, 0, 0.8)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.fillStyle = '#ffffff';
      ctx.font = '32px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('MAZE ESCAPED!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
      ctx.textAlign = 'left';
    }

    if (gameState === 'paused') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      ctx.fillStyle = '#ffffff';
      ctx.font = '32px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('TIME UP!', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
      ctx.textAlign = 'left';
    }
  });

  useEffect(() => {
    generateMaze();
  }, [generateMaze]);

  const handlePause = () => {
    setGameState(prev => prev === 'playing' ? 'paused' : 'playing');
  };

  const handleReset = () => {
    setScore(0);
    setLevel(1);
    setTimeLeft(60);
    generateMaze();
    setGameState('playing');
  };

  return (
    <GameLayout
      gameTitle="Holo Maze Escape"
      gameCategory="Puzzle"
      score={score}
      isPlaying={gameState === 'playing'}
      onPause={handlePause}
      onReset={handleReset}
    >
      <div className="flex items-center justify-center min-h-[calc(100vh-64px)] p-4">
        <div className="relative">
          <canvas
            ref={canvasRef}
            width={CANVAS_WIDTH}
            height={CANVAS_HEIGHT}
            className="border border-neon-green/50 rounded-lg bg-black/20 backdrop-blur-sm shadow-2xl max-w-full h-auto"
            style={{ touchAction: 'none' }}
          />
          
          <div className="mt-4 text-center text-sm text-muted-foreground">
            <p>WASD or Arrow keys to move • Reach the pink exit before time runs out</p>
          </div>
        </div>
      </div>
    </GameLayout>
  );
};

export default HoloMazeEscape;
