import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface Plant {
  id: string;
  x: number;
  y: number;
  type: 'wheat' | 'corn' | 'energy_pod' | 'nano_fruit';
  growthStage: number;
  maxGrowthStage: number;
  waterLevel: number;
  maxWaterLevel: number;
  harvestValue: number;
  color: string;
  automatedWatering: boolean;
}

interface Farm {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  soilQuality: number;
  hasIrrigation: boolean;
  hasRobot: boolean;
}

interface Robot {
  id: string;
  x: number;
  y: number;
  task: 'idle' | 'watering' | 'harvesting' | 'planting';
  target: string | null;
  battery: number;
  maxBattery: number;
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;
const GRID_SIZE = 40;

const plantTypes = {
  wheat: { growthTime: 180, waterConsumption: 1, harvestValue: 10, color: '#FFD700', maxWater: 100 },
  corn: { growthTime: 240, waterConsumption: 1.5, harvestValue: 15, color: '#FFA500', maxWater: 120 },
  energy_pod: { growthTime: 300, waterConsumption: 2, harvestValue: 25, color: '#00FFFF', maxWater: 150 },
  nano_fruit: { growthTime: 360, waterConsumption: 2.5, harvestValue: 40, color: '#FF00FF', maxWater: 180 }
};

export default function CyberneticFarm() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [credits, setCredits] = useState(500);
  const [plants, setPlants] = useState<Plant[]>([]);
  const [farms, setFarms] = useState<Farm[]>([]);
  const [robots, setRobots] = useState<Robot[]>([]);
  const [selectedTool, setSelectedTool] = useState<'plant' | 'water' | 'harvest' | 'robot'>('plant');
  const [selectedPlantType, setSelectedPlantType] = useState<keyof typeof plantTypes>('wheat');
  const [gameTime, setGameTime] = useState(0);
  const [weather, setWeather] = useState<'sunny' | 'rainy' | 'drought'>('sunny');
  const plantIdRef = useRef(0);
  const robotIdRef = useRef(0);

  const initializeFarms = useCallback(() => {
    const newFarms: Farm[] = [];
    for (let x = 0; x < GAME_WIDTH; x += GRID_SIZE * 4) {
      for (let y = 0; y < GAME_HEIGHT; y += GRID_SIZE * 3) {
        newFarms.push({
          id: `farm-${x}-${y}`,
          x,
          y,
          width: GRID_SIZE * 4,
          height: GRID_SIZE * 3,
          soilQuality: 0.7 + Math.random() * 0.3,
          hasIrrigation: false,
          hasRobot: false
        });
      }
    }
    setFarms(newFarms);
  }, []);

  const plantSeed = useCallback((x: number, y: number, type: keyof typeof plantTypes) => {
    const gridX = Math.floor(x / GRID_SIZE) * GRID_SIZE;
    const gridY = Math.floor(y / GRID_SIZE) * GRID_SIZE;
    
    const plantConfig = plantTypes[type];
    const cost = plantConfig.harvestValue * 0.3;
    
    if (credits < cost) return false;
    
    // Check if position is empty
    const existingPlant = plants.find(p => p.x === gridX && p.y === gridY);
    if (existingPlant) return false;

    const newPlant: Plant = {
      id: `plant-${plantIdRef.current++}`,
      x: gridX,
      y: gridY,
      type,
      growthStage: 0,
      maxGrowthStage: plantConfig.growthTime,
      waterLevel: plantConfig.maxWater * 0.5,
      maxWaterLevel: plantConfig.maxWater,
      harvestValue: plantConfig.harvestValue,
      color: plantConfig.color,
      automatedWatering: false
    };

    setPlants(prev => [...prev, newPlant]);
    setCredits(prev => prev - cost);
    return true;
  }, [credits, plants]);

  const waterPlant = useCallback((plant: Plant) => {
    if (credits < 2) return false;
    
    setPlants(prev => prev.map(p => 
      p.id === plant.id 
        ? { ...p, waterLevel: Math.min(p.maxWaterLevel, p.waterLevel + 30) }
        : p
    ));
    setCredits(prev => prev - 2);
    return true;
  }, [credits]);

  const harvestPlant = useCallback((plant: Plant) => {
    if (plant.growthStage < plant.maxGrowthStage) return false;
    
    setPlants(prev => prev.filter(p => p.id !== plant.id));
    setCredits(prev => prev + plant.harvestValue);
    setScore(prev => prev + plant.harvestValue);
    return true;
  }, []);

  const deployRobot = useCallback((x: number, y: number) => {
    if (credits < 200) return false;
    
    const gridX = Math.floor(x / GRID_SIZE) * GRID_SIZE;
    const gridY = Math.floor(y / GRID_SIZE) * GRID_SIZE;
    
    const newRobot: Robot = {
      id: `robot-${robotIdRef.current++}`,
      x: gridX,
      y: gridY,
      task: 'idle',
      target: null,
      battery: 100,
      maxBattery: 100
    };

    setRobots(prev => [...prev, newRobot]);
    setCredits(prev => prev - 200);
    return true;
  }, [credits]);

  const handleCanvasClick = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPlaying || isPaused) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = GAME_WIDTH / rect.width;
    const scaleY = GAME_HEIGHT / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;

    switch (selectedTool) {
      case 'plant':
        plantSeed(x, y, selectedPlantType);
        break;
      case 'water':
        const plantToWater = plants.find(p => 
          x >= p.x && x <= p.x + GRID_SIZE && y >= p.y && y <= p.y + GRID_SIZE
        );
        if (plantToWater) waterPlant(plantToWater);
        break;
      case 'harvest':
        const plantToHarvest = plants.find(p => 
          x >= p.x && x <= p.x + GRID_SIZE && y >= p.y && y <= p.y + GRID_SIZE
        );
        if (plantToHarvest) harvestPlant(plantToHarvest);
        break;
      case 'robot':
        deployRobot(x, y);
        break;
    }
  }, [isPlaying, isPaused, selectedTool, selectedPlantType, plants, plantSeed, waterPlant, harvestPlant, deployRobot]);

  const updateRobots = useCallback(() => {
    setRobots(prev => prev.map(robot => {
      if (robot.battery <= 0) {
        return { ...robot, task: 'idle', target: null };
      }

      // Robot AI logic
      if (robot.task === 'idle') {
        // Find plants that need attention
        const thirstyPlants = plants.filter(p => p.waterLevel < p.maxWaterLevel * 0.3);
        const readyPlants = plants.filter(p => p.growthStage >= p.maxGrowthStage);
        
        if (thirstyPlants.length > 0) {
          const closestPlant = thirstyPlants.reduce((closest, plant) => {
            const distToPlant = Math.abs(plant.x - robot.x) + Math.abs(plant.y - robot.y);
            const distToClosest = Math.abs(closest.x - robot.x) + Math.abs(closest.y - robot.y);
            return distToPlant < distToClosest ? plant : closest;
          });
          return { ...robot, task: 'watering', target: closestPlant.id };
        } else if (readyPlants.length > 0) {
          const closestPlant = readyPlants.reduce((closest, plant) => {
            const distToPlant = Math.abs(plant.x - robot.x) + Math.abs(plant.y - robot.y);
            const distToClosest = Math.abs(closest.x - robot.x) + Math.abs(closest.y - robot.y);
            return distToPlant < distToClosest ? plant : closest;
          });
          return { ...robot, task: 'harvesting', target: closestPlant.id };
        }
      }

      // Move towards target
      if (robot.target) {
        const targetPlant = plants.find(p => p.id === robot.target);
        if (!targetPlant) {
          return { ...robot, task: 'idle', target: null };
        }

        const dx = targetPlant.x - robot.x;
        const dy = targetPlant.y - robot.y;
        
        if (Math.abs(dx) + Math.abs(dy) < GRID_SIZE) {
          // At target location
          if (robot.task === 'watering') {
            setPlants(prev => prev.map(p => 
              p.id === targetPlant.id 
                ? { ...p, waterLevel: Math.min(p.maxWaterLevel, p.waterLevel + 20) }
                : p
            ));
          } else if (robot.task === 'harvesting') {
            harvestPlant(targetPlant);
          }
          return { ...robot, task: 'idle', target: null, battery: robot.battery - 2 };
        } else {
          // Move towards target
          const moveX = dx > 0 ? GRID_SIZE : dx < 0 ? -GRID_SIZE : 0;
          const moveY = dy > 0 ? GRID_SIZE : dy < 0 ? -GRID_SIZE : 0;
          return { 
            ...robot, 
            x: robot.x + moveX, 
            y: robot.y + moveY,
            battery: robot.battery - 0.5
          };
        }
      }

      return robot;
    }));
  }, [plants, harvestPlant]);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused) return;

    setGameTime(prev => prev + 1);

    // Weather changes
    if (gameTime % 600 === 0) { // Every 10 seconds
      const weathers: ('sunny' | 'rainy' | 'drought')[] = ['sunny', 'rainy', 'drought'];
      setWeather(weathers[Math.floor(Math.random() * weathers.length)]);
    }

    // Update plants
    setPlants(prev => prev.map(plant => {
      let newWaterLevel = plant.waterLevel;
      let newGrowthStage = plant.growthStage;

      // Weather effects
      if (weather === 'rainy') {
        newWaterLevel = Math.min(plant.maxWaterLevel, newWaterLevel + 1);
      } else if (weather === 'drought') {
        newWaterLevel = Math.max(0, newWaterLevel - 2);
      } else {
        newWaterLevel = Math.max(0, newWaterLevel - plantTypes[plant.type].waterConsumption);
      }

      // Growth only happens if well watered
      if (newWaterLevel > plant.maxWaterLevel * 0.2 && newGrowthStage < plant.maxGrowthStage) {
        newGrowthStage += 1;
      }

      return {
        ...plant,
        waterLevel: newWaterLevel,
        growthStage: newGrowthStage
      };
    }));

    // Update robots
    if (gameTime % 30 === 0) { // Robot actions every 0.5 seconds
      updateRobots();
    }

    // Recharge robot batteries at stations
    setRobots(prev => prev.map(robot => ({
      ...robot,
      battery: Math.min(robot.maxBattery, robot.battery + 0.1)
    })));

  }, [isPlaying, isPaused, gameTime, weather, updateRobots]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;

    // Sky background with weather effects
    let skyColor = '#001122';
    if (weather === 'rainy') skyColor = '#001133';
    if (weather === 'drought') skyColor = '#221100';
    
    ctx.fillStyle = skyColor;
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Weather particles
    if (weather === 'rainy') {
      ctx.strokeStyle = '#4488ff';
      ctx.lineWidth = 2;
      for (let i = 0; i < 50; i++) {
        const x = (gameTime + i * 13) % GAME_WIDTH;
        const y = (gameTime * 3 + i * 7) % GAME_HEIGHT;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x - 5, y + 10);
        ctx.stroke();
      }
    }

    // Grid
    ctx.strokeStyle = '#003344';
    ctx.lineWidth = 1;
    for (let x = 0; x <= GAME_WIDTH; x += GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, GAME_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y <= GAME_HEIGHT; y += GRID_SIZE) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(GAME_WIDTH, y);
      ctx.stroke();
    }

    // Draw farms
    farms.forEach(farm => {
      ctx.fillStyle = `rgba(0, 100, 50, ${farm.soilQuality * 0.3})`;
      ctx.fillRect(farm.x, farm.y, farm.width, farm.height);
      
      if (farm.hasIrrigation) {
        ctx.strokeStyle = '#0088ff';
        ctx.lineWidth = 2;
        ctx.strokeRect(farm.x, farm.y, farm.width, farm.height);
      }
    });

    // Draw plants
    plants.forEach(plant => {
      const growthPercent = plant.growthStage / plant.maxGrowthStage;
      const size = 10 + growthPercent * 20;
      const waterPercent = plant.waterLevel / plant.maxWaterLevel;
      
      // Plant body
      ctx.fillStyle = plant.color;
      ctx.globalAlpha = 0.5 + waterPercent * 0.5;
      ctx.fillRect(
        plant.x + GRID_SIZE/2 - size/2,
        plant.y + GRID_SIZE/2 - size/2,
        size, size
      );
      ctx.globalAlpha = 1;

      // Growth indicator
      if (growthPercent >= 1) {
        ctx.strokeStyle = '#ffff00';
        ctx.lineWidth = 3;
        ctx.strokeRect(plant.x + 2, plant.y + 2, GRID_SIZE - 4, GRID_SIZE - 4);
      }

      // Water level indicator
      ctx.fillStyle = '#0088ff';
      ctx.fillRect(plant.x + 2, plant.y + GRID_SIZE - 6, (GRID_SIZE - 4) * waterPercent, 4);
    });

    // Draw robots
    robots.forEach(robot => {
      ctx.fillStyle = '#ff8800';
      ctx.shadowColor = '#ff8800';
      ctx.shadowBlur = 8;
      ctx.fillRect(robot.x + 5, robot.y + 5, GRID_SIZE - 10, GRID_SIZE - 10);
      ctx.shadowBlur = 0;

      // Battery indicator
      const batteryPercent = robot.battery / robot.maxBattery;
      ctx.fillStyle = batteryPercent > 0.3 ? '#00ff00' : '#ff0000';
      ctx.fillRect(robot.x + 2, robot.y + 2, (GRID_SIZE - 4) * batteryPercent, 3);

      // Task indicator
      ctx.fillStyle = '#ffffff';
      ctx.font = '8px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(robot.task, robot.x + GRID_SIZE/2, robot.y + GRID_SIZE + 10);
    });

    // UI
    ctx.fillStyle = 'rgba(0, 20, 40, 0.9)';
    ctx.fillRect(0, 0, GAME_WIDTH, 80);

    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(`Credits: $${credits}`, 10, 25);
    ctx.fillText(`Weather: ${weather}`, 10, 45);
    ctx.fillText(`Plants: ${plants.length}`, 10, 65);

    ctx.fillText(`Robots: ${robots.length}`, 150, 25);
    ctx.fillText(`Tool: ${selectedTool}`, 150, 45);
    if (selectedTool === 'plant') {
      ctx.fillText(`Type: ${selectedPlantType}`, 150, 65);
    }

    ctx.textAlign = 'center';
  }, [farms, plants, robots, credits, weather, selectedTool, selectedPlantType, gameTime]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  const startGame = () => {
    setScore(0);
    setCredits(500);
    setPlants([]);
    setRobots([]);
    setGameTime(0);
    setWeather('sunny');
    plantIdRef.current = 0;
    robotIdRef.current = 0;
    initializeFarms();
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => {
    setIsPlaying(false);
    setScore(0);
  };

  return (
    <GameLayout
      title="Cybernetic Farm"
      description="Manage automated farming systems in the future!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          onClick={handleCanvasClick}
          className="border-2 border-neon-green rounded-lg cursor-pointer max-w-full h-auto"
          style={{ background: 'linear-gradient(180deg, #001122, #002211)' }}
        />
        
        {isPlaying && (
          <div className="flex flex-col gap-4 w-full max-w-4xl">
            {/* Tools */}
            <div className="flex gap-2 justify-center flex-wrap">
              {['plant', 'water', 'harvest', 'robot'].map(tool => (
                <button
                  key={tool}
                  onClick={() => setSelectedTool(tool as any)}
                  className={`px-4 py-2 rounded border-2 transition-all ${
                    selectedTool === tool 
                      ? 'border-neon-green bg-neon-green/20' 
                      : 'border-gray-600 hover:border-neon-green/50'
                  }`}
                >
                  {tool.charAt(0).toUpperCase() + tool.slice(1)}
                  {tool === 'robot' && ' ($200)'}
                </button>
              ))}
            </div>

            {/* Plant Types */}
            {selectedTool === 'plant' && (
              <div className="flex gap-2 justify-center flex-wrap">
                {Object.entries(plantTypes).map(([type, config]) => (
                  <button
                    key={type}
                    onClick={() => setSelectedPlantType(type as keyof typeof plantTypes)}
                    className={`px-3 py-2 rounded border-2 transition-all ${
                      selectedPlantType === type 
                        ? 'border-neon-green bg-neon-green/20' 
                        : 'border-gray-600 hover:border-neon-green/50'
                    }`}
                    style={{ borderColor: config.color, color: config.color }}
                  >
                    <div className="font-bold">{type.replace('_', ' ').toUpperCase()}</div>
                    <div className="text-xs">
                      ${config.harvestValue} | {Math.round(config.growthTime/60)}s
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
        
        <div className="text-center text-sm text-gray-400 max-w-md">
          Plant crops, manage water levels, and deploy robots to automate your farm. 
          Weather affects growth and water consumption!
        </div>
      </div>
    </GameLayout>
  );
}
