import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface DataStream {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  color: string;
  safe: boolean;
}

interface DataPacket {
  x: number;
  y: number;
  collected: boolean;
  value: number;
  color: string;
}

interface Player {
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  invulnerable: number;
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;

export default function DataStreamRunner() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [player, setPlayer] = useState<Player>({
    x: 50,
    y: GAME_HEIGHT / 2,
    width: 20,
    height: 20,
    speed: 5,
    invulnerable: 0
  });
  const [streams, setStreams] = useState<DataStream[]>([]);
  const [packets, setPackets] = useState<DataPacket[]>([]);
  const [lives, setLives] = useState(3);
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});

  const spawnStream = useCallback(() => {
    const newStream: DataStream = {
      x: GAME_WIDTH,
      y: Math.random() * (GAME_HEIGHT - 100),
      width: 20,
      height: 60 + Math.random() * 40,
      speed: 3 + Math.random() * 2,
      color: Math.random() > 0.7 ? '#ff0099' : '#0066ff',
      safe: Math.random() > 0.7
    };
    setStreams(prev => [...prev, newStream]);
  }, []);

  const spawnPacket = useCallback(() => {
    const newPacket: DataPacket = {
      x: GAME_WIDTH,
      y: Math.random() * GAME_HEIGHT,
      collected: false,
      value: 10,
      color: '#ffff00'
    };
    setPackets(prev => [...prev, newPacket]);
  }, []);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused) return;

    // Move player
    setPlayer(prev => {
      let newX = prev.x;
      let newY = prev.y;

      if (keys['ArrowUp'] || keys['w']) newY -= prev.speed;
      if (keys['ArrowDown'] || keys['s']) newY += prev.speed;
      if (keys['ArrowLeft'] || keys['a']) newX -= prev.speed;
      if (keys['ArrowRight'] || keys['d']) newX += prev.speed;

      return {
        ...prev,
        x: Math.max(0, Math.min(GAME_WIDTH - prev.width, newX)),
        y: Math.max(0, Math.min(GAME_HEIGHT - prev.height, newY)),
        invulnerable: Math.max(0, prev.invulnerable - 1)
      };
    });

    // Update streams
    setStreams(prev => prev.map(stream => ({
      ...stream,
      x: stream.x - stream.speed
    })).filter(stream => stream.x > -stream.width));

    // Update packets
    setPackets(prev => prev.map(packet => ({
      ...packet,
      x: packet.x - 2
    })).filter(packet => packet.x > -20 && !packet.collected));

    // Check collisions
    packets.forEach(packet => {
      if (!packet.collected &&
          player.x < packet.x + 15 &&
          player.x + player.width > packet.x &&
          player.y < packet.y + 15 &&
          player.y + player.height > packet.y) {
        packet.collected = true;
        setScore(prev => prev + packet.value);
      }
    });

    // Spawn new elements
    if (Math.random() < 0.02) spawnStream();
    if (Math.random() < 0.01) spawnPacket();

  }, [isPlaying, isPaused, keys, player, packets, spawnStream, spawnPacket]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = '#000814';
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Data grid
    ctx.strokeStyle = '#003366';
    ctx.lineWidth = 1;
    for (let x = 0; x < GAME_WIDTH; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, GAME_HEIGHT);
      ctx.stroke();
    }

    // Streams
    streams.forEach(stream => {
      ctx.fillStyle = stream.color;
      ctx.shadowColor = stream.color;
      ctx.shadowBlur = 10;
      ctx.fillRect(stream.x, stream.y, stream.width, stream.height);
      ctx.shadowBlur = 0;
    });

    // Packets
    packets.forEach(packet => {
      if (!packet.collected) {
        ctx.fillStyle = packet.color;
        ctx.shadowColor = packet.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(packet.x + 7, packet.y + 7, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    });

    // Player
    ctx.fillStyle = player.invulnerable > 0 ? '#ff8800' : '#0aff9d';
    ctx.shadowColor = '#0aff9d';
    ctx.shadowBlur = 12;
    ctx.fillRect(player.x, player.y, player.width, player.height);
    ctx.shadowBlur = 0;

    // UI
    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.fillText(`Lives: ${lives}`, 10, 30);
  }, [player, streams, packets, lives]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: true }));
    const handleKeyUp = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: false }));
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = () => {
    setScore(0);
    setLives(3);
    setStreams([]);
    setPackets([]);
    setPlayer({ x: 50, y: GAME_HEIGHT / 2, width: 20, height: 20, speed: 5, invulnerable: 0 });
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Data Stream Runner"
      description="Navigate through flowing data streams!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          className="border-2 border-neon-green rounded-lg max-w-full h-auto"
        />
        <div className="text-center text-sm text-gray-400 max-w-md">
          Navigate through data streams and collect packets. Avoid red streams!
        </div>
      </div>
    </GameLayout>
  );
}
