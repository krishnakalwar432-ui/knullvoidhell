import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface AIFighter {
  id: string;
  name: string;
  x: number;
  y: number;
  health: number;
  maxHealth: number;
  energy: number;
  maxEnergy: number;
  speed: number;
  damage: number;
  color: string;
  behavior: 'aggressive' | 'defensive' | 'balanced' | 'tactical';
  target: string | null;
  cooldown: number;
  size: number;
}

interface Projectile {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  damage: number;
  owner: string;
  color: string;
  life: number;
}

interface AIProgram {
  name: string;
  behavior: 'aggressive' | 'defensive' | 'balanced' | 'tactical';
  stats: {
    speed: number;
    damage: number;
    health: number;
    energy: number;
  };
  color: string;
}

const ARENA_WIDTH = 800;
const ARENA_HEIGHT = 600;

const aiPrograms: AIProgram[] = [
  {
    name: 'Berserker',
    behavior: 'aggressive',
    stats: { speed: 3, damage: 30, health: 80, energy: 50 },
    color: '#ff0000'
  },
  {
    name: 'Guardian',
    behavior: 'defensive',
    stats: { speed: 2, damage: 20, health: 120, energy: 80 },
    color: '#0000ff'
  },
  {
    name: 'Assassin',
    behavior: 'tactical',
    stats: { speed: 4, damage: 35, health: 70, energy: 70 },
    color: '#800080'
  },
  {
    name: 'Warrior',
    behavior: 'balanced',
    stats: { speed: 2.5, damage: 25, health: 100, energy: 60 },
    color: '#00ff00'
  }
];

export default function AICombatArena() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [fighters, setFighters] = useState<AIFighter[]>([]);
  const [projectiles, setProjectiles] = useState<Projectile[]>([]);
  const [selectedPrograms, setSelectedPrograms] = useState<string[]>([]);
  const [battlePhase, setBattlePhase] = useState<'setup' | 'fighting' | 'finished'>('setup');
  const [winner, setWinner] = useState<AIFighter | null>(null);
  const [round, setRound] = useState(1);
  const fighterIdRef = useRef(0);
  const projectileIdRef = useRef(0);

  const createFighter = useCallback((program: AIProgram, x: number, y: number): AIFighter => {
    return {
      id: `fighter-${fighterIdRef.current++}`,
      name: program.name,
      x,
      y,
      health: program.stats.health,
      maxHealth: program.stats.health,
      energy: program.stats.energy,
      maxEnergy: program.stats.energy,
      speed: program.stats.speed,
      damage: program.stats.damage,
      color: program.color,
      behavior: program.behavior,
      target: null,
      cooldown: 0,
      size: 20
    };
  }, []);

  const spawnProjectile = useCallback((fighter: AIFighter, targetX: number, targetY: number) => {
    if (fighter.energy < 10 || fighter.cooldown > 0) return;

    const dx = targetX - fighter.x;
    const dy = targetY - fighter.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const speed = 6;

    const projectile: Projectile = {
      id: `projectile-${projectileIdRef.current++}`,
      x: fighter.x,
      y: fighter.y,
      vx: (dx / distance) * speed,
      vy: (dy / distance) * speed,
      damage: fighter.damage,
      owner: fighter.id,
      color: fighter.color,
      life: 120
    };

    setProjectiles(prev => [...prev, projectile]);
    setFighters(prev => prev.map(f => 
      f.id === fighter.id 
        ? { ...f, energy: f.energy - 10, cooldown: 30 }
        : f
    ));
  }, []);

  const findNearestEnemy = useCallback((fighter: AIFighter, fighters: AIFighter[]) => {
    const enemies = fighters.filter(f => f.id !== fighter.id && f.health > 0);
    if (enemies.length === 0) return null;

    return enemies.reduce((nearest, enemy) => {
      const distanceToEnemy = Math.sqrt(
        (enemy.x - fighter.x) ** 2 + (enemy.y - fighter.y) ** 2
      );
      const distanceToNearest = nearest ? Math.sqrt(
        (nearest.x - fighter.x) ** 2 + (nearest.y - fighter.y) ** 2
      ) : Infinity;

      return distanceToEnemy < distanceToNearest ? enemy : nearest;
    });
  }, []);

  const updateAI = useCallback((fighter: AIFighter, allFighters: AIFighter[]) => {
    if (fighter.health <= 0) return fighter;

    const nearestEnemy = findNearestEnemy(fighter, allFighters);
    if (!nearestEnemy) return fighter;

    const dx = nearestEnemy.x - fighter.x;
    const dy = nearestEnemy.y - fighter.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    let newX = fighter.x;
    let newY = fighter.y;

    switch (fighter.behavior) {
      case 'aggressive':
        // Move towards enemy aggressively
        if (distance > 100) {
          newX += (dx / distance) * fighter.speed;
          newY += (dy / distance) * fighter.speed;
        }
        // Shoot frequently
        if (distance < 200 && fighter.cooldown === 0) {
          spawnProjectile(fighter, nearestEnemy.x, nearestEnemy.y);
        }
        break;

      case 'defensive':
        // Keep distance, retreat if too close
        if (distance < 150) {
          newX -= (dx / distance) * fighter.speed * 0.8;
          newY -= (dy / distance) * fighter.speed * 0.8;
        } else if (distance > 300) {
          newX += (dx / distance) * fighter.speed * 0.5;
          newY += (dy / distance) * fighter.speed * 0.5;
        }
        // Shoot when at optimal distance
        if (distance > 150 && distance < 250 && fighter.cooldown === 0) {
          spawnProjectile(fighter, nearestEnemy.x, nearestEnemy.y);
        }
        break;

      case 'tactical':
        // Circle around enemy
        const angle = Math.atan2(dy, dx) + Math.PI / 2;
        if (distance > 120 && distance < 200) {
          newX += Math.cos(angle) * fighter.speed;
          newY += Math.sin(angle) * fighter.speed;
        } else if (distance > 200) {
          newX += (dx / distance) * fighter.speed;
          newY += (dy / distance) * fighter.speed;
        }
        // Precise shooting
        if (distance < 180 && fighter.cooldown === 0 && fighter.energy > 20) {
          spawnProjectile(fighter, nearestEnemy.x, nearestEnemy.y);
        }
        break;

      case 'balanced':
        // Balanced approach
        if (distance > 150) {
          newX += (dx / distance) * fighter.speed * 0.7;
          newY += (dy / distance) * fighter.speed * 0.7;
        } else if (distance < 100) {
          newX -= (dx / distance) * fighter.speed * 0.5;
          newY -= (dy / distance) * fighter.speed * 0.5;
        }
        if (distance < 200 && fighter.cooldown === 0) {
          spawnProjectile(fighter, nearestEnemy.x, nearestEnemy.y);
        }
        break;
    }

    // Keep within arena bounds
    newX = Math.max(fighter.size, Math.min(ARENA_WIDTH - fighter.size, newX));
    newY = Math.max(fighter.size, Math.min(ARENA_HEIGHT - fighter.size, newY));

    return {
      ...fighter,
      x: newX,
      y: newY,
      energy: Math.min(fighter.maxEnergy, fighter.energy + 0.5),
      cooldown: Math.max(0, fighter.cooldown - 1)
    };
  }, [findNearestEnemy, spawnProjectile]);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused || battlePhase !== 'fighting') return;

    // Update fighters
    setFighters(prev => {
      const updatedFighters = prev.map(fighter => updateAI(fighter, prev));
      
      // Check for battle end
      const aliveFighters = updatedFighters.filter(f => f.health > 0);
      if (aliveFighters.length <= 1) {
        setBattlePhase('finished');
        if (aliveFighters.length === 1) {
          setWinner(aliveFighters[0]);
          setScore(s => s + round * 100);
        }
      }
      
      return updatedFighters;
    });

    // Update projectiles
    setProjectiles(prev => prev.map(projectile => ({
      ...projectile,
      x: projectile.x + projectile.vx,
      y: projectile.y + projectile.vy,
      life: projectile.life - 1
    })).filter(projectile => {
      // Remove if out of bounds or life expired
      if (projectile.life <= 0 || 
          projectile.x < 0 || projectile.x > ARENA_WIDTH ||
          projectile.y < 0 || projectile.y > ARENA_HEIGHT) {
        return false;
      }

      // Check collision with fighters
      const hitFighter = fighters.find(fighter => {
        if (fighter.id === projectile.owner || fighter.health <= 0) return false;
        
        const dx = fighter.x - projectile.x;
        const dy = fighter.y - projectile.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        return distance < fighter.size;
      });

      if (hitFighter) {
        setFighters(prev => prev.map(f => 
          f.id === hitFighter.id 
            ? { ...f, health: Math.max(0, f.health - projectile.damage) }
            : f
        ));
        return false;
      }

      return true;
    }));
  }, [isPlaying, isPaused, battlePhase, fighters, updateAI, round]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx || !canvas) return;

    // Arena background
    const gradient = ctx.createRadialGradient(
      ARENA_WIDTH/2, ARENA_HEIGHT/2, 0,
      ARENA_WIDTH/2, ARENA_HEIGHT/2, ARENA_WIDTH/2
    );
    gradient.addColorStop(0, '#001a33');
    gradient.addColorStop(1, '#000814');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);

    // Arena grid
    ctx.strokeStyle = '#003366';
    ctx.lineWidth = 1;
    for (let x = 0; x <= ARENA_WIDTH; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, ARENA_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y <= ARENA_HEIGHT; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(ARENA_WIDTH, y);
      ctx.stroke();
    }

    // Draw projectiles
    projectiles.forEach(projectile => {
      ctx.fillStyle = projectile.color;
      ctx.shadowColor = projectile.color;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(projectile.x, projectile.y, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    });

    // Draw fighters
    fighters.forEach(fighter => {
      if (fighter.health <= 0) return;

      // Fighter body
      ctx.fillStyle = fighter.color;
      ctx.shadowColor = fighter.color;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(fighter.x, fighter.y, fighter.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Health bar
      const barWidth = fighter.size * 2;
      const barHeight = 4;
      const healthPercent = fighter.health / fighter.maxHealth;
      
      ctx.fillStyle = '#ff0000';
      ctx.fillRect(fighter.x - barWidth/2, fighter.y - fighter.size - 15, barWidth, barHeight);
      ctx.fillStyle = '#00ff00';
      ctx.fillRect(fighter.x - barWidth/2, fighter.y - fighter.size - 15, barWidth * healthPercent, barHeight);

      // Energy bar
      const energyPercent = fighter.energy / fighter.maxEnergy;
      ctx.fillStyle = '#333333';
      ctx.fillRect(fighter.x - barWidth/2, fighter.y - fighter.size - 10, barWidth, 3);
      ctx.fillStyle = '#00ffff';
      ctx.fillRect(fighter.x - barWidth/2, fighter.y - fighter.size - 10, barWidth * energyPercent, 3);

      // Name
      ctx.fillStyle = '#ffffff';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(fighter.name, fighter.x, fighter.y + fighter.size + 15);

      // Behavior indicator
      const behaviorColors = {
        aggressive: '#ff0000',
        defensive: '#0000ff',
        tactical: '#800080',
        balanced: '#00ff00'
      };
      
      ctx.strokeStyle = behaviorColors[fighter.behavior];
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(fighter.x, fighter.y, fighter.size + 5, 0, Math.PI * 2);
      ctx.stroke();
    });

    // UI Text
    ctx.fillStyle = '#ffffff';
    ctx.font = '18px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(`Round: ${round}`, 10, 30);
    ctx.fillText(`Phase: ${battlePhase}`, 10, 55);

    if (battlePhase === 'finished' && winner) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.fillRect(0, 0, ARENA_WIDTH, ARENA_HEIGHT);
      
      ctx.fillStyle = winner.color;
      ctx.font = 'bold 36px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`${winner.name} WINS!`, ARENA_WIDTH/2, ARENA_HEIGHT/2);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '18px Arial';
      ctx.fillText('Click to start next round', ARENA_WIDTH/2, ARENA_HEIGHT/2 + 40);
    }

    ctx.textAlign = 'left';
  }, [fighters, projectiles, battlePhase, winner, round]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 16);
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  const startBattle = useCallback(() => {
    if (selectedPrograms.length < 2) return;

    const newFighters: AIFighter[] = [];
    const positions = [
      { x: 100, y: 100 },
      { x: ARENA_WIDTH - 100, y: 100 },
      { x: 100, y: ARENA_HEIGHT - 100 },
      { x: ARENA_WIDTH - 100, y: ARENA_HEIGHT - 100 }
    ];

    selectedPrograms.forEach((programName, index) => {
      const program = aiPrograms.find(p => p.name === programName);
      if (program && positions[index]) {
        newFighters.push(createFighter(program, positions[index].x, positions[index].y));
      }
    });

    setFighters(newFighters);
    setProjectiles([]);
    setBattlePhase('fighting');
    setWinner(null);
  }, [selectedPrograms, createFighter]);

  const nextRound = useCallback(() => {
    setRound(prev => prev + 1);
    setBattlePhase('setup');
    setFighters([]);
    setProjectiles([]);
    setWinner(null);
  }, []);

  const handleCanvasClick = useCallback(() => {
    if (battlePhase === 'finished') {
      nextRound();
    }
  }, [battlePhase, nextRound]);

  const toggleProgram = useCallback((programName: string) => {
    setSelectedPrograms(prev => {
      if (prev.includes(programName)) {
        return prev.filter(p => p !== programName);
      } else if (prev.length < 4) {
        return [...prev, programName];
      }
      return prev;
    });
  }, []);

  const startGame = () => {
    setScore(0);
    setRound(1);
    setBattlePhase('setup');
    setFighters([]);
    setProjectiles([]);
    setSelectedPrograms([]);
    setWinner(null);
    fighterIdRef.current = 0;
    projectileIdRef.current = 0;
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => {
    setIsPlaying(false);
    setScore(0);
  };

  return (
    <GameLayout
      title="AI Combat Arena"
      description="Program AI fighters and watch them battle!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={ARENA_WIDTH}
          height={ARENA_HEIGHT}
          onClick={handleCanvasClick}
          className="border-2 border-neon-green rounded-lg cursor-pointer max-w-full h-auto"
          style={{ background: 'radial-gradient(circle, #001a33, #000814)' }}
        />
        
        {isPlaying && battlePhase === 'setup' && (
          <div className="flex flex-col gap-4 w-full max-w-4xl">
            <div className="text-center text-white">
              Select 2-4 AI programs for battle:
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {aiPrograms.map(program => (
                <button
                  key={program.name}
                  onClick={() => toggleProgram(program.name)}
                  className={`p-4 rounded border-2 transition-all ${
                    selectedPrograms.includes(program.name)
                      ? 'border-neon-green bg-neon-green/20'
                      : 'border-gray-600 hover:border-neon-green/50'
                  }`}
                  style={{ borderColor: program.color }}
                >
                  <div className="font-bold text-lg" style={{ color: program.color }}>
                    {program.name}
                  </div>
                  <div className="text-sm text-gray-400 capitalize">
                    {program.behavior}
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    HP: {program.stats.health} | DMG: {program.stats.damage}<br/>
                    SPD: {program.stats.speed} | EN: {program.stats.energy}
                  </div>
                </button>
              ))}
            </div>
            
            <button
              onClick={startBattle}
              disabled={selectedPrograms.length < 2}
              className={`px-6 py-3 rounded border-2 transition-all ${
                selectedPrograms.length >= 2
                  ? 'border-neon-green text-neon-green hover:bg-neon-green/20'
                  : 'border-gray-600 text-gray-600 cursor-not-allowed'
              }`}
            >
              START BATTLE ({selectedPrograms.length}/4 selected)
            </button>
          </div>
        )}
        
        <div className="text-center text-sm text-gray-400 max-w-md">
          Each AI has different combat behaviors: Aggressive attacks directly, Defensive keeps distance,
          Tactical circles enemies, Balanced uses mixed strategies.
        </div>
      </div>
    </GameLayout>
  );
}
