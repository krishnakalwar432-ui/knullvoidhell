import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface MazeCell {
  x: number;
  y: number;
  walls: { top: boolean; right: boolean; bottom: boolean; left: boolean };
  visited: boolean;
  isPath: boolean;
  memoryPattern: number;
}

interface Player {
  x: number;
  y: number;
  moves: number;
}

const MAZE_SIZE = 15;
const CELL_SIZE = 30;
const CANVAS_WIDTH = MAZE_SIZE * CELL_SIZE;
const CANVAS_HEIGHT = MAZE_SIZE * CELL_SIZE;

export default function MemoryMazeChallenge() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [maze, setMaze] = useState<MazeCell[][]>([]);
  const [player, setPlayer] = useState<Player>({ x: 0, y: 0, moves: 0 });
  const [targetX] = useState(MAZE_SIZE - 1);
  const [targetY] = useState(MAZE_SIZE - 1);
  const [showPath, setShowPath] = useState(false);
  const [memoryTime, setMemoryTime] = useState(5);
  const [phase, setPhase] = useState<'memory' | 'playing' | 'complete'>('memory');
  const [keys, setKeys] = useState<{[key: string]: boolean}>({});

  const generateMaze = useCallback(() => {
    const newMaze: MazeCell[][] = [];
    
    // Initialize maze
    for (let y = 0; y < MAZE_SIZE; y++) {
      newMaze[y] = [];
      for (let x = 0; x < MAZE_SIZE; x++) {
        newMaze[y][x] = {
          x, y,
          walls: { top: true, right: true, bottom: true, left: true },
          visited: false,
          isPath: false,
          memoryPattern: Math.floor(Math.random() * 4) // 0-3 for different colors
        };
      }
    }

    // Simple maze generation - create random paths
    const stack: {x: number, y: number}[] = [];
    let current = { x: 0, y: 0 };
    newMaze[0][0].visited = true;

    while (true) {
      const neighbors = [];
      const { x, y } = current;

      // Check neighbors
      if (y > 1 && !newMaze[y-2][x].visited) neighbors.push({ x, y: y-2, dir: 'top' });
      if (x < MAZE_SIZE-2 && !newMaze[y][x+2].visited) neighbors.push({ x: x+2, y, dir: 'right' });
      if (y < MAZE_SIZE-2 && !newMaze[y+2][x].visited) neighbors.push({ x, y: y+2, dir: 'bottom' });
      if (x > 1 && !newMaze[y][x-2].visited) neighbors.push({ x: x-2, y, dir: 'left' });

      if (neighbors.length > 0) {
        const next = neighbors[Math.floor(Math.random() * neighbors.length)];
        stack.push(current);

        // Remove walls between current and next
        if (next.dir === 'top') {
          newMaze[y][x].walls.top = false;
          newMaze[y-1][x].walls.top = false;
          newMaze[y-1][x].walls.bottom = false;
          newMaze[y-2][x].walls.bottom = false;
        } else if (next.dir === 'right') {
          newMaze[y][x].walls.right = false;
          newMaze[y][x+1].walls.right = false;
          newMaze[y][x+1].walls.left = false;
          newMaze[y][x+2].walls.left = false;
        } else if (next.dir === 'bottom') {
          newMaze[y][x].walls.bottom = false;
          newMaze[y+1][x].walls.bottom = false;
          newMaze[y+1][x].walls.top = false;
          newMaze[y+2][x].walls.top = false;
        } else if (next.dir === 'left') {
          newMaze[y][x].walls.left = false;
          newMaze[y][x-1].walls.left = false;
          newMaze[y][x-1].walls.right = false;
          newMaze[y][x-2].walls.right = false;
        }

        current = { x: next.x, y: next.y };
        newMaze[next.y][next.x].visited = true;
      } else if (stack.length > 0) {
        current = stack.pop()!;
      } else {
        break;
      }
    }

    setMaze(newMaze);
  }, []);

  const gameLoop = useCallback(() => {
    if (!isPlaying || isPaused || phase !== 'playing') return;

    setPlayer(prev => {
      let newX = prev.x;
      let newY = prev.y;
      let moved = false;

      if (keys['ArrowLeft'] && newX > 0 && !maze[newY][newX].walls.left) {
        newX--;
        moved = true;
      } else if (keys['ArrowRight'] && newX < MAZE_SIZE - 1 && !maze[newY][newX].walls.right) {
        newX++;
        moved = true;
      } else if (keys['ArrowUp'] && newY > 0 && !maze[newY][newX].walls.top) {
        newY--;
        moved = true;
      } else if (keys['ArrowDown'] && newY < MAZE_SIZE - 1 && !maze[newY][newX].walls.bottom) {
        newY++;
        moved = true;
      }

      if (moved) {
        const newMoves = prev.moves + 1;
        
        // Check if reached target
        if (newX === targetX && newY === targetY) {
          setPhase('complete');
          setScore(s => s + Math.max(100, 500 - newMoves));
        }

        return { x: newX, y: newY, moves: newMoves };
      }

      return prev;
    });
  }, [isPlaying, isPaused, phase, keys, maze, targetX, targetY]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = '#000814';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    if (maze.length === 0) return;

    // Draw maze
    maze.forEach((row, y) => {
      row.forEach((cell, x) => {
        const cellX = x * CELL_SIZE;
        const cellY = y * CELL_SIZE;

        // Cell background with memory pattern
        if (phase === 'memory' || showPath) {
          const colors = ['#ff0099', '#0aff9d', '#7000ff', '#00ffff'];
          ctx.fillStyle = colors[cell.memoryPattern] + '30';
          ctx.fillRect(cellX + 1, cellY + 1, CELL_SIZE - 2, CELL_SIZE - 2);
        } else {
          ctx.fillStyle = '#001122';
          ctx.fillRect(cellX + 1, cellY + 1, CELL_SIZE - 2, CELL_SIZE - 2);
        }

        // Draw walls
        ctx.strokeStyle = '#0aff9d';
        ctx.lineWidth = 2;
        ctx.beginPath();

        if (cell.walls.top) {
          ctx.moveTo(cellX, cellY);
          ctx.lineTo(cellX + CELL_SIZE, cellY);
        }
        if (cell.walls.right) {
          ctx.moveTo(cellX + CELL_SIZE, cellY);
          ctx.lineTo(cellX + CELL_SIZE, cellY + CELL_SIZE);
        }
        if (cell.walls.bottom) {
          ctx.moveTo(cellX + CELL_SIZE, cellY + CELL_SIZE);
          ctx.lineTo(cellX, cellY + CELL_SIZE);
        }
        if (cell.walls.left) {
          ctx.moveTo(cellX, cellY + CELL_SIZE);
          ctx.lineTo(cellX, cellY);
        }

        ctx.stroke();
      });
    });

    // Draw player
    const playerX = player.x * CELL_SIZE + CELL_SIZE / 2;
    const playerY = player.y * CELL_SIZE + CELL_SIZE / 2;
    
    ctx.fillStyle = '#ffff00';
    ctx.shadowColor = '#ffff00';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(playerX, playerY, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Draw target
    const targetXPos = targetX * CELL_SIZE + CELL_SIZE / 2;
    const targetYPos = targetY * CELL_SIZE + CELL_SIZE / 2;
    
    ctx.fillStyle = '#ff0099';
    ctx.shadowColor = '#ff0099';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(targetXPos, targetYPos, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Phase indicators
    if (phase === 'memory') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      
      ctx.fillStyle = '#0aff9d';
      ctx.font = '24px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('MEMORIZE THE PATTERN', CANVAS_WIDTH/2, CANVAS_HEIGHT/2 - 20);
      ctx.fillText(`${memoryTime}`, CANVAS_WIDTH/2, CANVAS_HEIGHT/2 + 20);
    } else if (phase === 'complete') {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
      
      ctx.fillStyle = '#ffff00';
      ctx.font = '32px Arial';
      ctx.textAlign = 'center';
      ctx.fillText('MAZE COMPLETE!', CANVAS_WIDTH/2, CANVAS_HEIGHT/2);
      ctx.fillText(`Moves: ${player.moves}`, CANVAS_WIDTH/2, CANVAS_HEIGHT/2 + 40);
    }

    ctx.textAlign = 'left';
  }, [maze, player, targetX, targetY, phase, memoryTime, showPath]);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(gameLoop, 100); // Slower movement
    return () => clearInterval(interval);
  }, [gameLoop, isPlaying]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  useEffect(() => {
    if (phase === 'memory' && memoryTime > 0) {
      const timer = setTimeout(() => {
        setMemoryTime(prev => prev - 1);
      }, 1000);
      return () => clearTimeout(timer);
    } else if (phase === 'memory' && memoryTime === 0) {
      setPhase('playing');
      setShowPath(false);
    }
  }, [phase, memoryTime]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: true }));
    const handleKeyUp = (e: KeyboardEvent) => setKeys(prev => ({ ...prev, [e.key]: false }));
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = () => {
    setScore(0);
    setPlayer({ x: 0, y: 0, moves: 0 });
    setPhase('memory');
    setMemoryTime(5);
    setShowPath(true);
    generateMaze();
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Memory Maze Challenge"
      description="Navigate mazes using memory patterns!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={CANVAS_WIDTH}
          height={CANVAS_HEIGHT}
          className="border-2 border-neon-green rounded-lg max-w-full h-auto"
        />
        <div className="text-center text-sm text-gray-400 max-w-md">
          Memorize the colored pattern, then navigate to the pink target using arrow keys!
        </div>
      </div>
    </GameLayout>
  );
}
