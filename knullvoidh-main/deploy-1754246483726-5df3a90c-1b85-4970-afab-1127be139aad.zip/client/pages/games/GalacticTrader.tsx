import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GameLayout } from '../../components/GameLayout';

interface Planet {
  id: string;
  name: string;
  x: number;
  y: number;
  population: number;
  wealth: number;
  color: string;
  supplies: { [key: string]: number };
  demands: { [key: string]: number };
}

interface Ship {
  x: number;
  y: number;
  fuel: number;
  maxFuel: number;
  cargo: { [key: string]: number };
  maxCargo: number;
  credits: number;
}

interface Trade {
  item: string;
  price: number;
  quantity: number;
}

const GAME_WIDTH = 800;
const GAME_HEIGHT = 600;

const commodities = ['Fuel', 'Food', 'Minerals', 'Technology', 'Luxury Goods'];

export default function GalacticTrader() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [ship, setShip] = useState<Ship>({
    x: 400,
    y: 300,
    fuel: 100,
    maxFuel: 100,
    cargo: {},
    maxCargo: 50,
    credits: 1000
  });
  const [planets, setPlanets] = useState<Planet[]>([]);
  const [selectedPlanet, setSelectedPlanet] = useState<Planet | null>(null);
  const [showTrade, setShowTrade] = useState(false);
  const [trades, setTrades] = useState<Trade[]>([]);

  const generatePlanets = useCallback(() => {
    const planetNames = ['Alpha Centauri', 'Betelgeuse', 'Rigel', 'Vega', 'Sirius'];
    const newPlanets: Planet[] = [];
    
    planetNames.forEach((name, i) => {
      const angle = (i / planetNames.length) * Math.PI * 2;
      const distance = 150 + Math.random() * 150;
      
      const planet: Planet = {
        id: `planet-${i}`,
        name,
        x: GAME_WIDTH/2 + Math.cos(angle) * distance,
        y: GAME_HEIGHT/2 + Math.sin(angle) * distance,
        population: 1000000 + Math.random() * 5000000,
        wealth: 0.5 + Math.random() * 0.5,
        color: `hsl(${Math.random() * 360}, 70%, 60%)`,
        supplies: {},
        demands: {}
      };
      
      // Generate random supply and demand
      commodities.forEach(commodity => {
        if (Math.random() > 0.5) {
          planet.supplies[commodity] = Math.floor(Math.random() * 100);
        }
        if (Math.random() > 0.5) {
          planet.demands[commodity] = Math.floor(Math.random() * 50);
        }
      });
      
      newPlanets.push(planet);
    });
    
    setPlanets(newPlanets);
  }, []);

  const travelToPlanet = useCallback((planet: Planet) => {
    const distance = Math.sqrt((planet.x - ship.x) ** 2 + (planet.y - ship.y) ** 2);
    const fuelCost = Math.floor(distance / 5);
    
    if (ship.fuel >= fuelCost) {
      setShip(prev => ({
        ...prev,
        x: planet.x,
        y: planet.y,
        fuel: prev.fuel - fuelCost
      }));
      
      setSelectedPlanet(planet);
      generateTrades(planet);
      setShowTrade(true);
    }
  }, [ship]);

  const generateTrades = useCallback((planet: Planet) => {
    const newTrades: Trade[] = [];
    
    // Selling opportunities (planet demands)
    Object.entries(planet.demands).forEach(([item, demand]) => {
      if (ship.cargo[item] > 0) {
        const basePrice = 20 + Math.random() * 30;
        const price = Math.floor(basePrice * planet.wealth);
        newTrades.push({
          item,
          price,
          quantity: Math.min(ship.cargo[item], demand)
        });
      }
    });
    
    // Buying opportunities (planet supplies)
    Object.entries(planet.supplies).forEach(([item, supply]) => {
      const basePrice = 10 + Math.random() * 20;
      const price = Math.floor(basePrice / planet.wealth);
      newTrades.push({
        item,
        price: -price, // negative for buying
        quantity: Math.min(supply, ship.maxCargo - Object.values(ship.cargo).reduce((a, b) => a + b, 0))
      });
    });
    
    setTrades(newTrades);
  }, [ship]);

  const executeTrade = useCallback((trade: Trade, quantity: number) => {
    if (trade.price > 0) { // Selling
      setShip(prev => ({
        ...prev,
        cargo: {
          ...prev.cargo,
          [trade.item]: (prev.cargo[trade.item] || 0) - quantity
        },
        credits: prev.credits + trade.price * quantity
      }));
      setScore(prev => prev + trade.price * quantity);
    } else { // Buying
      const cost = Math.abs(trade.price) * quantity;
      if (ship.credits >= cost) {
        setShip(prev => ({
          ...prev,
          cargo: {
            ...prev.cargo,
            [trade.item]: (prev.cargo[trade.item] || 0) + quantity
          },
          credits: prev.credits - cost
        }));
      }
    }
  }, [ship.credits]);

  const handleCanvasClick = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPlaying || isPaused || showTrade) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const scaleX = GAME_WIDTH / rect.width;
    const scaleY = GAME_HEIGHT / rect.height;
    const x = (event.clientX - rect.left) * scaleX;
    const y = (event.clientY - rect.top) * scaleY;

    // Check if clicked on a planet
    const clickedPlanet = planets.find(planet => {
      const distance = Math.sqrt((planet.x - x) ** 2 + (planet.y - y) ** 2);
      return distance < 30;
    });

    if (clickedPlanet) {
      travelToPlanet(clickedPlanet);
    }
  }, [isPlaying, isPaused, showTrade, planets, travelToPlanet]);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;

    // Space background
    ctx.fillStyle = '#000814';
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Stars
    ctx.fillStyle = '#ffffff';
    for (let i = 0; i < 100; i++) {
      const x = (i * 7) % GAME_WIDTH;
      const y = (i * 13) % GAME_HEIGHT;
      ctx.beginPath();
      ctx.arc(x, y, 1, 0, Math.PI * 2);
      ctx.fill();
    }

    // Planets
    planets.forEach(planet => {
      ctx.fillStyle = planet.color;
      ctx.shadowColor = planet.color;
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(planet.x, planet.y, 25, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#ffffff';
      ctx.font = '12px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(planet.name, planet.x, planet.y - 35);
    });

    // Ship
    ctx.fillStyle = '#0aff9d';
    ctx.shadowColor = '#0aff9d';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(ship.x, ship.y, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // UI
    ctx.fillStyle = 'rgba(0, 20, 40, 0.9)';
    ctx.fillRect(0, 0, GAME_WIDTH, 80);

    ctx.fillStyle = '#ffffff';
    ctx.font = '16px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(`Credits: ${ship.credits}`, 10, 25);
    ctx.fillText(`Fuel: ${ship.fuel}/${ship.maxFuel}`, 10, 45);
    ctx.fillText(`Cargo: ${Object.values(ship.cargo).reduce((a, b) => a + b, 0)}/${ship.maxCargo}`, 10, 65);

    if (showTrade && selectedPlanet) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
      ctx.fillRect(100, 100, 600, 400);
      
      ctx.fillStyle = '#0aff9d';
      ctx.font = '20px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`Trading at ${selectedPlanet.name}`, GAME_WIDTH/2, 140);
      
      ctx.fillStyle = '#ffffff';
      ctx.font = '14px Arial';
      ctx.textAlign = 'left';
      trades.forEach((trade, i) => {
        const y = 180 + i * 30;
        const action = trade.price > 0 ? 'SELL' : 'BUY';
        const price = Math.abs(trade.price);
        ctx.fillText(`${action} ${trade.item}: ${price} credits (Max: ${trade.quantity})`, 120, y);
      });
    }

  }, [ship, planets, selectedPlanet, showTrade, trades]);

  useEffect(() => {
    const interval = setInterval(draw, 16);
    return () => clearInterval(interval);
  }, [draw]);

  const startGame = () => {
    setScore(0);
    setShip({
      x: 400,
      y: 300,
      fuel: 100,
      maxFuel: 100,
      cargo: { Food: 10, Minerals: 5 },
      maxCargo: 50,
      credits: 1000
    });
    generatePlanets();
    setShowTrade(false);
    setIsPlaying(true);
    setIsPaused(false);
  };

  const pauseGame = () => setIsPaused(!isPaused);
  const resetGame = () => setIsPlaying(false);

  return (
    <GameLayout
      title="Galactic Trader"
      description="Trade resources across star systems!"
      score={score}
      isPlaying={isPlaying}
      isPaused={isPaused}
      onStart={startGame}
      onPause={pauseGame}
      onReset={resetGame}
    >
      <div className="flex flex-col items-center gap-4">
        <canvas
          ref={canvasRef}
          width={GAME_WIDTH}
          height={GAME_HEIGHT}
          onClick={handleCanvasClick}
          className="border-2 border-neon-green rounded-lg cursor-pointer max-w-full h-auto"
        />
        
        {showTrade && (
          <div className="flex gap-2 justify-center">
            <button
              onClick={() => setShowTrade(false)}
              className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
            >
              Leave Planet
            </button>
          </div>
        )}
        
        <div className="text-center text-sm text-gray-400 max-w-md">
          Click on planets to travel and trade. Buy low, sell high across the galaxy!
        </div>
      </div>
    </GameLayout>
  );
}
