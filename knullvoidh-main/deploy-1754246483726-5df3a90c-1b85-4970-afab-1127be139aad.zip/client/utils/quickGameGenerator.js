// This utility helps generate multiple games quickly
// I'll create them individually but efficiently
console.log('Generating games batch...');
